function [mm,la,sa,lao,sao]=gharfer(g,plt)
%GHARFER Return Mean matrix of inertia and square root of eigenvalues ratio and directional parameters.
% Based on grain directional properties after Harvey & Ferguson (1981, Tectonophysics 74:T33-T42)
% and Harvey (1981, Computers & Geosciences 7:387-392)
% Syntax: [mm,la,sa,lao,sao]=gharfer(g,plt);
% Plot option plt 1..plot crosses 2..plot ellipses 3..ellipses and crosses

if nargin<2
 plt=0;
end

mm=[0 0;0 0];
rf=[];
la=[]; sa=[]; lao=[]; sao=[];

% Create convex hull (technique need convex polygon)
g=gconvhull(g);

h=fwaitbar(0,'Calculating...');
poc=length(g);
for ii=1:poc
    [x,y]=get(g(ii),'x','y');
    x=x(1:end-1);
    y=y(1:end-1);
    n=length(x);

    % shift to centre
    xc=get(g(ii),'xcentre');
    yc=get(g(ii),'ycentre');
    x=x-xc;
    y=y-yc; 

    % Calculate point and area functions
    ix=1:n; ixp=[2:n 1]; z=zeros(1,n);
    ftn=polyarea([x([ix;ixp]);z],[y([ix;ixp]);z])/3;
    xptn=sum(x([ix;ixp]))/2;
    yptn=sum(y([ix;ixp]))/2;
    ftp=sum(ftn([ix;ixp]));
    xptp=x(ixp)/2;
    yptp=y(ixp)/2;
    f=[ftn;ftp]; f=f(:);
    xp=[xptn;xptp']; xp=xp(:);
    yp=[yptn;yptp']; yp=yp(:);

    % Calculate inertia matrix
    j=1:2*n;
    totarea = sum(f);
    uxx=sum(f(j).*xp(j).^2);
    uyy=sum(f(j).*yp(j).^2);
    uxy = sum(f(j).*xp(j).*yp(j));

    m = [uxx uxy;...
         uxy uyy]./(2*n);

    mm = mm + m; % add to mean matrix

    % Calculate eigenvalues and eigenvectors
    [v,c]=eig(m);
    if c(1,1)<c(2,2)  % Sort eigenvalues and eigenvectors
        c=rot90(c,2);
        v=fliplr(v);
    end

    r = sqrt(c(1,1)/c(2,2)); % square root of eigenvalues ratio
    ra = sqrt(totarea*r/pi); rb = totarea / (pi*ra); % Long axis and Short axis scaled on totalarea
    oa = atan2(v(1,1),v(2,1));  ob = atan2(v(1,2),v(2,2)); % orientation

    fwaitbar(ii/poc,h);

    rf=[rf;r];
    la=[la;2*ra];
    sa=[sa;2*rb];
    lao=[lao;mod(deg(oa),180)];
    sao=[sao;mod(deg(ob),180)];

end

close(h)
mm=mm/poc; % weighted mean matrix

if plt~=0
    if bitget(plt,1)==1
        pcross(la/2,sa/2,lao,[get(g,'xcentre') get(g,'ycentre')],'k');
    end
    if bitget(plt,2)==1
        pellipse(la/2,sa/2,lao,[get(g,'xcentre') get(g,'ycentre')],'k');
    end
end
