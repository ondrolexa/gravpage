function [r,v,nnd]=gnna(g,plt)
%GNNA Return index of nearest-neighbour statistics.
% Syntax:  [R,va,dist]=gnna(g,plt);
%      plt - nonzero plt produce histogram of distances
%        R - nearest-neighbour statistics index
%            >1..regular 1..random <1..clustered
%       va - standart variate of normal curve
%     dist - vector of euclidan distances to nearest neighbour

%Reference: Clark, P.J., & Evans F.C. (1954). Distance to nearest neighbor
%as a measure of spatial relationships in populations. Ecology, 35, 445-453

if nargin<2
   plt=0;
end

nnd=[];

poc=length(g);
gx=get(g,'xcentre');
gy=get(g,'ycentre');
tri=delaunay(gx,gy); 
pts=[gx gy];

% determine area of convexhull
area=acharea(g,1);

% Calculate delta of random distribution
nnrd=0.5*sqrt(area/poc);

% Calculate distances
for j=1:poc
 [xi,yi]=find(tri==j);
 w=tri(xi,:);
 w=setdiff(w(:),j);
 dt=sqrt(sum((pts(w,:)-repmat(pts(j,:),length(w),1)).^2'));
 nn=min(dt);
 nnd=[nnd;nn];
end

mu=mean(nnd);

r=mu/nnrd;
v=abs(poc*(mu-nnrd))/(0.26136*sqrt(area));

disp(['R index: ' num2str(r)]);
if r>1
 disp(['Regularly spaced with standard variate: ' num2str(v)]);
else
 disp(['Clustered with standard variate: ' num2str(v)]);
end
if plt~=0
   phist(nnd);
end

