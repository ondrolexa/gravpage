function [la,sa,lao,sao]=aorten2(g,plt)
%AORTEN2 Return parameters of orientation tensor of decomposed grain/boundary.
% Syntax: [la,sa,lao,sao]=aorten2(g,plt);
% g can be grain and boundary object(s)
% Plot option plt 1..plot crosses 2..plot ellipses 3..ellipses and crosses

if nargin<2
    plt=0;
end

%Initialize
poc=size(g,2);
if (isa(g,'grain'))
    aa=get(g,'area');
else
    aa=get(g,'length').*get(g,'width');
end
la=[]; sa=[]; lao=[]; sao=[];

h=fwaitbar(0,'Calculating...');
for ii=1:poc
    
    [x,y]=get(g(ii),'x','y');
    dx=x(2:end)-x(1:end-1);
    dy=y(2:end)-y(1:end-1);
    
    m=([dx dy]'*[dx dy])/length(dx);
    
    % Calculate eigenvalues and eigenvectors
    [v,c]=eig(m);
    if c(2,2)<c(1,1)  % Sort eigenvalues and eigenvectors
        c=rot90(c,2);
        v=fliplr(v);
    end
    
    c(c<0)=0; % chybicka zaokruhlovania
    ra = sqrt(c(2,2));
    rb = sqrt(c(1,1));
    if rb>0
        kk=aa(ii)/(pi*ra*rb);
    else
        kk=1;
    end
    oa = atan2(v(1,2),v(2,2));
    ob = atan2(v(1,1),v(2,1)); % orientation
    
    fwaitbar(ii/poc,h);
    la=[la;2*sqrt(kk)*ra];
    sa=[sa;2*sqrt(kk)*rb];
    lao=[lao;mod(deg(oa),180)];
    sao=[sao;mod(deg(ob),180)];

end
close(h)

if plt~=0
    if bitget(plt,1)==1
        pcross(la/2,sa/2,lao,[get(g,'xcentre') get(g,'ycentre')],'k');
    end
    if bitget(plt,2)==1
        pellipse(la/2,sa/2,lao,[get(g,'xcentre') get(g,'ycentre')],'k');
    end
end
