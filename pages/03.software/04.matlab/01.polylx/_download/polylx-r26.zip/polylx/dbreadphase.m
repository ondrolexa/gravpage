function g=dbreadphase(samples,phase)
%DBREADPHASE Read all grains of choosen phase from database.
% Syntax:  g=dbreadphase;
%          g=dbreadphase(samples,phase);

% Ondrej Lexa 2006

global polylx_prefs
%Check connection
if dbconnect
    if nargin<1
        samples=dbcommand(['SELECT name FROM samples']);
        if isempty(samples)
            disp('No samples in open database. Aborting.');
            g=[];
            dbclose
            return
        end
    end
    if nargin<2
        if strcmpi(polylx_prefs.driver,'MySQL')
            up={};
            for i=1:length(samples)
                upt=dbcommand(['SELECT phase FROM grains INNER JOIN samples ON (grains.id_sample=samples.id) WHERE samples.name="' samples{i} '"']);
                up=union(up,upt);
            end
        else
            up={};
            for i=1:length(samples)
                upt=dbcommand(['SELECT DISTINCT phase FROM ' samples{i} '.grains']);
                up=union(up,upt);
            end
        end
        [sel,ok] = listdlg('ListString',up,'SelectionMode','single','Name','Select sample');
        if ok==0
            g=[];
            dbclose;
            return
        else
            phase=up{sel};
        end
    end
    if strcmpi(polylx_prefs.driver,'MySQL')
        ii=1;
        for k=1:length(samples)
            res=dbcommand(['SELECT grains.id_grain,samples.name,AsText(geometry) FROM samples INNER JOIN grains ON (samples.id=grains.id_sample) WHERE grains.phase="' phase '" AND samples.name="' samples{k} '"']);
            poc=size(res,2);
            if poc>0
                g(ii:poc+1)=grain;
                h=fwaitbar(0,['Reading grains ' num2str(k) ' of ' num2str(length(samples)) ' from database...']);
                for i=1:poc;
                    wkt=res{3,i};
                    if ~ischar(wkt)
                        wkt=char(wkt');
                    end
                    co=sscanf(strrep(wkt(strfind(wkt,'((')+2:strfind(wkt,'))')-1),'),(',',NaN NaN,'),'%f %f,',[2,inf]);
                    g(ii+i-1)=grain(res{1,i},res{2,i},co(1,:)',co(2,:)');
                    fwaitbar(i/poc,h);
                end
                ii=ii+poc;
                close(h)
            end
        end
    else
        gid=0;
        for i=1:length(samples)
            res=dbcommand(['SELECT id_grain,AsText(geometry) FROM ' samples{i} '.grains WHERE phase=''' phase '''']);
            poc=size(res,2);
            h=fwaitbar(0,['Reading grains ' num2str(i) ' of ' num2str(length(samples)) ' from database...']);
            if poc>0
                for j=1:poc;
                    gid=gid+1;
                    wkt=res{2,j};
                    co=sscanf(strrep(wkt(strfind(wkt,'((')+2:strfind(wkt,'))')-1),'),(',',NaN NaN,'),'%f %f,',[2,inf]);
                    g(gid)=grain(res{1,j},samples{i},co(1,:)',co(2,:)');
                    fwaitbar(j/poc,h);
                end
            end
            close(h);
        end
    end
end
dbclose;
