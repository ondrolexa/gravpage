function [exn,obn]=cameth(g,b)
%CAMETH Direct Contact area method (Kretz 1969).
% NOT YET IMPLEMENTED PROPERLY. DO NOT USE.
% Syntax:  [exn,obn]=cameth(g,b);
%   exn - cell array of expected contact lengths from random distribution
%   obn - cell array of observed contact lengths

if nargin<2
   help cameth
   return
end

% obtain phase list and number of phases
phlist=gplist(g);
pf=size(phlist,1);

% Calculate area fractions
totarea=sum(get(g,'area'));
af=zeros(pf,1);
for i=1:pf
 af(i)=sum(get(g(phlist{i}),'area'))/totarea;
end

% Calculate probability table for randomness distribution
% (diagonals are af^2, outdiagonals are 2*af(i)*af(j)
expn=2*af*af'; % double outer product
expn=expn-diag(diag(expn)/2); % half of diagonals

% Calculate total length and expected length table

totlength=sum(get(b,'cumlength'));
expn=expn.*totlength;

% Calculate observed lengths table
for i=1:pf
 for j=i:pf
  ph=sort({phlist{i};phlist{j}});
  bt=[ph{1} '-' ph{2}];
  obt(j,i)=sum(get(b(bt),'cumlength'));
  obt(i,j)=obt(j,i);
 end
end

exn=[{'Expected'} gplist(g)' ; [gplist(g) num2cell(tril(2*expn-diag(diag(expn))))]];
obn=[{'Obtained'} gplist(g)' ; [gplist(g) num2cell(tril(2*obt-diag(diag(obt))))]];

% Calculate chi-square value
if exist('chi2cdf','file')==2
 chis=sum(sum(tril(((obt-expn).^2)./expn)));
 pp=chi2cdf(chis,pf*(pf+1)/2-1);
 if pp>0.5
  disp(['Contacts are not randomly distributed at significance level ' num2str(pp*100)]);
 else
  disp(['Contacts are randomly distributed at significance level ' num2str(100-pp*100)]);
 end
end

while 1
 phx=listdlg('ListString',phlist,'Name','Choose Type(s)','ListSize',[150 200],'CancelString','Exit');
 if isempty(phx)
  return
 end


 % plot histogram
 obt1=2*obt(phx,phx)-diag(diag(obt(phx,phx)));
 expn1=2*expn(phx,phx)-diag(diag(expn(phx,phx)));
 obt2=[];
 expn2=[];
 names=[];
 clf;
 hold on
 for i=1:length(phx)
  for j=i:length(phx)
   names=strvcat(names,[phlist{phx(i)} '-' phlist{phx(j)}]);
   obt2=[obt2;obt1(i,j)];
   expn2=[expn2;expn1(i,j)];
   if i==j
    bar(size(names,1),(obt1(i,j)-expn1(i,j))./sqrt(expn1(i,j)),1,'r');
   else
    bar(size(names,1),(obt1(i,j)-expn1(i,j))./sqrt(expn1(i,j)),1,'b');
   end
  end
 end
 %bar(100*obt2./expn2-100,1);
 set(gca,'XTickLabel',names)
 set(gca,'XTick',1:length(obt2))
 ax=axis;
 ax(1:2)=[0.5 length(obt2)+0.5];
 axis(ax);
 title('Contact Area Method')
 ylabel('(O-E)/sqrt(E)')
 if length(obt2)>10
   xstairlabels;
 end
end
