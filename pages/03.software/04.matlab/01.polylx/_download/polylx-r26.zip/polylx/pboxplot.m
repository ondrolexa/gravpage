function pboxplot(g,varargin)
%PBOXPLOT Routine to plot boxplot of measuremnts of individual phases/types.
% Syntax: pboxplot(g,[prop]);
%         pboxplot(data,labels);
% g is grain/boundary objects
% data and labels are cell objects
% 
% Ondrej Lexa 2001, 2009

if nargin<1
   help pboxplot
   return
end

valid=1;
xlbl='Data position';
ylbl='Value';

if isa(g,'grain') || isa(g,'boundary')
    if nargin<2
        tlist=get(g);
        [typa,valid]=listdlg('PromptString','Select measurement:','SelectionMode','Single','ListString',tlist);
    else
        typa=1;
        tlist=varargin;
    end
    ph=gplist(g);
    % padding data and prepare labels
    x={};
    labl=ph;
    for i=1:length(ph)
        x{i}=get(g(ph{i}),tlist{typa});
        labl{i}=[labl{i} ' (' num2str(length(x{i})) ')'];
    end
    if isa(g,'grain')
        xlbl='Phases';
    else
        xlbl='Types';
    end
    ylbl=tlist{typa};
elseif isa(g,'double')
    x={g(:)};
    labl=varargin{1};
elseif isa(g,'cell')
    x=g;
    labl=varargin{1};
else
    error('Wrong argument')
end
if valid~=1
   disp ('Aborted.')
   return
end

if isempty(labl)
    for i=1:length(g)
        labl{i}=num2str(i);
    end
end

newplot;
boxplt(x,labl);
ylabel(ylbl);
xlabel(xlbl)
if length(x)>10
   xstairlabels;
end

function boxplt(data,labl)
%BOXPLOT Routine to plot boxplot of data.

% Ondrej Lexa 2001

ndata = length(data);

if ndata == 1
   [t,b] = oneboxplot(data{1}, 1, .4);
   axis([0 2 b-.05*(t-b) t+.05*(t-b)])
else
   tt = -1e100;
   bb =  1e100;
   for k=1:ndata
      [t,b] = oneboxplot(data{k}, k, .3);
      tt = max(t,tt);
      bb = min(b,bb);
      hold on;
   end
   axis([0 (ndata+1) bb-.05*(tt-bb) tt+.05*(tt-bb)]);
   hold off;
end 
set(gca,'XTick', 1:ndata);
set(gca,'XTickLabel',labl)

function [high, low] = oneboxplot(data, xpos, halfwidth)
% helper function for boxplots

foo = percentil(data(:), [25, 50, 75]);
q1 = foo(1); q2 = foo(2); q3 = foo(3);

xleft=xpos-halfwidth; xright=xpos+halfwidth;

high = max(data);
low  = min(data);
top = min( high, q3+1.5*(q3-q1) );
bottom = max( low, q1-1.5*(q3-q1) );
outliers = data( data<bottom | data>top );
xvals = xpos*ones(size(outliers));

plot([xleft xleft xright xright xleft],[q1 q3 q3 q1 q1], 'k-',...
   [xleft xright], [q2 q2], 'k-', ...
   [xpos xpos (xpos-halfwidth/3) (xpos+halfwidth/3)],... 
   [q3 top top top],'k-', ...
   [xpos xpos (xpos-halfwidth/3) (xpos+halfwidth/3)],... 
   [q1 bottom bottom bottom],'k-',...
   xvals, outliers, 'k.',...
   [xpos xpos], [top high],'k:',...
   [xpos xpos], [bottom low], 'k:');

