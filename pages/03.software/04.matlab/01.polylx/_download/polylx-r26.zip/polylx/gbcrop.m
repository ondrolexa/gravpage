function [gsub,bsub]=gbcrop(g,b)
%GBCROP Crop area from boundary and grain objects.
% Syntax: [gsub,bsub]=gbcrop(g,b);

if nargin<2
    b=bmake(g);
end
clf;
idplot(g);
title('Select grain by mouse and hit any key');
pause
ix=getsel;
gsub=g(ix);
bsub=bgsel(gsub,b);
