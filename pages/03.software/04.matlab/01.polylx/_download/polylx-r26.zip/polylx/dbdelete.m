function dbdelete(sample)
%DBDELETE Delete sample(s) in database.

global polylx_prefs
%Check connection
if dbconnect

    if nargin<1
        res=dbcommand(['SELECT name FROM samples']);
        if isempty(res)
            disp('No samples in open database. Aborting.');
            dbclose;
            return
        else
            [sel,ok] = listdlg('ListString',res,'Name','Select sample(s)');
            if ok==0
                dbclose;
                return
            else
                sample=res(sel);
            end
        end
    end
    if ischar(sample)
        sample={sample};
    end
    
    % delete samples
    bt=questdlg(['Are you sure that you want to permanently delete selected samples from database ?'],'Delete sample from database','Yes','No','No');
    if ~strcmp(bt,'Yes')
        return
    end
    for i=1:length(sample)
        res=dbcommand(['SELECT id FROM samples WHERE name=''' sample{i} '''']);
        if isempty(res)
            disp(['No sample ' sample{i} ' in database. Skipped.']);
        else
            if strcmpi(polylx_prefs.driver,'MySQL')
                id_sample=res{1};
                dbcommand(['DELETE FROM grains WHERE id_sample=' num2str(id_sample)]);
                dbcommand(['DELETE FROM boundaries WHERE id_sample=' num2str(id_sample)]);
                dbcommand(['DELETE FROM samples WHERE id=' num2str(id_sample)]);
            else
                dbcommand(['DELETE FROM samples WHERE name=''' sample{i} '''']);
                dbcommand(['DROP SCHEMA ' sample{i} ' CASCADE;']);
            end
        end
    end
end
