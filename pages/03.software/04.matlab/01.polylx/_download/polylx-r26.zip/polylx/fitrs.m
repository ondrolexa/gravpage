function [err,yt]=fitrs(lam,xx)
% function to fit data on ellipse
% lam is [a b c]

% Ondrej Lexa 2002

global xdat ydat

a=lam(1);
b=lam(2);
c=lam(3);

if nargout<2
 yt=c-a.*cos(2*xdat)-b*sin(2*xdat);
 err=sum((ydat-yt).^2.*(ydat));
else
 yt=c-a.*cos(2*xx)-b*sin(2*xx);
 err=0;
end