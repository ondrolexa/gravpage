/*
SQL dump for PolyLX database for MySQL 5.0 and higher
Ondrej Lexa 2006
*/

/*Table structure for table `samples` */

DROP TABLE IF EXISTS `samples`;

CREATE TABLE `samples` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `name` varchar(20) collate latin1_general_ci default NULL,
  `label` varchar(10) collate latin1_general_ci default NULL,
  `X` float default NULL,
  `Y` float default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

/*Table structure for table `grains` */

DROP TABLE IF EXISTS `grains`;

CREATE TABLE `grains` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `id_sample` int(10) unsigned default NULL,
  `id_grain` int(10) unsigned default NULL,
  `phase` varchar(20) collate latin1_general_ci default NULL,
  `geometry` polygon default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

/*Table structure for table `boundaries` */

DROP TABLE IF EXISTS `boundaries`;

CREATE TABLE `boundaries` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `id_sample` int(10) unsigned default NULL,
  `id_boundary` int(10) unsigned default NULL,
  `id_graina` int(10) unsigned default NULL,
  `id_grainb` int(10) unsigned default NULL,
  `phasea` varchar(20) collate latin1_general_ci default NULL,
  `phaseb` varchar(20) collate latin1_general_ci default NULL,
  `geometry` linestring default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
