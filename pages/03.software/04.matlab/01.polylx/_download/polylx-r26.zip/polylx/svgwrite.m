function svgwrite(g,varargin)
%SVGWRITE Write SVG (Scalable Vector Graphics) file suitable for web.
%publishibg or import into graphics editors like Inkscape, CorelDraw etc.
% Syntax: svgwrite(g);
%         svgwrite(g,filename);
%         svgwrite(g,pal);
%         svgwrite(g,filename,pal);
% g is grain or boundary object(s)
% pal is optional palette made with makepal

% GUI save file
if nargin<1
    help svgwrite
    return
end

for i=1:length(varargin)
    switch class(varargin{i})
        case 'cell'
            if size(varargin{i},2)==2
                pal=makepal(g,ct);
            else
                pal=varargin{i};
            end
        case 'char'
            filename=varargin{i};
        otherwise
            error('Wrong argument. Aborted.');
    end
end
            
if ~exist('filename','var')
    [fnm, pth]=uiputfile({'*.svg','SVG file (*.svg)'},'Save SVG file');
    if fnm==0
        return
    end
    filename=[pth fnm];
end
if ~exist('pal','var')
    pal=makepal(g);
end 

bb=acharea(g,[5 6 7 8]);
dscale=1000/max(bb(2)-bb(1),bb(4)-bb(3));

NEWLINE = sprintf('\n');

fid = fopen(filename ,'w');
if fid == (-1), error(['Could not write to file ' filename]); end

fwrite(fid,'<?xml version="1.0" encoding="UTF-8" standalone="no"?>','uchar'); fwrite(fid, NEWLINE, 'char');
fwrite(fid,['<svg width="100%" height="100%" viewBox="' sprintf('%f %f %f %f',dscale*[bb(1)-0.05*(bb(2)-bb(1)) -bb(4)-0.05*(bb(4)-bb(3)) 1.1*(bb(2)-bb(1)) 1.1*(bb(4)-bb(3))]) '" xmlns="http://www.w3.org/2000/svg" version="1.1">'],'uchar'); fwrite(fid, NEWLINE, 'char');
fwrite(fid,'<desc>Exported from PolyLX Toolbox (c) Ondrej Lexa</desc>','uchar'); fwrite(fid, NEWLINE, 'char');
fwrite(fid,'<g id="','uchar');
[upal,ix]=unique(cat(1,pal{:,1}));

switch class(g)
    case 'grain'
        fwrite(fid,'grains">','uchar');  fwrite(fid, NEWLINE, 'char');
        for i=1:length(g)
            if pal{i,1}>0
                cc=dec2hex(round(255*pal{i,3}));
                cc=lower(reshape(cc',1,6));
                co=dscale*[get(g(i),'x') -get(g(i),'y')]';
                fwrite(fid,['<path id="grain' num2str(get(g(i),'id')) '" style="fill:#' cc ';stroke:black;stroke-width:1" d="'],'uchar');
                fprintf(fid,'M %f %f ',co(:,1));
                fprintf(fid,'L %f %f ',co(:,2:end));
                fwrite(fid,'z ','uchar');
                hol=get(g(i),'holes');
                for j=1:get(g(i),'nholes');
                    co=dscale*[hol(j).x -hol(j).y]';
                    fprintf(fid,'M %f %f ',co(:,1));
                    fprintf(fid,'L %f %f ',co(:,2:end));
                    fwrite(fid,'z ','uchar');
                end
                fwrite(fid,['" />'],'uchar');  fwrite(fid, NEWLINE, 'char');
            end
        end
    otherwise
        fwrite(fid,'boundaries">','uchar');  fwrite(fid, NEWLINE, 'char');
        for i=1:length(g)
            if pal{i,1}>0
                cc=dec2hex(round(255*pal{i,3}));
                cc=lower(reshape(cc',1,6));
                fwrite(fid,['<polyline id="boundary' num2str(get(g(i),'id')) '" fill="none" stroke="#' cc '" stroke-width="1" points="'],'uchar');
                co=dscale*[get(g(i),'x') -get(g(i),'y')]';
                fprintf(fid,'%f,%f ',co(:));
                fwrite(fid,['" />'],'uchar');  fwrite(fid, NEWLINE, 'char');
            end
        end
end
fwrite(fid,'</g>','uchar'); fwrite(fid, NEWLINE, 'char');

fwrite(fid,'<g id="legend">','uchar'); fwrite(fid, NEWLINE, 'char');
ix1=find(cat(1,pal{:,1})~=0);
[upal,ix2]=unique(cat(1,pal{ix1,1}));
fwrite(fid,['<rect x="' num2str(dscale*(bb(1)-0.05*(bb(2)-bb(1)))+50) '" y="1000" width="' num2str(150+6*size(char(pal(ix1(ix2),2)),2)) '" height="' num2str(length(upal)*25+50) '" fill="white" stroke="black" stroke-width="1"/>'],'uchar'); fwrite(fid, NEWLINE, 'char');
for i=1:length(upal)
    cc=dec2hex(round(255*pal{ix1(ix2(i)),3}));
    cc=lower(reshape(cc',1,6));
    fwrite(fid,['<rect x="' num2str(dscale*(bb(1)-0.05*(bb(2)-bb(1)))+100) '" y="' num2str(1000+i*25) '" width="45" height="20" fill="#' cc '" stroke="black" stroke-width="1"/>'],'uchar'); fwrite(fid, NEWLINE, 'char');
    fwrite(fid,['<text x="' num2str(dscale*(bb(1)-0.05*(bb(2)-bb(1)))+150) '" y="' num2str(1000+i*25+12) '">' pal{ix1(ix2(i)),2} '</text>'],'uchar'); fwrite(fid, NEWLINE, 'char');
end

fwrite(fid,'</g></svg>','uchar'); fwrite(fid, NEWLINE, 'char');
fclose(fid);
