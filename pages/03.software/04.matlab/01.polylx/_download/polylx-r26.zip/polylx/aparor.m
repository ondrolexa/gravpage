function [pd,la,sa,lao,sao]=aparor(g,opt,plt)
%APAROR Return results of PAROR analysis after R.Panozzo.
% Syntax: [pd,la,sa,lao,sao]=aparor(g,opt,plt);
% g can be grain and boundary object(s)
% opt 1.. fit best ellipse projection (SLOW!!!)
% Plot option plt 1..plot crosses 2..plot ellipses 3..ellipses and crosses

if nargin<1
    help aparor;
    return;
end

if nargin<3
 plt=0;
end

if nargin<2
 opt=0;
end

%Initialize
n=size(g,2);
pd=zeros(n,180); la=zeros(n,1); sa=la; lao=la; sao=la;

h=fwaitbar(0,'Calculating...');

nn=[sin(rad(1:180));cos(rad(1:180))];

for ii=1:n
    [x,y]=get(g(ii),'x','y');

    ff=[x y]*nn;
    f=(max(ff)-min(ff))';

    if opt==1
        [f,lat,sat,laot,saot]=fitpd(f); % fit ellipse
        laot=mod(laot,180);
        saot=mod(saot,180);
        lat=2*lat;
        sat=2*sat;
    else
        [sat,saot]=min(f); % just analyze (fast)
        [lat,laot]=max(f);
    end

    pd(ii,:)=f;
    sa(ii)=sat;
    sao(ii)=saot;
    la(ii)=lat;
    lao(ii)=laot;

    fwaitbar(ii/n,h);
end

% turn 180 to 0
lao(lao==180)=0;
sao(sao==180)=0;

close(h)

if plt~=0
    if bitget(plt,1)==1
        pcross(la/2,sa/2,lao,[get(g,'xcentre') get(g,'ycentre')],'k');
    end
    if bitget(plt,2)==1
        pellipse(la/2,sa/2,lao,[get(g,'xcentre') get(g,'ycentre')],'k');
    end
end

