function gc=garea(g,plt)
%GAREA Return area, area fraction, number of grains and average diameter
% for each phase. Average diameter is EAD for average area.
% Syntax: gc=garea(g,plt);
%  g     - grain objects
%  plt   - nonzero plt produce a pie graph

if nargin<2
 plt=0;
end
if ~isa(g,'grain')
    error('First argument must be grain object!');
end

% obtain phase list and number of phases
ph=gplist(g);
pf=size(ph,1);
leg=cell(pf,1);
gc=zeros(pf,4);
ta=sum(get(g,'area'));

% Calculate area fractions

for i=1:pf
 ix=gpsel(g,ph{i});
 ca=sum(get(g(ix),'area'));
 gc(i,:)=[ca 100*ca/ta length(ix) sqrt(ca/(length(ix)*pi))];
 leg{i}=[ph{i} ' (' num2str(gc(i,3)) ')'];
end

if plt~=0
 ix=gc(:,2)<=2;
 if length(find(ix))>1
    pie([gc(~ix,2); sum(gc(ix,2))]);
    legend([leg(~ix);{['Others (' num2str(sum(gc(ix,3))) ')']}]);
 else
    pie(gc(:,2));
    legend(leg);
 end
end
gc=[{'Phase' 'Area' '%' 'N' 'Dm'};ph num2cell(gc)];
