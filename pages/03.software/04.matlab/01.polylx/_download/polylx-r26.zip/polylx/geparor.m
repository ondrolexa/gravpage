function [la,sa,lao,sao]=geparor(g,plt)
%GEPAROR Exact paror. Long axis is in direction onto which projection is maximum.
% Short axis is in right angle
% Syntax: [la,sa,lao,sao]=geparor(g,plt)
% Plot option plt 1..plot crosses 2..plot ellipses 3..ellipses and crosses

if nargin<2
 plt=0;
end

%Initialize
n=size(g,2);
la=zeros(n,1); sa=la; lao=la; sao=la;

h=fwaitbar(0,'Calculating...');

for ii=1:n
    dt=get(g(ii),'x','y');
    m=size(dt,1);
    p=(m-1):-1:2;
    k=zeros(m*(m-1)/2,1);
    k(cumsum([1 p]))=1;
    k=cumsum(k);
    j=ones(m*(m-1)/2,1);
    j(cumsum(p)+1)=2-p;
    j(1)=2;
    j=cumsum(j);
    l=(dt(k,:)-dt(j,:))';
    l=sum(l.^2);
    l=sqrt(l);
    n=size(l,2);
    m=(1+sqrt(1+8*n))/2;
    z=zeros(m);
    k=ones(n,1);
    j=[1 (m-1):-1:2]';
    k(cumsum(j))=(2:m);
    z(cumsum(k))=l';
    z = z + z';
    [z1,p1]=max(z);
    [lat,p2]=max(z1);
    p1=p1(p2);
    dp=dt(p2,:)-dt(p1,:);
    rv=dp/sqrt(dp*dp');
    rv=[rv(2);-rv(1)]; % unit perpendicular vector
    pp=(dt*rv); % projection onto rv
    la(ii)=lat;
    sa(ii)=max(pp)-min(pp);
    lao(ii)=mod(atan2(dp(1),dp(2))*180/pi,180);
    sao(ii)=mod(lao(ii)+90,180);
    fwaitbar(ii/n,h);
end

close(h)

if plt~=0
 if bitget(plt,1)==1
  pcross(la/2,sa/2,lao,[get(g,'xcentre') get(g,'ycentre')],'k');
 end
 if bitget(plt,2)==1
  pellipse(la/2,sa/2,lao,[get(g,'xcentre') get(g,'ycentre')],'k');
 end
end
