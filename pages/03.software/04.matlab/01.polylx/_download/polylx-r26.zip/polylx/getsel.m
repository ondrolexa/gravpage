function ix=getsel(obj)
%GETSEL Return indexes of actual selection or modify selection.
% GETSEL CLEAR clear selection.
% GETSEL INVERT invert selection.
%
% Internal callback from ButtonDownFcn event to select or unselect grain

if nargin < 1, obj = gcbo; end
if nargout > 0, ix=[]; end

% Clear selection
if strcmpi(obj,'clear')
    if any(get(0,'CurrentFigure'))
        h=findobj(gca,'Type','patch','Selected','on','Tag','grain');
        if any(h)
            c=get(h,'UserData');
            if size(c,1)>1
                cc=cat(1,c{:});
            else
                cc=c;
            end
            fl=isnan(cc(:,4));
            set(h,'Selected','off')
            set(h(~fl),{'FaceColor'},num2cell(cc(~fl,4:6),2));
            set(h(fl),'FaceColor','flat');
        end
    end
    return
end

% invert selection
if strcmpi(obj,'invert')
    if any(get(0,'CurrentFigure'))
        h=findobj(gca,'Type','patch','Tag','grain');
        for i=1:length(h)
            switch get(h(i), 'Selected')
                case 'on'
                    set(h(i),'Selected','off')
                    c=get(h(i),'UserData');
                    if all(isnan(c(4:6)))
                        set(h(i),'FaceColor','flat')
                    else
                        set(h(i),'FaceColor',c(4:6))
                    end
                otherwise
                    set(h(i),'Selected','on')
                    c=get(h(i),'UserData');
                    cc=get(h(i),'FaceColor');
                    if strcmp(cc,'flat')
                        c(4:6)=[NaN NaN NaN];
                    else
                        c(4:6)=cc;
                    end
                    set(h(i),'UserData',c)
                    set(h(i),'FaceColor',[1 1 0])
            end
        end
    end
    return
end

% return ID's
if ~strcmp(get(obj,'Type'),'patch')
    if any(get(0,'CurrentFigure'))
        h=findobj(gca,'Type','patch','Selected','on','Tag','grain');
        if any(h)
            c=get(h,'UserData');
            if size(c,1)>1
                cc=cat(1,c{:});
                ix=sort(cc(:,1));
            else
                ix=c(1);
            end
        end
    end
    return
end

% do callback
switch get(obj, 'Type')
    case 'patch'
        switch get(obj, 'Selected')
            case 'on'
                set(obj,'Selected','off')
                c=get(obj,'UserData');
                if all(isnan(c(4:6)))
                    set(obj,'FaceColor','flat')
                else
                    set(obj,'FaceColor',c(4:6))
                end
            otherwise
                set(obj,'Selected','on')
                c=get(obj,'UserData');
                cc=get(obj,'FaceColor');
                if strcmp(cc,'flat')
                    c(4:6)=[NaN NaN NaN];
                else
                    c(4:6)=cc;
                end
                set(obj,'UserData',c)
                set(obj,'FaceColor',[1 1 0])
        end
    otherwise
        return
end
