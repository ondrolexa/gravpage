function g = grain(id,p,x,y,udata)
%GRAIN/GRAIN Create grain object
%   g = GRAIN(id,p,x,y,udata) create a grain object from vectors of coordinates x,y
%   with phase name p and id.
if nargin==4
    udata=struct;
end
if nargin == 0
   g=struct('id',[],...
            'phase',[],...
            'x',[],...
            'y',[],...
            'area',[],...
            'perimeter',[],...
            'length',[],...
            'width',[],...
            'orientation',[],...
            'xcentre',[],...
            'ycentre',[],...
            'nholes',[],...
            'holes',struct('x',[],...
                           'y',[],...
                           'area',[],...
                           'perimeter',[],...
                           'length',[],...
                           'width',[],...
                           'orientation',[],...
                           'xcentre',[],...
                           'ycentre',[]),...
            'userdata',struct);
   g=class(g,'grain');
elseif isa(id,'grain')
   g=id;
elseif nargin >= 4
    if isnumeric(p)
        p=num2str(p);
    end
    g=struct('id',id,...
            'phase',p,...
            'x',[],...
            'y',[],...
            'area',[],...
            'perimeter',[],...
            'length',[],...
            'width',[],...
            'orientation',[],...
            'xcentre',[],...
            'ycentre',[],...
            'nholes',0,...
            'holes',struct('x',[],...
                           'y',[],...
                           'area',[],...
                           'perimeter',[],...
                           'length',[],...
                           'width',[],...
                           'orientation',[],...
                           'xcentre',[],...
                           'ycentre',[]),...
            'userdata',udata);
   % Calculate object parameters
   in = [0;find(isnan(x));length(x)+1];
   nn = length(in)-1;
   ok=0;
   for jj=1:nn
    ii = in(jj)+1:in(jj+1)-1;
    xx = x(ii); yy = y(ii);
    %check double vertex
    ii=[1;1+find(diff(xx)~=0|diff(yy)~=0)];
    xx = xx(ii); yy = yy(ii);
    %ccw = sign((xx(2:end)-xx(1:end-1))'*(yy(1:end-1)+yy(2:end))/2);
    geom=plgeo(xx,yy);
    %[la,sa,or]=diamor(xx,yy);
    if sign(geom(1)) == 1
     ok=ok+1;
     if ok == 1 
        g.x=xx;
        g.y=yy;
        g.area=geom(1);
        g.perimeter=geom(2);
        g.length=geom(5);
        g.width=geom(6);
        g.orientation=geom(7);
        g.xcentre=geom(3);
        g.ycentre=geom(4);
     else
        disp(['More then one outer boundary for object ID:' num2str(id)]);
     end
    elseif sign(geom(1)) == -1
     g.nholes=g.nholes+1;
     g.holes(g.nholes).x=xx;
     g.holes(g.nholes).y=yy;
     g.holes(g.nholes).area=-geom(1);
     g.holes(g.nholes).perimeter=geom(2);
     g.holes(g.nholes).length=geom(5);
     g.holes(g.nholes).width=geom(6);
     g.holes(g.nholes).orientation=geom(7);
     g.holes(g.nholes).xcentre=geom(3);
     g.holes(g.nholes).ycentre=geom(4);
    else
    % Area 0 case
    end  
   end
   % Correct area and perimeter info
   for jj=1:g.nholes
     g.area=g.area-g.holes(jj).area;
     g.perimeter=g.perimeter+g.holes(jj).perimeter;
   end
   if ok == 0
      error(['None outer boundary for object ID:' num2str(id)]);
   end
   g=class(g,'grain');
else
 disp('Wrong number of arguments');
end

% begin of subfunction PLGEO

function geom=plgeo(x,y) 
% PLGEO Geometry of a planar polygon
%
%   PLGEO(X,Y) returns geometry of the polygon 
%   specified by vertices in vectors X and Y.
%
%   PLGEO returns area, centroid location, perimeter
%   GEOM = [ area  perimeter  x_cen  y_cen ]

% after H.J. Sommer script
% http://www.mathworks.com/matlabcentral/fileexchange/319

% check if inputs are same size
if ~isequal( size(x), size(y) ),
  error( 'X and Y must be the same size');
end

% number of vertices
x=shiftdim(x);
y=shiftdim(y);
n= size(x,1);

% temporarily shift data to mean of vertices for improved accuracy
xm=mean(x);
ym=mean(y);
x=x-xm*ones(n,1);
y=y-ym*ones(n,1);

% delta x and delta y
dx=x([2:n 1])-x;
dy=y([2:n 1])-y;

% sums  
A=sum(y.*dx-x.*dy)/2;
Axc=sum(6*x.*y.*dx-3*x.*x.*dy+3*y.*dx.*dx+dx.*dx.*dy )/12;
Ayc=sum(3*y.*y.*dx-6*x.*y.*dy-3*x.*dy.*dy-dx.*dy.*dy )/12;
Ixx=sum(2*y.*y.*y.*dx-6*x.*y.*y.*dy-6*x.*y.*dy.*dy-2*x.*dy.*dy.*dy-2*y.*dx.*dy.*dy-dx.*dy.*dy.*dy)/12;
Iyy=sum(6*x.*x.*y.*dx-2*x.*x.*x.*dy+6*x.*y.*dx.*dx+2*y.*dx.*dx.*dx+2*x.*dx.*dx.*dy+dx.*dx.*dx.*dy)/12;
Ixy=sum(6*x.*y.*y.*dx-6*x.*x.*y.*dy+3*y.*y.*dx.*dx-3*x.*x.*dy.*dy+2*y.*dx.*dx.*dy-2*x.*dx.*dy.*dy)/24;
P=sum(sqrt(dx.*dx+dy.*dy));

% check for CCW versus CW boundary
if A < 0,
  Ixx = -Ixx;
  Iyy = -Iyy;
  Ixy = -Ixy;
end

% centroidal moments
xc=Axc/A;
yc=Ayc/A;
Iuu = Ixx - A*yc*yc;
Ivv = Iyy - A*xc*xc;
Iuv = Ixy - A*xc*yc;

% replace mean of vertices
x_cen=xc+xm;
y_cen=yc+ym;

% principal moments and orientation
I=[Iuu -Iuv;-Iuv Ivv];
[eig_vec,eig_val]=eig(I);
ang1=atan2(eig_vec(1,1),eig_vec(2,1));
ang2=atan2(eig_vec(1,2),eig_vec(2,2));

%Project polygon on major directions to get width and length
rv1=[sin(ang1);cos(ang1)];
rv2=[sin(ang2);cos(ang2)];
pp1=([x y]*rv1);
pp2=([x y]*rv2);

% return values
geom=[A P x_cen y_cen max(pp1)-min(pp1) max(pp2)-min(pp2) mod(ang1*180/pi,180)];
