function varargout = get(g, varargin)
%GRAIN/GET - return grain properties

if nargout~=(nargin-1)&&nargout>1
    error('Wrong Number of arguments')
end

n=length(g);
val2=[];
noerr=0;
if nargin>1
    for i=1:length(varargin);
        switch lower(varargin{i})
            case 'id'
                val = cat(1,g.id);
            case 'phase'
                val=cell(length(g),1);
                [val{:}]=deal(g.phase);
            case 'x'
                if n == 1
                    val = g.x;
                else
                    error('This property is valid only for single grain object.')
                end
            case 'y'
                if n == 1
                    val = g.y;
                else
                    error('This property is valid only for single grain object.')
                end
            case 'area'
                val = cat(1,g.area);
            case 'perimeter'
                val = cat(1,g.perimeter);
            case {'length','feret'}
                val = cat(1,g.length);
            case {'loglength'}
                val = log10(cat(1,g.length));
            case 'width'
                val = cat(1,g.width);
            case 'axialratio'
                val = cat(1,g.length)./cat(1,g.width);
            case 'logaxialratio'
                val = log10(cat(1,g.length)./cat(1,g.width));
            case {'orientation','lao'}
                val = cat(1,g.orientation);
            case 'sao'
                val = mod(cat(1,g.orientation)+90,180);
            case 'xcentre'
                val = cat(1,g.xcentre);
            case 'ycentre'
                val = cat(1,g.ycentre);
            case 'elongation'
                val = (pi*cat(1,g.length).^2)./(4*cat(1,g.area));
            case 'ead'
                val = 2*sqrt(cat(1,g.area)/pi);
            case 'logead'
                val = log10(2*sqrt(cat(1,g.area)/pi));
            case 'ear'
                val = sqrt(cat(1,g.area)/pi);
            case 'eap'
                val = 2*pi*sqrt(cat(1,g.area)/pi);
            case 'roundness'
                val = (4*cat(1,g.area))./(pi*cat(1,g.length).^2);
            case 'circularity'
                val = 4*cat(1,g.area)./(cat(1,g.perimeter).*cat(1,g.length));
            case 'ellipticity'
                val = pi*cat(1,g.length).^2./cat(1,g.area)/2;
            case 'compactness'
                val = (cat(1,g.perimeter).^2)./(4*pi*cat(1,g.area));
            case 'gsi'
                val = 2*pi*sqrt(cat(1,g.area)/pi)./cat(1,g.length);
            case 'gsf'
                val = (cat(1,g.length)./cat(1,g.width)).^(0.318).*cat(1,g.perimeter)./(2*sqrt(cat(1,g.area)));
            case {'f','fractdim'}
                val= cat(1,g.perimeter)./(2*pi*sqrt(cat(1,g.area)/pi));
            case 'nholes'
                val = cat(1,g.nholes);
            case 'holes'
                if n == 1
                    if g.nholes~=0
                        val=g.holes;
                    else
                        val=struct([]);
                    end
                else
                    disp('This property is valid only for single object.')
                end
            case 'outarea'
                for ii=1:n
                    val(ii) = g(ii).area + sum(cat(1,g(ii).holes.area));
                end
                val=val(:);
            case 'outperimeter'
                for ii=1:n
                    val(ii) = g(ii).perimeter - sum(cat(1,g(ii).holes.perimeter));
                end
                val=val(:);
            case 'outelongation'
                for ii=1:n
                    oa(ii) = g(ii).area + sum(cat(1,g(ii).holes.area));
                end
                oa=oa(:);
                val = (pi*cat(1,g.length).^2)./(4*oa);
            case 'outead'
                for ii=1:n
                    oa(ii) = g(ii).area + sum(cat(1,g(ii).holes.area));
                end
                oa=oa(:);
                val = 2*sqrt(oa/pi);
            case 'outear'
                for ii=1:n
                    oa(ii) = g(ii).area + sum(cat(1,g(ii).holes.area));
                end
                oa=oa(:);
                val = sqrt(oa/pi);
            case 'outeap'
                for ii=1:n
                    oa(ii) = g(ii).area + sum(cat(1,g(ii).holes.area));
                end
                oa=oa(:);
                val = 2*pi*sqrt(oa/pi);
            case 'outroundness'
                for ii=1:n
                    oa(ii) = g(ii).area + sum(cat(1,g(ii).holes.area));
                end
                oa=oa(:);
                val = (4*oa)./(pi*cat(1,g.length).^2);
            case 'outcircularity'
                for ii=1:n
                    oa(ii) = g(ii).area + sum(cat(1,g(ii).holes.area));
                    op(ii) = g(ii).perimeter - sum(cat(1,g(ii).holes.perimeter));
                end
                oa=oa(:);
                op=op(:);
                val = 4*oa./(op.*cat(1,g.length));
            case 'outellipticity'
                for ii=1:n
                    oa(ii) = g(ii).area + sum(cat(1,g(ii).holes.area));
                end
                oa=oa(:);
                val = pi*cat(1,g.length).^2./oa/2;
            case 'outcompactness'
                for ii=1:n
                    oa(ii) = g(ii).area + sum(cat(1,g(ii).holes.area));
                    op(ii) = g(ii).perimeter - sum(cat(1,g(ii).holes.perimeter));
                end
                oa=oa(:);
                op=op(:);
                val = (op.^2)./(4*pi*oa);
            case 'outgsi'
                for ii=1:n
                    oa(ii) = g(ii).area + sum(cat(1,g(ii).holes.area));
                end
                oa=oa(:);
                val = 2*pi*sqrt(oa/pi)./cat(1,g.length);
            case 'outgsf'
                for ii=1:n
                    oa(ii) = g(ii).area + sum(cat(1,g(ii).holes.area));
                    op(ii) = g(ii).perimeter - sum(cat(1,g(ii).holes.perimeter));
                end
                oa=oa(:);
                op=op(:);
                val = (cat(1,g.length)./cat(1,g.width)).^(0.318).*op./(2*sqrt(oa));
            case {'outf','outfractdim'}
                for ii=1:n
                    oa(ii) = g(ii).area + sum(cat(1,g(ii).holes.area));
                    op(ii) = g(ii).perimeter - sum(cat(1,g(ii).holes.perimeter));
                end
                oa=oa(:);
                op=op(:);
                val= op./(2*pi*sqrt(oa/pi));
            case 'userdata'
                if nargin>i+1&&~isempty(strmatch(varargin{i+1},fieldnames(g(1).userdata),'exact'))
                    if isnumeric(g(1).userdata.(varargin{i+1}))
                        for ii=1:length(g)
                            val(ii,:) = g(ii).userdata.(varargin{i+1});
                        end
                    else
                        for ii=1:length(g)
                            val{ii,:} = g(ii).userdata.(varargin{i+1});
                        end
                    end
                    noerr=1;
                else
                    if i>1||nargin>2
                        error('UserData cannot be collated.');
                    else
                        for ii=1:length(g)
                            val(ii) = g(ii).userdata;
                        end
                        if isempty(fieldnames(val))
                            val=struct;
                        end
                    end
                end
            otherwise
                if ~noerr
                    error([varargin{i},' is not valid grain property.']);
                else
                    val=[];
                    noerr=0;
                end
        end
        try
            val2=[val2 val];
        catch
            error('Not allowed combination of properties.');
        end
    end
    if nargout==size(val2,2)
        for i=1:nargout
            varargout{i}=val2(:,i);
        end
    else
        varargout{1}=val2;
    end
else
    if nargout>0
        varargout{1}={'ID','Phase','XCentre','YCentre','Area','OutArea','Perimeter','OutPerimeter','Length','LogLength','Width','Orientation','SAO','AxialRatio','LogAxialRatio','Elongation','OutElongation','EAD','LogEAD','OutEAD','EAR','OutEAR','EAP','OutEAP','Roundness','OutRoundness','Circularity','OutCircularity','Ellipticity','OutEllipticity','Compactness','OutCompactness','GSI','OutGSI','GSF','OutGSF','FractDim','OutFractDim','NHoles','UserData'};
    else
        disp('Available grain properties are:');
        disp('  ID');
        disp('  Phase');
        disp('  X (for single grain only)');
        disp('  Y (for single grain only)');
        disp('  XCentre');
        disp('  YCentre');
        disp('  [Out]Area');
        disp('  [Out]Perimeter');
        disp('  Length');
        disp('  LogLength');
        disp('  Width');
        disp('  Orientation/LAO');
        disp('  SAO');
        disp('  AxialRatio');
        disp('  LogAxialRatio - log10 of axial ratio');
        disp('  [Out]Elongation');
        disp('  [Out]EAD - Equal area diameter');
        disp('  LogEAD - log10 of Equal area diameter');
        disp('  [Out]EAR - Equal area radius');
        disp('  [Out]EAP - Equal area perimeter');
        disp('  [Out]Roundness');
        disp('  [Out]Circularity');
        disp('  [Out]Ellipticity');
        disp('  [Out]Compactness');
        disp('  [Out]GSI - Grain shape index');
        disp('  [Out]GSF - Grain shape factor');
        disp('  [Out]F or [Out]FractDim - shape factor or fractal dimension');
        disp('  NHoles');
        disp('  Holes (for single grain only)');
        disp('  UserData');
    end
end
