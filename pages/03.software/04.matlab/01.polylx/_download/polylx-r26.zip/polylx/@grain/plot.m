function plot(g,varargin)
%GRAIN/PLOT Plot grain objects g on active figure
%   PLOT(g,options) plot grain objects g on active figure.
%Options
%  'noleg'    ... do not place legend
%  'vertex'   ... plot vertices
%   ct or pal ... colortable (GENCT) or pallete (MAKEPAL)
%   bb        ... bounding box. double of size [4 2]. see ELLEREAD

poc=length(g);
leg=1;
vert=0;
pltbx=0;
% process inputs
for i=1:length(varargin)
    switch class(varargin{i})
        case 'char'
            switch lower(varargin{i})
                case {'on','leg=1'}
                    leg=1;
                case {'noleg','off','leg=0'}
                    leg=0;
                case 'vertex'
                    vert=1;
                otherwise
                    error('Wrong argument !');
            end
        case 'cell'
            %check template
            if size(varargin{i},2)==2
                tmpl=varargin{i};
                pal=[repmat({[0]},poc,1) repmat({''},poc,1) repmat({[0 0 0]},poc,1)];
                for ii=1:size(tmpl,1)
                    ix=gpsel(g,tmpl{ii,1});
                    if ~isempty(ix)
                        pal(ix,1)={ii};
                        pal(ix,2)={[tmpl{ii,1} ' (' num2str(length(ix)) ')']};
                        pal(ix,3)={tmpl{ii,2}};
                    end
                end
            else
                pal=varargin{i};
            end
        case 'double'
            if all(size(varargin{i})==[4 2])
                bb=varargin{i};
                pltbx=1;
            end
            
        otherwise
            error('Wrong argument !');
    end
end
if ~exist('pal','var')
    pal=makepal(g);
end
%Check pallete
if ~all(size(pal)==[poc 3])==iscell(pal)
    error('Palette is not compatible with passed grains objects! Use makepal.');
end
% Clear figure when not holded
if ~ishold
 clf
end
set(gca,'Box','on','TickDir','out','XminorTick','on','YminorTick','on');
a=get(g,'outarea');
[dummy,zorder]=sort(a);
zorder=flipud(zorder);
htlist=[];
bkc=get(gca,'Color');
for i=1:poc
    if pal{zorder(i),1}>0
        %plot outerarea
        [x,y]=get(g(zorder(i)),'x','y');
        ht=patch(x,y,pal{zorder(i),3});
        if vert
            set(ht,'Marker','.')
        end
        htlist=[htlist; ht];
        %plot holes
        h=get(g(zorder(i)),'holes');
        for j=1:get(g(zorder(i)),'nholes')
            patch(h(j).x,h(j).y,bkc);
        end
    else
        htlist=[htlist; NaN];
    end
end
axis equal
% Show legend
if leg==1
    [u,i,dummy]=unique(pal(zorder,2));
    uhtlist=htlist(i);
    [dummy,ix]=sort(cat(1,pal{zorder(i),1}));
    h=legend(uhtlist(ix(~isnan(uhtlist))),u(ix(~isnan(uhtlist))),0);
    set(h,'FontSize',8);
end
% Plot boundaing box from elle files
if pltbx==1
    bb=[bb;bb(1,:)];
    line(bb(:,1),bb(:,2),'Color','k');
end
    
