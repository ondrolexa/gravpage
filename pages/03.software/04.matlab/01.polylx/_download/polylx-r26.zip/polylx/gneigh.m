function r=gneigh(cm,ix,opt)
%GNEIGH Return indexes or cell array of indexes to adjacent grains.
% Choosen grains are passed in index vector ix. Connectivity matrix cm
% have to be constructed with GETCM. When opt is 0 the vector of unique
% indexes is return, otherwise cell array of index vectors corresponding to
% individual grains is returned.
% Syntax: r=gneigh(cm,ix,opt);

if nargin<3
    opt=1;
end

if nargin<2
    help gneigh
    r=[];
    return
end

for i=1:length(ix)
    r{i}=find(cm(ix(i),:));
end

if opt~=0
     r=unique(cat(2,r{:}));
end