function csdwrite(g,varargin)
%CSDWRITE Write CSD file for analysis with CSDCorrection of M. Higgins.
% Software could be downloaded from Michael D. Higgins homepage 
%   http://geologie.uqac.uquebec.ca/~mhiggins/
% Syntax: csdwrite(g);
%         csdwrite(g,filename);
%         csdwrite(g,filename,tomm);
% g is grain object(s)
% filename is name of file with .csd extension
% tomm is coefficient to transform actual units to mm. Default is 1

% GUI save file
if nargin<1
    help csdwrite
    return
end
%default scaling
tomm=1;

for i=1:nargin-1
    switch class(varargin{i})
        case 'char'
            filename=varargin{i};
            if isempty(strfind(filename,'.csd'))
                error('Filename must have .csd extension. Aborted');
            end
            ix=find(filename=='\');
            if isempty(ix);
                ix=0;
            end
            fnm=filename(ix(end)+1:end);
        case 'double'
            tomm=varargin{i};
        otherwise
            error('Wrong argument. Aborted');
    end
end

if ~exist('filename','var')
    [fnm, pth]=uiputfile({'*.csd','CSDCorrection file (*.csd)'},'Save CSD file');
    if fnm==0
        return
    end
    filename=[pth fnm];
end

if length(gplist(g))>1
    ix=gpsel(g);
    if isempty(ix)
        return
    end
else
    ix=1:length(g);
end

res=questdlg('Use total area of phases or convex hull ?','Total area','Phases Area','Convex Hull','Phases Area');

if strcmp(res,'Phases Area')
    tot=sum(get(g,'area'))*tomm^2;
else
    tt=acharea(g,1);
    tot=tt*tomm^2;
end

measure=questdlg('Which measure you want to use ?','Select measure','Maximum length','Ellipse Major axis','Ellipse Minor axis','Maximum length');

NEWLINE = sprintf('\r\n');

fid = fopen(filename ,'w');
if fid == (-1), error(['Could not write to file ' filename]); end

fwrite(fid,'<?xml version="1.0"?>','uchar'); fwrite(fid, NEWLINE, 'char');
fwrite(fid,'<CSD_data>','uchar'); fwrite(fid, NEWLINE, 'char');
fwrite(fid,'<CSDCorrections> 1.37 </CSDCorrections>','uchar'); fwrite(fid, NEWLINE, 'char');
fwrite(fid,'<sample_data>','uchar'); fwrite(fid, NEWLINE, 'char');
fwrite(fid,['<name>' fnm '</name>'],'uchar'); fwrite(fid, NEWLINE, 'char');
fwrite(fid,'<inter_project>Intersection</inter_project>','uchar'); fwrite(fid, NEWLINE, 'char');
fwrite(fid,'<short>1.00</short>','uchar'); fwrite(fid, NEWLINE, 'char');
fwrite(fid,'<inter>2.00</inter>','uchar'); fwrite(fid, NEWLINE, 'char');
fwrite(fid,'<long>3.00</long>','uchar'); fwrite(fid, NEWLINE, 'char');
fwrite(fid,'<fabric>M</fabric>','uchar'); fwrite(fid, NEWLINE, 'char');
fwrite(fid,'<quality>10</quality>','uchar'); fwrite(fid, NEWLINE, 'char');
fwrite(fid,'<orientation>P</orientation>','uchar'); fwrite(fid, NEWLINE, 'char');
fwrite(fid,['<roundness>' num2str(round(10*mean(get(g(ix),'roundness')))) '</roundness>'],'uchar'); fwrite(fid, NEWLINE, 'char');
fwrite(fid,['<phase_vol>' num2str(100*sum(get(g(ix),'area'))*tomm^2/tot) '</phase_vol>'],'uchar'); fwrite(fid, NEWLINE, 'char');
fwrite(fid,'<vpa_correction>correct</vpa_correction>','uchar'); fwrite(fid, NEWLINE, 'char');
fwrite(fid,'</sample_data>','uchar'); fwrite(fid, NEWLINE, 'char');
fwrite(fid,'<scale>','uchar'); fwrite(fid, NEWLINE, 'char');
fwrite(fid,'<scale_type>log10</scale_type>','uchar'); fwrite(fid, NEWLINE, 'char');
fwrite(fid,['<scale_val>' num2str(round(log(length(g(ix))))) '</scale_val>'],'uchar'); fwrite(fid, NEWLINE, 'char');
fwrite(fid,'</scale>','uchar'); fwrite(fid, NEWLINE, 'char');
fwrite(fid,'<size1>','uchar'); fwrite(fid, NEWLINE, 'char');
fwrite(fid,['<area>' num2str(tot) '</area>'],'uchar'); fwrite(fid, NEWLINE, 'char');
switch measure
    case 'Maximum length'
        fwrite(fid,'<data_type><col1>Max_len</col1></data_type>','uchar'); fwrite(fid, NEWLINE, 'char');
        dt=get(g(ix),'length');
    case 'Ellipse Major axis'
        fwrite(fid,'<data_type><col1>Ell_major</col1></data_type>','uchar'); fwrite(fid, NEWLINE, 'char');
        dt=aorten(g(ix));
    case 'Ellipse Minor axis'
        fwrite(fid,'<data_type><col1>Ell_minor</col1></data_type>','uchar'); fwrite(fid, NEWLINE, 'char');
        [dummy,dt]=aorten(g(ix));
end

for i=1:length(dt)
    fwrite(fid,['<outline><col1>' num2str(dt(i)*tomm) '</col1></outline>'],'uchar'); fwrite(fid, NEWLINE, 'char');
end

fwrite(fid,'</size1>','uchar'); fwrite(fid, NEWLINE, 'char');
fwrite(fid,'<notes>','uchar'); fwrite(fid, NEWLINE, 'char');
fwrite(fid,'<li>Data exported from PolyLX</li>','uchar'); fwrite(fid, NEWLINE, 'char');
fwrite(fid,'</notes>','uchar'); fwrite(fid, NEWLINE, 'char');
fwrite(fid,'</CSD_data>','uchar'); fwrite(fid, NEWLINE, 'char');

fclose(fid);
