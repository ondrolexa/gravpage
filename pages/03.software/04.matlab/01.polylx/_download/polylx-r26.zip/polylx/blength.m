function bc=blength(b,plt)
%BLENGTH Return cell array of Cumlength, CumLength fraction and number of boundaries.
% Syntax:  bc=blength(b,plt);
%    b   - structure contains margins
%  plt   - nonzero plt produce a pie graph

if nargin<2
 plt=0;
end
if ~isa(b,'boundary')
    error('First argument must be boundary object!');
end

% obtain phase list and number of phases
ph=btlist(b);
pf=length(ph);
leg=cell(pf,1);
bc=zeros(pf,3);
tl=sum(get(b,'cumlength'));

% Calculate length fractions

for i=1:pf
 ix=btsel(b,ph{i});
 cl=sum(get(b(ix),'cumlength'));
 bc(i,:)=[cl 100*cl/tl length(ix)];
 leg{i}=[ph{i} ' (' num2str(bc(i,3)) ')'];
end

if plt~=0
 ix=bc(:,2)<=2;
 if length(find(ix))>1
    pie([bc(~ix,2); sum(bc(ix,2))]);
    legend([leg(~ix);{['Others (' num2str(sum(bc(ix,3))) ')']}]);
 else
    pie(bc(:,2));
    legend(leg);
 end
end
bc=[{'Type' 'CumLength' '%' 'N'};ph num2cell(bc)];
