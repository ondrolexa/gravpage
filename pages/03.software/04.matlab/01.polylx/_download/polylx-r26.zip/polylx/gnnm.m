function [rs,theta]=gnnm(g)
%GNNM The nearest neighbour method to determine the orientation of strain ellipse and it's ellipticity.
% Syntax:  [rs,theta]=gnnm(g);

global xdat ydat

xdat=[];
ydat=[];

pts=[get(g,'xcentre') get(g,'ycentre')];
dist=[]; angl=[];
n=size(pts,1);

tri=delaunay(pts(:,1),pts(:,2));

for j=1:n
 [xi,yi]=find(tri==j);
 w=tri(xi,:);
 w=setdiff(w(:),j);
 dt=sqrt(sum((pts(w,:)-repmat(pts(j,:),length(w),1)).^2'));
 [mn,ix]=min(dt);
 dist=[dist;mn];
 angl=[angl;atan2(pts(w(ix),1)-pts(j,1),pts(w(ix),2)-pts(j,2))*180/pi];
end

ix=find(angl<0);
angl(ix)=angl(ix)+180;

%data kernel
for i=0:5:170;
 ix=find(angl>=i&angl<=(i+10));
 if ~isempty(ix)
  xdat=[xdat i+5];
  ydat=[ydat mean(dist(ix))];
 end
end
 
%fit ellipse
r=fminsearch('fitelf',[1 1 0],optimset('Display','off','TolFun',1e-8,'TolX',1e-8));
[dummy,y]=fitelf(r,0:1:180);
plot(angl,dist,'.');
hold on;
plot(xdat,ydat,'o');
plot(0:1:180,y);
hold off

clear xdat ydat

%correct values of fit
if abs(r(1))>abs(r(2))
 rs=abs(r(1)/r(2));
 theta=r(3);
else
 rs=abs(r(2)/r(1));
 theta=r(3)-90;
end
if theta<0
 theta=theta+180;
end

title(['Strain ratio:' num2str(rs) ' Orientation:' num2str(theta)]);
