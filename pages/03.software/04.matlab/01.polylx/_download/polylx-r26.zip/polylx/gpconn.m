function r=gpconn(g,b,varargin)
%GPCONN Return connectivity index for individual phases.
% Syntax: r=gpconn(g,b,options);
% Return number of all grains, number of isolated grains
% and bulk connectivity (0-1)
% options are passed as pairs of option name and option value:
% 'format'     ... 'cell'...return cell arrays ready for txtwrite. Other
%                  numeric arrays. Default 'cell'

if nargin<1
   help gpconn
   return
end

if nargin<2
    b=bmake(g);
end

% Process input arguments
opts.format='cell';
opts=parseargs(varargin,opts);

% Initialize
id=get(g,'id');
poc=length(id);
phlist=gplist(g);
r=[];

% Generate connectivity matrix
cm=getcm(g,b);

% Calculate connectivity for individual phases
for i=1:length(phlist)
    ix=gpsel(g,phlist{i});
    cmt=cm(ix,ix);
    poc=length(ix);
    if full(any(any(cmt)))
        vl=1:poc;
        clear pm;
        l=[];
        
        while (~isempty(vl))
            pvl=ggclust(cmt,vl(1));
            l=[l;length(pvl)];
            vl=setdiff(vl,pvl);
        end
        
        b0=length(find(l==1));
        bc=sum(l)-b0;
        cc=l(l~=1);
        cc(:,2)=cc(:,1)./(b0+bc);
        c=unique(cc(:,1));
        for k=1:length(c)
            c(k,2)=sum(cc(cc(:,1)==c(k),2));
        end
        r=[r;[poc b0 sum(c(:,2))]];
    else
        r=[r;[poc poc 0]];
    end
end

if strcmpi(opts.format,'cell')
    r=[{'Phase' 'N' 'Niso' 'Conn'};phlist num2cell(r)];
end


%---------------------- Functions ------------------------%
function v=ggclust(cm,vl)
% get grains cluster contain grain/s vl
i=1;
v=ggneigh(cm,vl);
top=length(v);
while i<=top
    u=setdiff(ggneigh(cm,v(i)),v);
    v=[v;u(:)];
    top=length(v);
    i=i+1;
end

function v=ggneigh(cm,vl)
% get grain/s neighbours
v=vl;
for i=1:length(vl)
    u=(find(cm(:,vl(i))==1));
    v=union(v,u);
end
v=v(:);
