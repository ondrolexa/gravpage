function stat=prose(a,varargin)
%PROSE Draw a rose diagram and calculate circular statistics.
% Syntax: stat=prose(a,options) or prose(g,options);
%  a    - vector of orientations or grain/boundary object
% options are passed as pairs of option name and option value:
% 'axial'  ... 1 - axial data, 0 - circular. Default 1
% 'apex'   ... acuteness of bar tip 0-1. Default 0.95
% 'nbins'  ... number of bins. Default 36.
% 'color'  ... Matlab plot style
% 'scale'  ... 0...counts, 1...percents, 2...probability density. Default 1
% 'align'  ... 0...zero aligned, 1...bin centre aligned. Default 0
% 'view'   ... 0...zero vertical, 1...zero horizontal. Default 0
% 'stat'   ... 1...plot meen direction and deviation 0...no plot. Default 1
% Output is stat vector of mean direction, circular standard deviation and
% circular variance, Rayleigh's uniformity test p-value a critical value


if nargin<1
    help prose
    return
end

% when grain object is passed
if isa(a,'grain')||isa(a,'boundary')
   a=get(a,'Orientation');
end 

% initialize defaults and parse arguments
opts.axial=1;
opts.apex=0.95;
opts.nbins=36;
opts.color='b';
opts.scale=1;
opts.align=0;
opts.view=0;
opts.stat=1;
opts=parseargs(varargin,opts);

%linearize, filter NaN's and inf's and modulate
a=a(:);
a=a(~isnan(a));
a=a(~isinf(a));
if opts.axial==1
    a=mod(a,180);
    tit='Axial data';
else
    a=mod(a,360);
    tit='Circular data';
end

% take first column of data
poc=size(a,1);

if opts.view==1
    a=mod(a+90,180);
end

if opts.axial==1
   ah=[a;a+180];
   a=2*a;
else
   ah=a;
end

binw=360/opts.nbins;
if opts.align==1
    bns=0:binw:360;
    t=histc(ah,bns);
    t(1)=t(1)+t(end);
    t=t(1:end-1);
else
    bns=0-binw/2:binw:360+binw/2;
    t=histc(ah,bns);
    t(1)=t(1)+t(end-1);
    t=t(1:end-2);
end

% recalculate on percents
switch opts.scale
    case 1
        t=100*(t/poc);
        xlab='Percents';
    case 2
        if opts.axial==1
            t=t/poc/(180/binw);
        else
            t=t/poc/(360/binw);
        end
        xlab='Probability';
    otherwise
        xlab='Counts';
end

tn=[];
rn=[];

for i=1:opts.nbins
    tn=[tn 0 rad(bns(i)) rad((bns(i)+bns(i+1))/2) rad(bns(i+1)) 0];
    rn=[rn 0 opts.apex*t(i) t(i) opts.apex*t(i) 0];
end

polar(tn,rn);
[x,y]=pol2cart(tn,rn);
patch(x,y,opts.color);

% Calculate resultant and circular statistics
rr=ones(size(a))'*exp(1i*rad(a));
md=mod(deg(atan2(imag(rr),real(rr))),360);
R=abs(rr)/length(a); % normalized resultant
s=deg(sqrt(log(1/R^2))); % circular deviation
cv=1-R; % circular variance
if opts.axial==1
    md=md/2;
    s=s/2;
end
Z=poc*R^2;
p=exp(-Z);
if poc<50
    p = p*(1+(2*Z-Z^2)/(4*poc)-(24*Z-132*Z^2+76*Z^3-9*Z^4)/(288*poc^2));
end

if nargout>0
    stat=[md s cv p Z];
end

if opts.view==1
    view(0,-90);
    xlabel([tit ' rose plot - MD:' num2str(md) ' CSD:' num2str(s) ' CV: ' num2str(cv) ' p: ' num2str(p) ' Z: ' num2str(Z)]);
    ylabel(xlab)
else
    view(90,-90);
    ylabel([tit ' rose plot - MD:' num2str(md) ' CSD:' num2str(s) ' CV: ' num2str(cv) ' p: ' num2str(p) ' Z: ' num2str(Z)]);
    xlabel(xlab)
end

% get radius of plot
ar=get(gca,'PlotBoxAspectRatio');
ar=ar(1)/ar(3);

if opts.stat==1
    % draw CSD part
    dd=linspace(md-s,md+s,18);
    xc=cos(rad(dd))*ar;
    yc=sin(rad(dd))*ar;
    h3=line(xc,yc);
    set(h3,'LineWidth',3,'Color','r');
    if opts.axial==1
        h4=line(-xc,-yc);
        set(h4,'LineWidth',3,'Color','r');
    end
    % draw mean direction
    x=cos(rad(md))*ar;
    y=sin(rad(md))*ar;
    if opts.axial==1
        h5=line([x;-x],[y;-y]);
        set(h5,'LineWidth',2,'Color','r');
    else
        h5=line([x;0],[y;0]);
        set(h5,'LineWidth',2,'Color','r');
    end
end