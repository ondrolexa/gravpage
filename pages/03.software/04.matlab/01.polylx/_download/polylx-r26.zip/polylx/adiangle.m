function da=adiangle(g,b)
%ADIANGLE Return cell array of measurement of dihedral angles.
% Syntax: da=adiangle(g,b);
%         da=adiangle(g); Boundaries will be generated with BMAKE
% g are grain and b are boundary objects
% Output is cell array da of vectors of dihedral angles with number of rows
% equal to number of boundary types and number of columns equal to number
% of phases. Angle is measured only on triple junctions in phase which
% share with boundary one point. In this example ANGLE will be placed in da
% in row equal to position of boundary type A-B in btlist and in column
% equal to position of phase C in gplist. Note that row and column index is
% shifted because there are column and row headers. To plot histogram use
% routine PDIANGLEHIST.
%
%
%         A         / 
%                  /  Phase=
%  --type=row-----  ANGLE      C
%                  \  =column
%         B         \
%

% Ondrej Lexa (c) 2007

%Check
if nargin<1
    help adiangle;
    return;
end
if ~isa(g,'grain')
    help adiangle
    da={};
    return
end
if nargin<2
    b=bmake(g);
end
if ~isa(b,'boundary')
    help adiangle
    da={};
    return
end

% Initialize
co=zeros(0,2);
cn=sparse([],[],[],1,1,0);

poc=length(b);
h=fwaitbar(0,'Building boundary tree...');
for i=1:poc
    x=get(b(i),'x');
    y=get(b(i),'y');
    nfrom=find((co(:,1)==x(1))&(co(:,2)==y(1)));
    if isempty(nfrom)
        co=[co;x(1) y(1)];
        nfrom=size(co,1);
    end
    nto=find((co(:,1)==x(end))&(co(:,2)==y(end)));
    if isempty(nto)
        co=[co;x(end) y(end)];
        nto=size(co,1);
    end
    cn(nfrom,nto)=i;
    cn(nto,nfrom)=i;
    fwaitbar(i/poc,h);
end
close(h)

bl=btlist(b);
bln=length(bl);
gl=gplist(g);
gln=length(gl);
da=cell(bln,gln);

h=fwaitbar(0,'Calculating...');
for i=1:poc
   [tj,dummy]=find(cn==i);
   if length(tj)==2
       for j=1:2
           nb=setdiff(full(cn(tj(j),find(cn(tj(j),:)))),i); % find attached boundaries
           if length(nb)==2
               [xs1,ys1]=eqpoints(get(b(i),'x'),get(b(i),'y'),100);
               vv=[xs1(2:end-1)-co(tj(j),1) ys1(2:end-1)-co(tj(j),2)]';
               w=sqrt(min(sum(vv.^2))./sum(vv.^2));
               rv1=sum((vv.*[w;w]),2);
               aa1=atan2(rv1(2),rv1(1))*180/pi;
               [xs2,ys2]=eqpoints(get(b(nb(1)),'x'),get(b(nb(1)),'y'),100);
               vv=[xs2(2:end-1)-co(tj(j),1) ys2(2:end-1)-co(tj(j),2)]';
               w=sqrt(min(sum(vv.^2))./sum(vv.^2));
               rv2=sum((vv.*[w;w]),2);
               aa2=atan2(rv2(2),rv2(1))*180/pi;
               [xs3,ys3]=eqpoints(get(b(nb(2)),'x'),get(b(nb(2)),'y'),100);
               vv=[xs3(2:end-1)-co(tj(j),1) ys3(2:end-1)-co(tj(j),2)]';
               w=sqrt(min(sum(vv.^2))./sum(vv.^2));
               rv3=sum((vv.*[w;w]),2);
               aa3=atan2(rv3(2),rv3(1))*180/pi;
               [dummy,ix]=sort([aa1 aa2 aa3]);
               switch find(ix==1)
                   case 1
                       ang=max(aa2,aa3)-min(aa2,aa3);
                   case 2
                       ang=360+min(aa2,aa3)-max(aa2,aa3);
                   case 3
                       ang=max(aa2,aa3)-min(aa2,aa3);
               end
               bx=strmatch(get(b(i),'type'),bl);
               % find grain in which angle is measured
               gr=[get(b(nb),'ida');get(b(nb),'idb')];
               [dummy,un,dummy]=unique(gr);
               df=setdiff(1:4,un);
               if length(df==1) % do not use degenerate case
                   gx=strmatch(get(g(gr(df)),'phase'),gl);
                   da{bx,gx}=[da{bx,gx} ang];
               end
           end
       end
   end
   fwaitbar(i/poc,h);
end
close(h)

% Collate labels
da=[{'DIANGLE'} gl';bl da];

function [xs,ys]=eqpoints(x,y,n)
% computes equally spaced points on a polyline.

xs=[];
ys=[];

% calculate cumulative length
cl=[0;cumsum(sqrt(diff(x).^2+diff(y).^2))];
j=1;
for i=1:n
    pp=((i-1)*cl(end))/(n-1);
    tt=find(cl>pp);
    if isempty(tt)
        ix=length(cl)-1;
    else
        ix=tt(1)-1;
    end
    xs=[xs;((cl(ix+1)-pp)*x(ix)+(pp-cl(ix))*x(ix+1))/(cl(ix+1)-cl(ix))];
    ys=[ys;((cl(ix+1)-pp)*y(ix)+(pp-cl(ix))*y(ix+1))/(cl(ix+1)-cl(ix))];
end


