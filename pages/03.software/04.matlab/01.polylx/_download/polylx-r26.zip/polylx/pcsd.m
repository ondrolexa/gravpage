function [a,n0]=pcsd(g,varargin)
%PCSD Routine to plot CSD diagram after Peterson,1996.
% Syntax: [alpha,n0]=pcsd(g,options);
% options are string evaluated by function (these are default values):
% 'tomm'        ... factor to convert actual units into mm. Default 1
% 'scalefactor' ... Scale factor. Default 1.269
% 'beta'        ... factor of degree of spatial orientation. Default 0.4286
% 'gama'        ... intercept factor. Default 0.833
% 'area'        ... Total area of measurements. Default total area of g.

% Ondrej Lexa 2001

if nargin<1
    help pcsd;
    return;
end

if ~isa(g,'grain')
    help gdmeth;
    return;
end

% Process input arguments
opts.tomm=1;
opts.scalefactor=1.269;
opts.beta=0.4286;
opts.gama=0.833;
opts.area=sum(get(g,'area'));
opts=parseargs(varargin,opts);

%select phase(s) to analyze
if length(gplist(g))>1
   ix=gpsel(g);
   if isempty(ix)
      return
   end
   g=g(ix);
end
%obtain feret diameters
f=get(g,'feret');
%correct units to mm
f=f*opts.tomm;
%censor outliers data  !!!!!
f=f(f/exp(mean(log(f)))<=7);
%f=fxS
f=f*opts.scalefactor; %for spheres
%create bins
nb=ceil(1+7*log10(length(f))); % Try this...Hooops
dl=(2*max(f))/(2*(nb-1)+1);
bins=(0:dl:nb*dl)';
%count bins
cnt=histc(f,bins);
%calculate cumulative number of data
n2d=flipud(cumsum(flipud(cnt)))/opts.area/opts.tomm/opts.tomm;  %units must be same
lt=bins(2:end-1);
np=n2d(2:end-1)./lt;  %N'
p=polyfit(lt,log(np),1);
alfa=-1/p(1);
%iterate
dalfa=1;
cc=0;
while (dalfa>0.00000001)&&(cc<20)
    ln3d=log(np)+log(opts.gama)-opts.beta*alfa./lt;
    p=polyfit(lt,ln3d,1);
    nalfa=-1/p(1);
    dalfa=abs(alfa-nalfa);
    alfa=nalfa;
    cc=cc+1;
end
if cc==20, disp('Nonstable solution of alpha'); end
dn3d=diff(exp(ln3d));
n=-dn3d/dl;
l=lt(1:end-1)+dl/2;
%plot
plot(l,log(n),'k.');
ka=axis;
hold on
%fit chosen data
title('Click the polygon enclosing data for linear regression:');
[xx,yy]=getpoly;
if length(xx)>2
   ix=inpolygon(l,log(n),xx,yy);
else
   ix=1:length(l);
end
if isempty(find(ix)), ix=1:length(l); end  % take all
plot(l(ix),log(n(ix)),'ko');
p=polyfit(l(ix),log(n(ix)),1);
y=polyval(p,l);
plot(l,y);
axis(ka)
hold off
a=-1/p(1);
n0=exp(p(2));
title(['CSD Plot   alfa=' num2str(a) 'mm  n0=' num2str(n0) 'mm-4'])
xlabel('Size (mm)');
ylabel('Population density ln(n) mm-4)');
