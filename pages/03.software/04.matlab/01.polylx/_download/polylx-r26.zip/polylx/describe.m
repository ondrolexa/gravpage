function res=describe(g,varargin)
%DESCRIBE Return descriptive statistics of chosen measurement.
% Number, mean, std, geomean, geostd, min, qtile1, median, qtile3, max
% and trimean is calculated for individual phases or boundary types.
% Syntax:  dsc=describe(g,options);
%  g      - grain/boundary objects
% options are passed as pairs of option name and option value:
% 'prop'       ... properties of grain/boundary object to dump.
% 'format'     ... 'cell'...return cell arrays ready for txtwrite. Other
%                  numeric arrays. Default 'cell'

% Ondrej Lexa (c) 2003

if nargin<1
   help describe
   return
end

% Process input arguments
opts.prop='';
opts.format='cell';
opts=parseargs(varargin,opts);

if isempty(opts.prop)
    if isa(g,'grain') | isa(g,'boundary')
        tlist=get(g);
        [typa,valid]=listdlg('PromptString','Select measurement:','SelectionMode','Single','ListString',tlist);
    else
        error('First argument must be grain/boundary object.');
    end
    if valid~=1
        disp ('Aborted.')
        return
    end
else
    tlist={opts.prop};
    typa=1;
end
ph=gplist(g);
pf=length(ph);
dsc=[];

for i=1:pf
   f=get(g(ph{i}),tlist{typa});
   dsc=[dsc [length(f);mean(f);std(f);exp(mean(log(f)));exp(std(log(f)));min(f);percentil(f,25);median(f);percentil(f,75);max(f);(percentil(f,25)+2*percentil(f,50)+percentil(f,75))/4]];
end

if strcmpi(opts.format,'cell')
    res=[{tlist{typa};'N';'Mean';'Std';'Geomean';'Geostd';'Min';'Qtile1';'Median';'Qtile3';'Max';'Trimean'} [ph';num2cell(dsc)]];
else
    res=dsc;
end
