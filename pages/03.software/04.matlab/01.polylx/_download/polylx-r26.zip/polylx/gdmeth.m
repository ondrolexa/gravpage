function [obt,expn]=gdmeth(g,varargin)
%GDMETH Return results of Crystal density method (Kretz 1969).
% Syntax:  [obt,expn]=gdmeth(g,options)
%   expn - number of expected grains in each cell
%    obt - matrix of observed number of grain in each cell
% options are string evaluated by function (these are default values):
% 'xgrid'       ... number of division on x side. Default 15
% 'ygrid'       ... number of division on y side. Default 15
% 'plot'        ... 0 ... no plot, 1 ... just points,
%                   2 ... plot points and density contours. Default
% 'ncont'       ... number of contours. Defaut 10
% 'smooth'      ... degree of smoothing for contour plotting. Default 2
% 'pointsize'   ... point size. Dafault 6
% 'poitcolor'   ... point color and style. Default 'b.'

% 2001 (c) Ondrej Lexa

if nargin<1
    help gdmeth;
    return;
end

if ~isa(g,'grain')
    help gdmeth;
    return;
end 

% Process input arguments
opts.xgrid=15;
opts.ygrid=15;
opts.plot=2;
opts.ncont=10;
opts.smooth=2;
opts.pointsize=6;
opts.pointcolor='b.';
opts=parseargs(varargin,opts);

% initialize x a y coordinates of grains and determine bounding rectangle
gx=get(g,'xcentre');
gy=get(g,'ycentre');

% calculate counting grid
[dummy,dummy,obt]=dengrid(gx,gy,0,opts.xgrid,opts.ygrid);
expn=length(g)/(opts.xgrid*opts.ygrid);

% plotting
if opts.plot>1
   [x,y,tt]=dengrid(gx,gy,opts.smooth,opts.xgrid,opts.ygrid);
   contourf(x,y,tt,linspace(0,max(max(obt)),opts.ncont));
   colormap(flipud(gray));
   colorbar;
   hold on;
end
if opts.plot>0
   h1=plot(gx,gy,opts.pointcolor);
   set(h1,'MarkerSize',opts.pointsize);
   hold off
end

% Calculate chi-square value
if exist('chi2cdf','file')==2
 chis=sum(sum((obt-expn).^2/expn));
 pp=chi2cdf(chis,opts.xgrid*opts.ygrid-1);
 if pp>0.5
  disp(['Grains are not randomly distributed at significance level ' num2str(pp*100)]);
   else
  disp(['Grains are randomly distributed at significance level ' num2str(100-pp*100)]);
 end
end

