function [sd,la,sa,lao,sao]=asurfor(g,opt,plt)
%ASURFOR Return results of SURFOR analysis after R.Panozzo.
% Surface projection function. Note that for grains values of projection are divided by 2
% to be comparable with PAROR and with geometry of grains.
% Syntax: [sd,la,sa,lao,sao]=asurfor(g,opt,plt);
% g can be grain and boundary object(s)
%    opt - 0 (default) do not include holes into calculations
%          1 include holes into calculations
%          2 fit best ellipse projection (SLOW!!!) and do not include holes into calculations
%          3 fit best ellipse projection (SLOW!!!) and include holes into calculations
% Plot option plt 1..plot crosses 2..plot ellipses 3..ellipses and crosses

if nargin<3
 plt=0;
end

if nargin<2
 opt=0;
end

%Initialize
n=size(g,2);
sd=zeros(n,180); la=zeros(n,1); sa=la; lao=la; sao=la;

nn=[sin(rad(1:180));cos(rad(1:180))];

h=fwaitbar(0,'Calculating...');
for ii=1:n
 x=diff(get(g(ii),'x'));
 y=diff(get(g(ii),'y'));
 
 if bitget(opt,1)==1&&isa(g,'grain')
    q=get(g(ii),'holes');
    for jj=1:get(g(ii),'nholes');
       x=[x;diff(q(jj).x)];
       y=[y;diff(q(jj).y)];
    end
 end
  
 ff=[x y]*nn;
 if size(ff,1)>1
    f=(sum(abs(ff)))';
 else
    f=abs(ff)';
 end
 
 if isa(g,'grain')
    f=f/2;
 end
 
 if bitget(opt,2)==1
    [f,lat,sat,laot,saot]=fitpd(f); % fit ellipse
    laot=mod(laot,180);
    saot=mod(saot,180);
    lat=2*lat;
    sat=2*sat;
 else
    [sat,saot]=min(f); % just analyze (fast)
    [lat,laot]=max(f);
 end
 
 
 sd(ii,:)=f;
 sa(ii)=sat;
 sao(ii)=saot;
 la(ii)=lat;
 lao(ii)=laot;

 fwaitbar(ii/n,h);
end

% turn 180 to 0
lao(lao==180)=0;
sao(sao==180)=0;

close(h)

if plt~=0
    if bitget(plt,1)==1
        pcross(la/2,sa/2,lao,[get(g,'xcentre') get(g,'ycentre')],'k');
    end
    if bitget(plt,2)==1
        pellipse(la/2,sa/2,lao,[get(g,'xcentre') get(g,'ycentre')],'k');
    end
end



