function gfry(g)
%GFRY Fry's  method to detemine the strain ellipse.
% Syntax: gfry(g);

x=get(g,'xcentre');
y=get(g,'ycentre');
poc=length(x);

tri=delaunay(x,y);
nnd=[];
for j=1:poc
 [xi,dummy]=find(tri==j);
 w=tri(xi,:);
 w=setdiff(w(:),j);
 dt=sqrt(sum(([x(w) y(w)]-repmat([x(j) y(j)],length(w),1)).^2'));
 nn=min(dt);
 nnd=[nnd;nn];
end
mn=mean(nnd);

xnew=[];
ynew=[];
h=fwaitbar(0,'Please wait for computations to be done');
for i=1:poc
 dxx=x-x(i);
 dyy=y-y(i);
 w=find((dxx.^2+dyy.^2)<12*mn^2);
 xnew=[xnew;dxx(w)];
 ynew=[ynew;dyy(w)];
 fwaitbar(i/length(x),h);
end
close(h);

clf
hold on
plot(xnew,ynew,'r.')
plot(0,0,'k.')
title('Fry''s Plot');
set(gca,'xlim',[min(xnew),max(xnew)],...
   'ylim',[min(ynew),max(ynew)]);
axis equal
