function bt=btlist(b)
%BTLIST Return unique list (cell array) of types of boundary objects.
% Syntax: bt=btlist(b)

if isa(b,'grain')
   bt=gplist(b);
   return
end

bt=unique(get(b,'type'));
