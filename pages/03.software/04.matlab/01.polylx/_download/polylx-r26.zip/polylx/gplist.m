function ph=gplist(g)
%GPLIST Return unique list (cell array) of phases of objects g.
% Syntax: ph=gplist(g);

if isa(g,'boundary')
   ph=btlist(g);
   return
end

ph=unique(get(g,'phase'));
