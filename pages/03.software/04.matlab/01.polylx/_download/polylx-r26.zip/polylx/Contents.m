% PolyLX Toolbox Release 2
% Version 2.6 18-Feb-2010
%
% Grain/boundary manipulation commands
%   bgsel        - Boundary grain select. Return object index vector of boundaries beetween grains g.
%   bmake        - Routine to construct boundaries (boundary objects) from grain objects.
%   bsmake       - Routine to construct boundaries segments objects from grain objects.
%   boundary     - Create boundary object.
%   btlist       - Return unique list (cell array) of types of boundary objects.
%   btsel        - Boundary type select. Return object index vector.
%   gbcrop       - Crop area from boundary and grain objects.
%   get          - Get properties of grain/boundary objects.
%   getcm        - Return connectivity matrix
%   getidx       - Return index vector for subset of objects gsub for objects g, so g(ix)=gsub.
%   getsel       - Return indexes of actual selection or modify selection.
%   ggincl       - Get grains which are inclusions of choosen grains.
%   gneigh       - Return indexes or cell array of indexes to adjacent grains.
%   gnsearch     - Return grains of phase ph1 which share boundary with phase ph2.
%   grain        - Create grain object.
%   gplist       - Return unique list (cell array) of phases of objects g.
%   gpsel        - Grain phase select. Return indexes into objects array with phase(s) ph.
%   gpclust      - Return index to interconnected phase cluster.
%   gsetphase    - Change phase name of choosen grains.
%   gsmooth      - Smooth outlines of grain objects.
%   gtrans2d     - Transform grain objects using transformation matrix tm.
%   ssicreate    - Routine to generate anti-clustered circular grains.
%
% Analysis commands
%   acharea      - Calculate area, perimeter, centroid of convex hull and bounding box of grains or boundaries.
%   adiangle     - Return cell array of measurement of dihedral angles.
%   aorten       - Return results of Ellipse fitting using orientation tensor.
%   aorten2      - Return parameters of orientation tensor of decomposed grain/boundary.
%   aortentot    - Return results of Ellipse fitting using bulk orientation tensor.
%   aparis       - Return PARIS function and factor after Panozzo&Hurlimann, 1983.
%   aparis2      - Return paris and area factors after Heilbronner&Keulen, 2006.
%   aparor       - Return results of PAROR analysis after R.Panozzo.
%   arfphi       - Estimation of strain ratio from rf/phi modelling.
%   arfphiw      - Estimation of weighted strain ratio from rf/phi modelling.
%   astrip       - Determine a 3D sphere diameter distribution from 2d grainsize. Old.
%   astrip2      - Determine a 3D sphere diameter distribution from 2d grainsize.
%   asurfor      - Return results of SURFOR analysis after R.Panozzo.
%   blength      - Return cell array of Cumlength, CumLength fraction and number of boundaries.
%   cameth       - Direct Contact area method (Kretz 1969).
%   cfmeth       - Direct Contact frequency method (Kretz 1969).
%   clmeth       - Direct Contact length method (Kretz 1969).
%   describe     - Return descriptive statistics of chosen measurement.
%   garea        - Return area, area fraction, number of grains and average diameter
%   gconvhull    - Transform each grain into grain defined by convex hull of original grain.
%   gdmeth       - Return results of Crystal density method (Kretz 1969).
%   gdtnnm       - The Delaunay triangulation nearest neighbor method to detemine the strain.
%   geparor      - Exact paror. Long axis is in direction onto which projection is maximum.
%   getoutlier   - Rosner's many-outlier test for detection of outliers in data.
%   gfitel       - Stable Direct Least Squares Ellipse Fit to grains geometry.
%   gfry         - Fry's  method to detemine the strain ellipse.
%   gharfer      - Return Mean matrix of inertia and square root of eigenvalues ratio and directional parameters.
%   gminel       - Finds the minimum volume enclosing ellipse (MVEE) for grain or boundary.
%   gnna         - Return index of nearest-neighbour statistics.
%   gnnm         - The nearest neighbour method to determine the orientation of strain ellipse and it's ellipticity.
%   gpconn       - Return connectivity index for individual phases.
%
% Plotting commands
%   paxdev       - Plot histogram of projection axes deviation from orthogonality.
%   peigen       - Plot bulk eigenvalues ratio vs. choosen property of grains/boundaries.
%   pellipse     - Plot ellipses to the current plot.
%   pboxplot     - Routine to plot boxplot of measuremnts of individual phases/types.
%   pcross       - Adds axes of ellipses to the current plot.
%   pcsd         - Routine to plot CSD diagram after Peterson,1996.
%   pdianglehist - Plot histogram of chosen dihedral angles.
%   pdistplot    - Plot normal or lognormal probability plot.
%   pgsize       - Routine to plot grain size (EAD/feret) histogram with area fraction histogram.
%   phist        - Plot histogram and calculate statistics.
%   phistlog     - Plot histogram, lognormal distibution fit and calculate statistics.
%   phistnorm    - Plot histogram, normal distibution fit and calculate statistics.
%   phistw       - Plot weighted histogram.
%   plot         - Plot grains/boundaries.
%   prfphi       - Make Rf/phi plot.
%   prose        - Draw a rose diagram and calculate circular statistics.
%   prosew       - Draw a weighted rose diagram and calculate circular statistics.
%   xyplot       - XY plot with fitted linear regression.
%
% Import/Export and file management commands
%   csdwrite     - Write CSD file for analysis with CSDCorrection of M. Higgins.
%   dump         - Dump grain/boundary properties to cell array.
%   dxfread      - Read grain geometry from ASCII Drawing Interchange (DXF) Files R12.
%   elleread     - Read grain geometry and attributes from ELLE inputfile.
%   jmlread      - Read grain geometry from JUMP GML file.
%   mkflist      - Make list (cell array) of chosen files for batch processing.
%   roiread      - Read grain geometry from ImageJ ROI files.
%   shp2db       - Routine to export several shapefiles into database.
%   shp2mat      - Routine to convert several shapefiles into MAT-files for fast loading.
%   shpread      - Read grain/boundary geometry from ArcView shapefile.
%   svgwrite     - Write SVG (Scalable Vector Graphics) file suitable for web.
%   sxmread      - SXREAD Read grain geometry from Image SXM XY coordinates file.
%   txtwrite     - Write ASCII delimited file with column headers.
%
% Database manipulation commands
%   dbattrib     - Read attributes of samples from database.
%   dbdelete     - Delete sample(s) in database.
%   dblist       - Show informations about stored data in database.
%   dbread       - Read a grain geometry from database.
%   dbreadphase  - Read all grains of choosen phase from database.
%   dbreadtype   - Read all boundaries of choosen type from MySQL database.
%   dbselect     - Select samples and their attributes from database.
%   dbwrite      - Write grain object into database.
%
% GUI commands
%   genct        - Generate color table for grain/boundary objects based on phase/type.
%   idplot       - Plot selectable grain objects g on active figure.
%   makepal      - Routine to generate universal color palette for plot.
%   polygui      - Simple GUI to explore basic characteristics and produce simple graphics.
%
% Copyright (c) 2000-2010 by Ondrej Lexa
% Institute of Petrology and Structural Geology, Charles University,
% Prague, Czech Republic
