function phistw(a,w,varargin)
%PHISTW Plot weighted histogram.
% Syntax: phistw(a,w,options);
% a could be grain/boundary object, column vector or cell array of column vectors
% for grouped plot. EAD for grain and CumLength for boundary is used by default.
% w is vector of weights for data. Must have same size as data.
% options are passed as pairs of option name and option value:
% 'nbins'      ... number of bins.
% 'barwidth'   ... bar width. Default 1
% 'axislimits' ... [xmin xmax]. Default limits are minimum and maximum from data
% 'color'      ... its Matlab color style for single plot ot pallete for grouped.
%                  Default is 'b' or selection from jet palette.
% 'xlabel'     ... Label of x axis. Default based on input.

if nargin<1
    help phistw;
    return;
end

% when grain object is passed
if isa(a,'grain')
   a=get(a,'ead');
end 
if isa(a,'boundary')
    a=get(a,'CumLength');
end
% check cell array for grouped plot
if isa(a,'cell')
    ngrp=length(a);
    grp=a;
else
    ngrp=1;
    grp={a};
end
if nargin<2
    for i=1:ngrp
        w{i}=ones(size(grp{i}));
    end
end
if ~isa(w,'cell')
    w={w(:)};
end

if ~isequal(size(grp),size(w))
    error('Size of weights and data must be same.')
end

for i=1:ngrp
    if ~isequal(size(grp{i}),size(w{i}))
        error(['Number of weights and data for dataset ' num2str(i) ' must be same.'])
    end
    %linearize and filter NaN's anf Inf's
    a=grp{i}(:);
    ix=~isnan(a);
    a=a(ix);
    w{i}=w{i}(ix);
    ix=~isinf(a);
    a=a(ix);
    w{i}=w{i}(ix);
    poc(i)=size(a,1);
    mini(i)=min(a);
    maxi(i)=max(a);
end

% Process input arguments
opts.axislimits=[min(mini)-0.05*(max(maxi)-min(mini)) max(maxi)+0.05*(max(maxi)-min(mini))];
opts.nbins=ceil(1+7*log10(mean(poc)));
opts.barwidth=1;
opts.xlabel=inputname(1);
if isempty(opts.xlabel)
    opts.xlabel='x';
end
if ngrp>1
    opts.color=jet(ngrp);
else
    opts.color='b';
end
opts=parseargs(varargin,opts);
% Recalculate nbins, mini and maxi when axislimits specified
for i=1:ngrp
    a=grp{i}(:);
    a=a(~isnan(a));
    a=a(~isinf(a));
    a=a(a>=opts.axislimits(1)&a<=opts.axislimits(2));
    poc(i)=size(a,1);
end
opts.nbins=ceil(1+7*log10(mean(poc)));
opts=parseargs(varargin,opts);

% define bins
h=linspace(opts.axislimits(1),opts.axislimits(2)+10*eps,opts.nbins+1);
binw=(max(maxi)-min(mini))/opts.nbins;

% calculate frequancies
n=[];
for i=1:ngrp
    a=grp{i}(:);
    a=a(~isnan(a));
    a=a(~isinf(a));

    [tn,ixb]=histc(a,h);
    
    % Use weigths
    for j=1:opts.nbins
        tn(j)=sum(w{i}(ixb==j));
    end
    
    n=[n tn];
end
hh=bar(h+(h(2)-h(1))/2,n,opts.barwidth,'grouped');
for i=1:ngrp
    set(get(hh(i),'children'),'facecolor',opts.color(i,:));
end

% Correct x limits
ax=axis;
ax(1)=opts.axislimits(1);
ax(2)=opts.axislimits(2);
axis(ax);
  
ylabel('Cumulative weight');
xlabel(opts.xlabel);
