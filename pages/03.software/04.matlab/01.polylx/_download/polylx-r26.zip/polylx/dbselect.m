function [sample,att,attnames]=dbselect(fields)
%DBSELECT Select samples and their attributes from database.
% Syntax: sample=dbselect
%         [sample,att,attnames]=dbselect
%         [sample,att]=dbselect(attnames)
%   sample is cell array of sample names
%   att is cell array of attributes
%   attnames is cell array of attribute names

%Check connection
if dbconnect
    sample={};
    label={};
    x=[];
    y=[];
    res=dbcommand(['SELECT name FROM samples ORDER BY name']);
    if isempty(res)
        disp('No samples in open database. Aborting.');
    else
        [sel,ok] = listdlg('ListString',res(1,:),'Name','Select samples');
        if ok~=0
            sample=res(1,sel)';
            if nargout>1
                if nargin<1
                    [att,attnames]=dbattrib;
                else
                    [att,attnames]=dbattrib(fields);
                end
                att=att(sel,:);
            end
        end
    end
    dbclose;
end
