function [la,sa,lao,sao,co]=gminel(g,plt)
%GMINEL Finds the minimum volume enclosing ellipse (MVEE) for grain or boundary.
% Syntax: [la,sa,lao,sao,co]=gminel(g,plt);
% g can be grain or boundary object(s)
% Plot option plt 1..plot crosses 2..plot ellipses 3..ellipses and crosses

% The solver is based on Khachiyan Algorithm and modiefied after
% Nima Moshtagh (nima@seas.upenn.edu)
% University of Pennsylvania
% http://www.mathworks.com/matlabcentral/fileexchange/9542

if ~isa(g,'grain')
    help gminel
    return
end

if nargin<2
 plt=0;
end

poc=length(g);

h=fwaitbar(0,'Calculating...');

for ii=1:poc
    [x,y]=get(g(ii),'x','y');
    ix=convhull(x,y);
    x=x(ix(1:end-1));
    y=y(ix(1:end-1));
    P=[x';y'];
    N=length(x);
    Q=[P;ones(1,N)];
    count=1;
    err=1;
    u=(1/N)*ones(N,1);          % 1st iteration
    tolerance=get(g(ii),'length')/1000;
    % Khachiyan Algorithm
    % -----------------------------------
    it=0;
    while (err>tolerance)&(it<10000) % to be safe
        X=Q*diag(u)*Q';       % X = \sum_i ( u_i * q_i * q_i')  is a (d+1)x(d+1) matrix
        M=diag(Q'*inv(X)*Q);  % M the diagonal vector of an NxN matrix
        [maximum j]=max(M);
        step_size=(maximum-3)/(3*(maximum-1));
        new_u=(1-step_size)*u ;
        new_u(j)=new_u(j)+step_size;
        count=count+1;
        err=norm(new_u - u);
        u=new_u;
        it=it+1;
    end
    U=diag(u);
    A=0.5*inv(P*U*P'-(P*u)*(P*u)');
    co(ii,:)=u'*P';
    [e1,e2]=eig(A);
    la(ii,1)=2/sqrt(e2(1,1));
    sa(ii,1)=2/sqrt(e2(2,2));
    lao(ii,1)=180*atan(e1(1,1)/e1(2,1))/pi;
    if lao(ii,1)<0
        lao(ii,1)=lao(ii,1)+180;
    end
    if lao(ii,1)<90
        sao(ii,1)=lao(ii,1)+90;
    else
        sao(ii,1)=lao(ii,1)-90;
    end
    fwaitbar(ii/poc,h);
end
close(h)

if plt~=0
 if bitget(plt,1)==1
  pcross(la/2,sa/2,lao,co,'k');
 end
 if bitget(plt,2)==1
  pellipse(la/2,sa/2,lao,co,'k');
 end
end
