function pgsize(g,prop)
%PGSIZE Routine to plot grain size (EAD/feret) histogram with area fraction histogram.
% Syntax: pgsize(g,prop);
%   g   - grain objects
% prop  - property EAD(default),feret
%
% Ondrej Lexa 2003

if nargin<2
    prop='EAD';
end
if ~isa(g,'grain')
    disp('This routine works only with grain objects');
    help pgsize
    return
end

poc=length(g);

nb=ceil(1+7*log10(poc));
f=log10(get(g,prop));
a=get(g,'area');
tota=sum(a)/100;

w=(max(f)-min(f))/(nb-1);
ed=linspace(min(f)-w/2,max(f)+w/2,nb+1);
ec=linspace(min(f),max(f),nb);

[n,ix]=histc(f,ed);
n=100*n(1:end-1)/poc;
ca=[];
for j=1:length(n)
    ca=[ca;sum(a(ix==j))/tota];
end
bar(ec,[n ca],1);
xlabel('Log10 grain size (EAD)');
ylabel('%');
title([num2str(poc) ' grains']);

legend({'EAD frequency' 'Area fraction'}) 
 
