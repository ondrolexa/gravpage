function r=gpclust(g,b,ix)
%GPCLUST Return index to interconnected phase cluster.
% Syntax:  r=gclust(g,b,ix);
%   ix - index of seed(s) for interconnected cluster

% Ondrej Lexa

if nargin<3
    help gpclust
    return
end

cm=getcm(g,b);
r={};
for i=1:length(ix)
    iix=ix(i);
    go=1;
    ph=get(g(iix),'phase');
    while go==1
        nnb=gneigh(cm,iix);
        nnb=nnb(gpsel(g(nnb),ph));
        nix=union(iix,nnb);
        if isempty(setdiff(nix,iix))
            go=0;
        end
        iix=nix;
    end
    r{i}=iix;
end

if length(ix)==1
    r=r{i};
end