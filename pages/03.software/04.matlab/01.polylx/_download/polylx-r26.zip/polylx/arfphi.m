function [rs,chitest,Isym]=arfphi(rf,lao,nsteps)
%ARFPHI Estimation of strain ratio from rf/phi modelling.
% using instantaneous deformation approach
% Syntax: [rs,chites,Isym]=arfphi(ar,ang,[nsteps]) or arfphi(g,[nsteps]);
%  ar     - axial ratios Rf
%  ang    - axes orientations phi
%  nsteps - number of iterations. Default 50
%  g      - grain/boundary object
% Output:
%  rs     - estimated strain ratio
%  chi    - value of chi-squared test for estimated strain and value for
%           0.95 confidence
%  Isym   - Index of symmetry

% Ondrej Lexa

if nargin<3
    nsteps=[];
end

if nargin<2
    lao=[];
end

% when grain object is passed
if isa(rf,'grain')
    g=rf;
    nsteps=lao;
    rf=get(g,'AxialRatio');
    lao=get(g,'Orientation');
end

if isempty(nsteps)
    nsteps=50;
end


%Calculate vector mean
xr=sum(sin(rad(2*lao)));
yr=sum(cos(rad(2*lao)));
mdang=deg(atan2(xr,yr))/2;    % mean direction
phi=lao-mdang;
ixxx=find(phi>90);
phi(ixxx)=phi(ixxx)-180;
ixxx=find(phi<-90);
phi(ixxx)=phi(ixxx)+180;
clf;
ppp=get(gcf,'Position');
ppp([1 3])=[10 1100];
set(gcf,'Position',ppp);
subplot(1,3,1)
plot(phi,rf,'k.')
xlabel('Phi');
ylabel('Rf');
title('Strained');
a=axis;
a(1:3)=[-90 90 1];
axis(a);
set(gca,'XTick',-90:30:90);
tt=get(gca,'YTick');
set(gca,'YScale','log');
set(gca,'YTick',tt);
set(gca,'YGrid','on');
set(gca,'XGrid','on');

% settings
poc=length(rf);
e={}; en={}; chi=[]; 
nbins=round(poc/10);
if nbins>13, nbins=13; end
if nbins<5, nbins=5; end
kk=rf((phi>-10)&(phi<10));
stp=(sqrt(mean(kk)+std(kk))-1)/200;
rs=(1+(0:nsteps)*stp).^2';
subplot(1,3,3)
if exist('chi2inv','file')==2
    sl=chi2inv(0.95,nbins-2);
    line([1;(1+nsteps*stp)^2],[sl;sl]);
else
    sl=NaN;
end
set(gca,'YScale','log');
xlabel('Rs');
ylabel('Chi-square');
title(['Chi-square plot df=' num2str(nbins-1)]);
hold on


% nacte elipsy
for i=1:poc
    anr=phi(i)*pi/180;
    r=[cos(anr) -sin(anr);...
       sin(anr)  cos(anr)];
    p=[sqrt(rf(i)) 0;0 1/sqrt(rf(i))];
    e{i}=(r*p)*(r*p)';
end
for i=0:nsteps-1
    tm=[1/(1+i*stp) 0;0 (1+i*stp)];
    for j=1:poc
        en{j}=tm*e{j}*tm';
    end
    f=eanal(en);
    n=histc(f,linspace(-90,90,nbins)); n=n(1:end-1);
    chi=[chi; sum(((n-poc/nbins).^2)/(poc/nbins))];
    plot((1+i*stp)^2,chi(end),'k.');
    drawnow
end
a=axis;
a(1:2)=[1 (1+nsteps*stp)^2];
axis(a)

subplot(1,3,2)
ix=find(chi==min(chi));
ix=ix(round(length(ix)/2));
rs=rs(ix);
chitest=[chi(ix) sl];
tm=[1/(1+ix*stp) 0;0 (1+ix*stp)];
for j=1:poc
    en{j}=tm*e{j}*tm';
end
[f,r]=eanal(en);
plot(f,r,'b.')
xlabel('Phi');
ylabel('Ri');
title(['De-strained  Rs=' num2str(rs)]);
a=axis;
a(1:3)=[-90 90 1];
axis(a);
set(gca,'XTick',-90:30:90)
tt=get(gca,'YTick');
set(gca,'YScale','log');
set(gca,'YTick',tt);
set(gca,'YGrid','on');
set(gca,'XGrid','on');
if nargout>2
    hm=1./mean(1./rf);   % harmonic mean
    Isym=1-(abs(length(find(rf>hm&phi<=0))-length(find(rf>hm&phi>0)))+abs(length(find(rf<=hm&phi<=0))-length(find(rf<=hm&phi>0))))/length(rf);
end



%------------------------------------------------------------
% Helper functions
function [f,r]=eanal(e)
r=[]; f=[];
for i=1:length(e)
    [v,d]=eig(e{i});   ev=sqrt(diag(d));
    if ev(1)>ev(2)
        r=[r;ev(1)/ev(2)];
        vc=v(:,1);
    else
        r=[r;ev(2)/ev(1)];
        vc=v(:,2);
    end
    if vc(2)>0
        vc=-vc;
    end
    ot=acos(vc'*[-1;0])*180/pi;
    if ot>90
        ot=ot-180;
    end
    f=[f;ot];
end
