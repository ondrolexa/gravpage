function res=dbconnect(dbserver,dbname,dbuser,dbpassword,dbdriver)
%DBCONNECT Open the connection to database

global polylx_prefs
setdbprefs('DataReturnFormat','cellarray');
res=false;
avdrivers={'MySQL','PostgreSQL'};

if nargin==5
    polylx_prefs=struct('server',dbserver,'database',dbname,'username',dbuser,'password',dbpassword,'driver',dbdriver);
end
    
if ~exist('polylx_prefs','var')
    ok=false;
else
    if ~isfield(polylx_prefs,'server')|~isfield(polylx_prefs,'database')|~isfield(polylx_prefs,'username')|~isfield(polylx_prefs,'password')|~isfield(polylx_prefs,'driver')|~(~isempty(polylx_prefs.server)&~isempty(polylx_prefs.database)&~isempty(polylx_prefs.username)&~isempty(polylx_prefs.driver))
        ok=false;
    else
        ok=true;
    end
end

while ~ok
    [sel,ok]=listdlg('ListString',avdrivers,'SelectionMode','single','ListSize',[120 50],'Name','Connection','PromptString','Select database type');
    if isempty(sel)
        return
    end
    driver=avdrivers{sel};
    answer=inputdlg({'Database server:','Database:','Username:','Password:'},'Database connection',1,{'localhost','polylx','',''});
    if isempty(answer)
        return
    end
    %password=passcode;
    polylx_prefs=struct('server',answer{1},'database',answer{2},'username',answer{3},'password',answer{4},'driver',driver);
    ok=~isempty(polylx_prefs.server)&~isempty(polylx_prefs.database)&~isempty(polylx_prefs.username)&~isempty(polylx_prefs.driver);
end
if ~isfield(polylx_prefs,'connected')
    if strcmpi(polylx_prefs.driver,'MySQL')
        % Define connection string
        dbconn = database(polylx_prefs.database,polylx_prefs.username,polylx_prefs.password,'com.mysql.jdbc.Driver',['jdbc:mysql://' polylx_prefs.server '/' polylx_prefs.database]);
        if ~isempty(dbconn.Message)
            disp(dbconn.Message)
            clear global polylx_prefs
            return
        else
            polylx_prefs=setfield(polylx_prefs,'connected',dbconn);
        end 
    else %PostgreSQL
        % Define connection string
        dbconn = database(polylx_prefs.database,polylx_prefs.username,polylx_prefs.password,'org.postgresql.Driver',['jdbc:postgresql://' polylx_prefs.server '/']);
        if ~isempty(dbconn.Message)
            disp(dbconn.Message)
            clear global polylx_prefs
            return
        else
            polylx_prefs=setfield(polylx_prefs,'connected',dbconn);
            rr=dbcommand('SELECT table_name FROM information_schema.tables where table_name = ''samples''');
            if isempty(rr)
                dbcommand('CREATE TABLE samples(id serial PRIMARY KEY,name varchar(10) NOT NULL,label varchar(10),x float8,y float8);');
            end
        end
    end
end
res=true;

function pass = passcode(charset);
%PASSCODE  password input dialog box.
%  passcode creates a modal dialog box that returns user password input.
%  Given characters are substituted with '*'-Signs like in usual Windows dialogs.
%  
%  usage:
%  answer = PASSCODE 
%     without input parameter allows to type any ASCII-Character
%  answer = PASSCODE('digit') 
%     allows only digits as input characters [0-9]
%  answer = PASSCODE('letter')
%     allows only letters as input characters [a-z_A-Z]
%  answer = PASSCODE(<string>)
%     allows to use characters from the specified string only
%     
%  See also PCODE.

% Version: v1.2 (03-Mar-2008)
% Author:  Elmar Tarajan [MCommander@gmx.de]

if nargin==0
   charset = default;
else
   if any(strcmp({'letter' 'digit'},charset))
      charset = eval(charset);
   elseif ~isa(charset,'char')
      error('string expected. Check input parameters.')
   end% if
end% if
%
ScreenSize = get(0,'ScreenSize');
hfig = figure('Menubar','none', ...
   'Units','Pixels', ...
   'Resize','off', ...
   'NumberTitle','off', ...
   'Name',['password required'], ...
   'Position',[ (ScreenSize(3:4)-[300 75])/2 300 75], ...
   'Color',[0.8 0.8 0.8], ...
   'WindowStyle','modal');
hedit = uicontrol('Parent',hfig, ...
   'Style','Edit', ...
   'Enable','inactive', ...
   'Units','Pixels','Position',[49 28 202 22], ...
   'FontSize',15, ...
   'String',[], ...   
   'BackGroundColor',[0.7 0.7 0.7]);
hpass = uicontrol('Parent',hfig, ...
   'Style','Text', ...
   'Tag','password', ...
   'Units','Pixels','Position',[51 30 198 18], ...
   'FontSize',15, ...
   'BackGroundColor',[1 1 1]);
hwarn = uicontrol('Parent',hfig, ...
   'Style','Text', ...
   'Tag','error', ...
   'Units','Pixels','Position',[50 2 200 20], ...
   'FontSize',8, ...
   'String','character not allowed',...
   'Visible','off',...
   'ForeGroundColor',[1 0 0], ...
   'BackGroundColor',[0.8 0.8 0.8]);
%
set(hfig,'KeyPressFcn',{@keypress_Callback,hedit,hpass,hwarn,charset}, ...
         'CloseRequestFcn','uiresume')
%
uiwait
pass = get(hpass,'userdata');
delete(hfig)
  %
  %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function keypress_Callback(hObj,data,hedit,hpass,hwarn,charset)
%--------------------------------------------------------------------------
pass = get(hpass,'userdata');
%
switch data.Key
   case 'backspace'
      pass = pass(1:end-1);
      %
   case 'return'
      uiresume
      return
      %
   otherwise
      try
         if any(charset == data.Character)
            pass = [pass data.Character];
         else
            set(hwarn,'Visible','on')
            pause(0.5)
            set(hwarn,'Visible','off')
         end% if
      end% try
      %
end% switch
%
set(hpass,'userdata',pass)
set(hpass,'String',char('*'*sign(pass)))
  %
  %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function charset = default
%--------------------------------------------------------------------------
% charset = [letter digit '<>[]{}()@!?*#=~-+_.,;:§$%&/|\'];
charset = char(1:255);
  %
  %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function charset = digit
%--------------------------------------------------------------------------
charset = '0123456789';
  %
  %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function charset = letter
%--------------------------------------------------------------------------
charset = char([65:90 97:122]);
  %
  %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% I LOVE MATLAB %%%
