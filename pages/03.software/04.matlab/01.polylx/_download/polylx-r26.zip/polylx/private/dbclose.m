function dbclose
%DBCLOSE Close the connection to the database

global polylx_prefs
try
    close(polylx_prefs.connected);
    polylx_prefs=rmfield(polylx_prefs,'connected');
end
