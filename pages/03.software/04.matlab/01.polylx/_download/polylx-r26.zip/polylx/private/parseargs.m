function p=parseargs(args, defargs)
%PARSEARGS - parse varargin cell array

if nargin<2
    error('You must provide default values');
end
if mod(length(args),2)==1
    error('Wrong number of arguments. Options must be in pairs.');
end

% get names of default properties
props=lower(fieldnames(defargs));
p=defargs;

for i=1:2:length(args)
    tprop=args{i};
    if ~isa(tprop,'char')
        error([tprop ' is not option name. Check arguments order.']);
    end
    tprop=lower(tprop);
    if isempty(strmatch(tprop,props,'exact'))
        disp([tprop ' is not allowed property and will be ignored']);
    else
        if ~strcmp(class(args{i+1}),class(getfield(defargs,tprop)))
            error(['Wrong value for option ' tprop '. Is should be ' class(getfield(defargs,tprop)) '.']);
        end
        p=setfield(p,tprop,args{i+1});
    end
end
