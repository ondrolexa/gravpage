function [res,att]=dbcommand(command)
%DBCOMMAND  Send an SQL statement to a database

global polylx_prefs

try
    % Execute SQL command
    curs=fetch(exec(polylx_prefs.connected,command));
    att=attr(curs);
    res=curs.Data';
    if strcmp('No Data',res)
        res=[];
    end
catch
    % If anything went wrong return an empty set
    res=[];
end
