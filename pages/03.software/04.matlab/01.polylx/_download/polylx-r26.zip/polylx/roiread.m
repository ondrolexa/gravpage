function [g,pth,fnm]=roiread(varargin)
%ROIREAD Read grain geometry from ImageJ ROI files.
% Syntax:  [g,path,filename]=roiread([options];
%          [g,path,filename]=roiread(filename,[options]);
% Options are:
%  'method'  ... 'none' No smoothing. Default.
%            ... 'dp' Douglas-Peucker simplification.
%            ... 'bezier' quadratic bezier curves approximation.
%            ... 'average' averaging of neighborough coordinates.
%   'phase'  ... String assigned as phase name. Default 'None'.
%   'scale'  ... Scale in pixel/units. Default 1.

% Ondrej Lexa 2001,2007

if nargin>0
    if exist(varargin{1},'file')
        filename=varargin{1};
        varargin=varargin(2:end);
        ix=find(filename=='\');
        if isempty(ix);
            ix=0;
        end
        fnm=filename(ix(end)+1:end);
        pth=filename(1:ix(end));
    end
end

if ~exist('filename','var')
    [fnm, pth]=uigetfile({'*.roi','ImageJ ROI files (*.roi)'},'Open ROI file','MultiSelect','on');
    if isa(fnm,'double')
        ret=[];
        return
    end
end

if isa(fnm,'char')
    fnm={fnm};
end

% initialize defaults and parse arguments
opts.method='none';
opts.phase='None';
opts.scale=1;
opts=parseargs(varargin,opts);

cnt=0;

for i=1:length(fnm)
    fid = fopen([pth fnm{i}],'r','b');
    header = fread(fid,8,'uint8');

    if ~isequal(header(1:4),double('Iout')')
        printf('%s does not contain a valid ImageJ roi\n',fnm{i})
    else
        top = fread(fid,1,'int16');
        left = fread(fid,1,'int16');
        bottom = fread(fid,1,'int16');
        right = fread(fid,1,'int16');
        N = fread(fid,1,'int16');
        x1 = fread(fid,1,'float');
        y1 = fread(fid,1,'float');
        x2 = fread(fid,1,'float');
        y2 = fread(fid,1,'float');
        dummy = fread(fid,1,'int16');
        dummy = fread(fid,1,'float');
        dummy = fread(fid,12,'int16');
        if N>0
            x = left + fread(fid,N,'int16');
            y = top + fread(fid,N,'int16');
            x=[x;x(1)]/opts.scale;
            y=0-[y;y(1)]/opts.scale;
            geom=plgeo(x,y);
            if sign(geom(1))~=1
                x=flipud(x);
                y=flipud(y);
            end
            cnt=cnt+1;
            g(cnt)=grain(cnt,opts.phase,x,y);
        end
    end
    fclose(fid);
end

g=gsmooth(g,'method',opts.method);
