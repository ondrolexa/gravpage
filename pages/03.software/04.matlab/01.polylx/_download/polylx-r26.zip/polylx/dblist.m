function [stat,up]=dblist
%DBLIST Show informations about stored data in database.
% Syntax: res=dblist;
%         [res,up]=dblist;
%
% res   ... array of sample names, number of grains and number of phases
% up    ... list of unique phase names in database

global polylx_prefs
%Check connection
if dbconnect

    res=dbcommand('SELECT id,name FROM samples');
    stat=dbcommand(['SELECT name FROM samples']);
    if isempty(stat)
        disp('No samples in open database. Aborting.');
        dbclose
        return
    else
        up={};
        for i=1:size(res,2)
            stat{1,i}=res{2,i};
            if strcmpi(polylx_prefs.driver,'MySQL')
                upt=dbcommand(['SELECT phase FROM grains WHERE id_sample=' num2str(res{1,i})]);
            else
                upt=dbcommand(['SELECT phase FROM ' stat{1,i} '.grains']);
            end
            stat{2,i}=length(upt);
            upt=unique(upt);
            stat{3,i}=length(upt);
            up=union(up,upt);
        end
        stat=stat';
        if nargout<1
            disp([{'Samples','Grains','Phases'};stat]);
            clear stat
            clear up
        end
    end
    dbclose;
end
