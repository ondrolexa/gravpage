function gn=gsmooth(g,varargin)
%GSMOOTH Smooth outlines of grain objects.
% Syntax: gn=gsmooth(g,options);
% Options are:
%  'method'  ... 'dp' Douglas-Peucker simplification. Deafult.
%            ... 'bezier' quadratic bezier curves approximation.
%            ... 'average' averaging of neighborough coordinates.
%                 Works well for staircase boundaries.
%  'tol'     ... Distance tolerance for Douglas-Peucker and bezier.
%                Default 1/100 of mode of EAD.

if nargin<1
    help gsmooth
    return
end

% initialize defaults and parse arguments
opts.method='dp';
ead=get(g,'ead');
opts.tol=exp(mean(log(ead))-std(log(ead))^2)/100;
opts=parseargs(varargin,opts);

pocet=size(g,2);

if strcmpi(opts.method,'average')
    h=fwaitbar(0,'Smoothing...');
    for ii=1:pocet
        [x,y]=get(g(ii),'x','y');
        xm=mean([x(1:end-1) x(2:end)],2);
        xm=[xm;xm(1);NaN];
        ym=mean([y(1:end-1) y(2:end)],2);
        ym=[ym;ym(1);NaN];
        nh=get(g(ii),'nholes');
        if nh>0
            hh=get(g(ii),'holes');
            for j=1:nh
                txm=mean([hh(j).x(1:end-1) hh(j).x(2:end)],2);
                xm=[xm;txm;txm(1);NaN];
                tym=mean([hh(j).y(1:end-1) hh(j).y(2:end)],2);
                ym=[ym;tym;tym(1);NaN];
            end
        end
        xm=xm(1:end-1);
        ym=ym(1:end-1);
        gn(ii)=grain(get(g(ii),'id'),char(get(g(ii),'phase')),xm,ym,get(g(ii),'UserData'));
        fwaitbar(ii/pocet,h);
    end
    close(h)
elseif strcmpi(opts.method,'dp')
    h=fwaitbar(0,'Smoothing...');
    cix=1;
    for ii=1:pocet
        [x,y]=get(g(ii),'x','y');
        [nx,ny]=dpsimply(x(1:end-1),y(1:end-1),opts.tol);
        if length(nx)>2
            nx=[nx;nx(1);NaN];
            ny=[ny;ny(1);NaN];
            nh=get(g(ii),'nholes');
            if nh>0
                hh=get(g(ii),'holes');
                for j=1:nh
                    [tnx,tny]=dpsimply(hh(j).x(1:end-1),hh(j).y(1:end-1),opts.tol);
                    if length(tnx)>2
                        nx=[nx;tnx;tnx(1);NaN];
                        ny=[ny;tny;tny(1);NaN];
                    else
                        disp(['Hole ' num2str(j) ' of grain ' num2str(ii) ' degenerate and was discarded.'])
                    end
                end
            end
            nx=nx(1:end-1);
            ny=ny(1:end-1);
            gn(cix)=grain(get(g(ii),'id'),char(get(g(ii),'phase')),nx,ny,get(g(ii),'UserData'));
            cix=cix+1;
        else
            disp(['Grain ' num2str(ii) ' degenerate and was discarded.'])
        end
        fwaitbar(ii/pocet,h);
    end
    close(h)
elseif strcmpi(opts.method,'bezier')
    h=fwaitbar(0,'Smoothing...');
    cix=1;
    for ii=1:pocet
        [x,y]=get(g(ii),'x','y');
        [nx,ny]=bezcurve(x,y);
        [nx,ny]=dpsimply(nx(1:end-1),ny(1:end-1),opts.tol);
        if length(nx)>2
            nx=[nx;nx(1);NaN];
            ny=[ny;ny(1);NaN];
            nh=get(g(ii),'nholes');
            if nh>0
                hh=get(g(ii),'holes');
                for j=1:nh
                    [tnx,tny]=bezcurve(hh(j).x,hh(j).y);
                    [tnx,tny]=dpsimply(tnx(1:end-1),tny(1:end-1),opts.tol);
                    if length(tnx)>2
                        nx=[nx;tnx;tnx(1);NaN];
                        ny=[ny;tny;tny(1);NaN];
                    else
                        disp(['Hole ' num2str(j) ' of grain ' num2str(ii) ' degenerate and was discarded.'])
                    end
                end
            end
            nx=nx(1:end-1);
            ny=ny(1:end-1);
            gn(cix)=grain(get(g(ii),'id'),char(get(g(ii),'phase')),nx,ny,get(g(ii),'UserData'));
            cix=cix+1;
        else
            disp(['Grain ' num2str(ii) ' degenerate and was discarded.'])
        end
        fwaitbar(ii/pocet,h);
    end
    close(h)
else
    gn=g;
end

function [nx,ny]=dpsimply(x,y,tol,sx,sy)

if nargin<5
    sx=x(1);
    sy=y(1);
end

x0=x(1);
dx=x(end)-x0;
y0=y(1);
dy=y(end)-y0;
tria=abs((x-x0)*dy-(y-y0)*dx)/sqrt(dx*dx+dy*dy);
[mx,ix]=max(tria);
if mx>tol
    sx=[sx;x(ix)];
    sy=[sy;y(ix)];
    [sx,sy]=dpsimply(x(1:ix),y(1:ix),tol,sx,sy);
    if nargin<5
        [sx,sy]=dpsimply([x(ix:end);x(1)],[y(ix:end);y(1)],tol,sx,sy);
    else
        [sx,sy]=dpsimply(x(ix:end),y(ix:end),tol,sx,sy);
    end
end
nx=sx;
ny=sy;
if nargin<5
    nx=[nx;x(end)];
    ny=[ny;y(end)];
    [dummy,ia,dummy]=intersect([x y],[nx ny],'rows');
    ia=sort(ia);
    nx=x(ia);
    ny=y(ia);
end

function [xs,ys]=bezcurve(x,y)
x=[x(:);x(2)];
y=[y(:);y(2)];
t=linspace(0,1,20)';
xs=[];
ys=[];
for i=2:length(x)-1
    xs=[xs(1:end-1);(x(i-1)+x(i))*(1 - t).^2/2 + 2*x(i)*(1-t).*t + (x(i)+x(i+1))*t.^2/2];
    ys=[ys(1:end-1);(y(i-1)+y(i))*(1 - t).^2/2 + 2*y(i)*(1-t).*t + (y(i)+y(i+1))*t.^2/2];
end
