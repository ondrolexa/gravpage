function stat=pdianglehist(da,varargin)
%PDIANGLEHIST Plot histogram of chosen dihedral angles.
%Syntax: stat=pdianglehist(da,options);
%For options see PHISTNORM

if nargin<1|~isa(da,'cell')
    help pdianglehist
    return
end
stat=[];
while true
    [tx,c]=listdlg('ListString',da(2:end,1),'Name','Choose boundary type','ListSize',[150 200],'CancelString','Exit','SelectionMode','single');
    if c==0
        return
    end

    [phx,c]=listdlg('ListString',da(1,2:end),'Name','Choose oposite phase','ListSize',[150 200],'CancelString','Exit','SelectionMode','single');
    if c==0
        return
    end

    dt=da{tx+1,phx+1};
    if length(dt)>1
        [stat,tt]=phistnorm(dt,varargin{:});
        title([da{tx+1,1} '->' da{1,phx+1} '  ' tt])
    end
end