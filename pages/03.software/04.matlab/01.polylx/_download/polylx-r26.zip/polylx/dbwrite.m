function dbwrite(g,sample)
%DBWRITE Write grain object into database.
% Syntax:  dbwrite(g);
%          dbwrite(g,sample);

% Ondrej Lexa 2006

global polylx_prefs
% Check input
if nargin<2
    sample=[];
end
if nargin<1
    help dbwrite
    return
end
if ~isa(g,'grain')
    error('The first argument of DBWRITE must be a grain object. Aborting.');
end

%Check connection
if dbconnect

    if isempty(sample)
        res=dbcommand(['SELECT name FROM samples']);
        if isempty(res)
            answer=inputdlg('Input name for sample:','Name');
            sample=answer{1};
            sample=strrep(sample,'-','');
        else
            [sel,ok] = listdlg('ListString',[res {'New sample...'}],'SelectionMode','single','Name','Select sample');
            if ok==0
                dbclose;
                return
            end
            if sel==size(res,2)+1
                answer=inputdlg('Input name for sample:','Name');
                sample=answer{1};
                sample=strrep(sample,'-','');
            else
                sample=res{sel};
            end
        end
    else
        sample=strrep(sample,'-','');
    end
    
    % check sample list
    res=dbcommand(['SELECT name FROM samples WHERE name=''' sample '''']);
    if ~isempty(res)
        disp('Sample already exists. Aborting...')
        dbclose
        return
    end
    if strcmpi(polylx_prefs.driver,'MySQL')
        % get sample id
        dbcommand(['INSERT INTO samples (name) VALUES ("' sample '");']);
        res=dbcommand(['SELECT id FROM samples WHERE name="' sample '"']);
        id_sample=res{1};

        dbsep='),(';
        dbcmdfin='))''));';

        h=fwaitbar(0,'Writing grains into database...');
        poc=length(g);

        for i=1:poc;
            id_grain=get(g(i),'id');
            phase=get(g(i),'phase');
            [x,y]=get(g(i),'x','y');
            dbcmd=['INSERT INTO grains (id_sample,id_grain,phase,geometry) VALUES (' num2str(id_sample) ',' num2str(id_grain) ',"' phase{1} '",PolygonFromText(''POLYGON(('];
            co=sprintf('%.8f %.8f,',[x y]');
            dbcmd=[dbcmd co(1:end-1)];
            hol=get(g(i),'holes');
            for j=1:get(g(i),'nholes')
                co=sprintf('%.8f %.8f,',[hol(j).x hol(j).y]');
                dbcmd=[dbcmd dbsep co(1:end-1)];
            end
            dbcmd=[dbcmd dbcmdfin];

            % Insert a new row with a description in the string column
            % and leave the blob column empty
            dbcommand(dbcmd);
            fwaitbar(i/poc,h);
        end
        close(h)
        
        b=bmake(g);
        dbcmdfin=')''));';
        
        h=fwaitbar(0,'Writing boundaries into database...');
        poc=length(b);
        
        for i=1:poc;
            id_boundary=get(b(i),'id');
            ida=get(b(i),'ida');
            idb=get(b(i),'idb');
            phasea=get(b(i),'phasea');
            phaseb=get(b(i),'phaseb');
            x=get(b(i),'x');
            y=get(b(i),'y');
            dbcmd=['INSERT INTO boundaries (id_sample,id_boundary,id_graina,id_grainb,phasea,phaseb,geometry) VALUES (' num2str(id_sample) ',' num2str(id_boundary) ',' num2str(ida) ',' num2str(idb) ',"' phasea{1} '","' phaseb{1} '",LineStringFromText(''LINESTRING('];
            co=sprintf('%.8f %.8f,',[x y]');
            dbcmd=[dbcmd co(1:end-1)];
            dbcmd=[dbcmd dbcmdfin];
            dbcommand(dbcmd);
            fwaitbar(i/poc,h);
        end
        close(h)
    else
        dbcommand(['INSERT INTO samples (name,label) VALUES (''' sample ''',''' sample ''');']);
        dbcommand(['CREATE SCHEMA ' sample ';']);
        dbcommand(['CREATE TABLE "' sample '"."grains"(gid serial PRIMARY KEY,"id_grain" int4,"phase" varchar(10) NOT NULL);']);
        dbcommand(['SELECT AddGeometryColumn(''' sample ''',''grains'',''geometry'',''-1'',''POLYGON'',2);']);
        dbcommand(['CREATE INDEX "grains_geometry_gist" ON "' sample '"."grains" USING gist ("geometry" gist_geometry_ops);']);    
        dbcommand(['SET search_path TO ' sample ',public']);

        dbsep='),(';
        dbcmdfin='))''));';

        h=fwaitbar(0,'Writing grains into database...');
        poc=length(g);

        for i=1:poc;
            id_grain=get(g(i),'id');
            phase=get(g(i),'phase');
            [x,y]=get(g(i),'x','y');
            dbcmd=['INSERT INTO grains (id_grain,phase,geometry) VALUES (' num2str(id_grain) ',''' phase{1} ''',PolygonFromText(''POLYGON(('];
            co=sprintf('%.8f %.8f,',[x y]');
            dbcmd=[dbcmd co(1:end-1)];
            hol=get(g(i),'holes');
            for j=1:get(g(i),'nholes')
                co=sprintf('%.8f %.8f,',[hol(j).x hol(j).y]');
                dbcmd=[dbcmd dbsep co(1:end-1)];
            end
            dbcmd=[dbcmd dbcmdfin];

            dbcommand(dbcmd);
            fwaitbar(i/poc,h);
        end
        close(h)
    end
    dbclose;
end
