function cm=getcm(g,b)
%GETCM Return connectivity matrix
% Syntax: cm=getcm(g,b);
%         cm=getcm(g);

if nargin<1
    help getcm
    return
end

if nargin<2
    b=bmake(g);
end

% Initialize
poc=length(g);

% Generate connectivity matrix
cm=sparse(poc,poc);
for i=1:length(b);
    ixa=get(b(i),'ida');
    ixb=get(b(i),'idb');
    cm(ixa,ixb)=1;
    cm(ixb,ixa)=1;
end
