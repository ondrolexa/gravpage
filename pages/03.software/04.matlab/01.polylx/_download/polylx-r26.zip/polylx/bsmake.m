function b=bsmake(g)
%BSMAKE Routine to construct boundaries segments objects from grain objects.
% Syntax:  b=bsmake(g);
%    g   - grain objects

h=fwaitbar(0,'Decomposing grain objects...');

%Decompose grains
idx=0;
poc=length(g);
for i=1:poc
    fwaitbar(i/poc,h);
    [x,y]=get(g(i),'x','y');
    for j=1:length(x)-1
        idx=idx+1;
        b(idx)=boundary(idx,i,0,char(get(g(i),'phase')),'ZZ',x(j:j+1),y(j:j+1));
    end
    fwaitbar(i/poc,h);
end
close(h);
