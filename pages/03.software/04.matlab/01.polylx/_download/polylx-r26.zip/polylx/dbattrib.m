function [res,fin]=dbattrib(fields)
%DBATTRIB Read attributes of samples from database.
% Syntax: [res,fin]=dbattrib
%         [res,fin]=dbattrib(fields)
%   res is cell array of attributes
%   fin is cell array of field names

%Check connection
if dbconnect
    [res,att]=dbcommand(['SELECT * FROM samples ORDER BY name']);
    if isempty(res)
        disp('No samples in open database. Aborting.');
    else
        fin={att.fieldName};
        if nargin<1
            [sel,ok] = listdlg('ListString',fin,'Name','Select attributes');
            if ok~=0
                fin=fin(sel);
                res=res(sel,:)';
            end
        else
            [sel,ix]=intersect(fin,fields);
            if ~isempty(ix)
                fin=fin(ix);
                res=res(ix,:)';
            end
        end
    end
    dbclose;
end
