function [id,idmore,idless]=gnsearch(g,b,ph1,ph2,treshold,opt)
%GNSEARCH Return grains of phase ph1 which share boundary with phase ph2.
% Routine return as well grains which share more/less than treshold.
% Syntax:  [id,idmore,idless]=gnsearch(g,b,ph1,ph2,treshold);
%   ph1      ... searched phase
%   ph2      ... enclosing phase
%   treshold ... treshold of selection. Default 0.5
%   opt      ... 0... boundary grains are not used. Default
%            ... 1... boundary grains are used

% Ondrej Lexa (c) 2004


if nargin<4
	error('Not enough arguments.');
end
if nargin<5
	treshold=0.5;
end
if nargin<6
    opt=0;
end

rp=[];
rid=[];
tt=sort({ph1,ph2});
btype=strcat(tt{1},'-',tt{2});
ix=gpsel(g,ph1);
for i=1:length(ix);
   id=get(g(ix(i)),'id');
   ida=get(b,'ida');
   idb=get(b,'idb');
   ib=union(find(ida==id),find(idb==id));
   if ~isempty(ib)
      per=get(g(ix(i)),'perimeter');
      cltot=sum(get(b(ib),'cumlength'));
      if opt==0
          if cltot/per>0.99999 % bad way to test border grains
              cltyp=sum(get(b(ib(btsel(b(ib),btype))),'length'));
              rp=[rp cltyp/cltot];
              rid=[rid ix(i)];
          end
      else
          cltyp=sum(get(b(ib(btsel(b(ib),btype))),'length'));
          rp=[rp cltyp/cltot];
          rid=[rid ix(i)];
      end
   else % isolated grains
       if opt==1
           rp=[rp 0];
           rid=[rid ix(i)];
       end
   end
end
id=rid(rp==treshold);
idmore=rid(rp>treshold);
idless=rid(rp<treshold);
