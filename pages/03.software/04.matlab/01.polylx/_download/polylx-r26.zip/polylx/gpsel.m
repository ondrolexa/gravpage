function ix=gpsel(g,varargin)
%GPSEL Grain phase select. Return indexes into objects array with phase(s) ph.
% Syntax: ix=gpsel(g,ph);

if nargin<1
   help gpsel
   ix=[];
   return
end

if isa(g,'boundary')
   ix=btsel(g,varargin);
   return
end

% GUI choose props
if isempty(varargin)
    upl=gplist(g);
    [phx,c]=listdlg('ListString',upl,'Name','Choose Phase(s)','ListSize',[150 200],'CancelString','Exit');
    if c==0
        ix=[];
        return
    end
    tp=upl(phx);
else
    tp=varargin;
end

plist=lower(get(g,'phase'));

ix=[];
for i=1:length(tp);
    ix=[ix;strmatch(lower(tp{i}),plist,'exact')];
end
ix=unique(ix);
