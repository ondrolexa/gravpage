function idplot(g)
%IDPLOT Plot selectable grain objects g on active figure.
%   IDPLOT(g) plot grain objects g on active figure.

if isempty(g), return; end

zoz=gplist(g);
hlist=[];

% Clear figure when not holded
if ~ishold
 cla
end
set(gca,'Box','on','TickDir','out','XminorTick','on','YminorTick','on','Tag','GrainPlot');

% get background color and edge color
bkc=get(gca,'Color');
edgec = get(gcf,'DefaultAxesxColor');

% plot in order first bigest last smallest due to holes
switch class(g)
    case 'grain'
        [dummy,zorder]=sort(-get(g,'OutArea'));
        phl=get(g,'Phase');
    otherwise
        close(gcf);
        error('Argument must be grain object.');
end
for ii=1:size(g,2)
  cix=strmatch(phl{zorder(ii)},zoz,'exact');
  ud=[zorder(ii) get(g(zorder(ii)),'xcentre') get(g(zorder(ii)),'ycentre')];
  ud=[ud NaN NaN NaN];
  ht=patch('XData',get(g(zorder(ii)),'x'),'YData',get(g(zorder(ii)),'y'),'CData',cix,'FaceColor','flat','EdgeColor',edgec,'ButtonDownFcn','getsel','Tag','grain','SelectionHighlight','off','UserData',ud);
  hlist=[hlist; ht cix];
  q=get(g(zorder(ii)),'Holes');
  for jj=1:get(g(zorder(ii)),'Nholes')
      patch('XData',q(jj).x,'Ydata',q(jj).y,'FaceColor',bkc,'EdgeColor',edgec,'Tag','hole','UserData',{NaN,NaN,[]});
  end
end
axis equal
set(gcf, 'WindowButtonDownFcn', 'rectsel')
uicontrol('Style', 'pushbutton', 'String', 'Clear','Units','Normalized','Position', [0.005 0.945 0.1 0.05], 'Callback', 'getsel clear');
uicontrol('Style', 'popup','String', 'jet|hsv|hot|cool|bone|copper|pink|flag|prism|gray','Units','Normalized','Position', [0.11 0.945 0.1 0.05],'Callback', 'dummy=get(gcbo,''String''); colormap(eval(dummy(get(gcbo,''Value''),:)))');

