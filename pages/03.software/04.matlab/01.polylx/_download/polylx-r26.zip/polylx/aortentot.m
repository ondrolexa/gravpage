function [la,sa,lao,sao]=aortentot(g,opt)
%AORTENTOT Return results of Ellipse fitting using bulk orientation tensor.
% Syntax: [la,sa,lao,sao]=aortentot(g,opt);
% g can be grain and boundary object(s)
% opt 0 ... use all vertexes (default)
%     1 ... use long axes (uniform length)
%     2 ... use long axes (proportional length)

if nargin<2
 opt=0;
end

%Initialize
poc=size(g,2);
xx=[];
yy=[];

if isa(g,'boundary') && opt==1
    opt=0;
end

h=fwaitbar(0,'Calculating...');
for ii=1:poc
    [x,y]=get(g(ii),'x','y');
    
    switch opt
        case 0
            if isa(g,'grain')
                x=x(1:end-1)-get(g(ii),'xcentre');
                y=y(1:end-1)-get(g(ii),'ycentre');
            else
                x=x-get(g(ii),'xcentre');
                y=y-get(g(ii),'ycentre');
            end
        case 1
            or=get(g(ii),'orientation');
            x=sin(rad(or));
            y=cos(rad(or));
        case 2
            or=get(g(ii),'orientation');
            la=get(g(ii),'length');
            x=la*sin(rad(or));
            y=la*cos(rad(or));
        otherwise
            close (h)
            help aortentot
            error ('Wrong argument');
    end
    xx=[xx;x];
    yy=[yy;y];
    fwaitbar(ii/poc,h);
end

m=([xx yy]'*[xx yy])/length(xx);

% Calculate eigenvalues and eigenvectors
[v,c]=eig(m);
if c(2,2)<c(1,1)  % Sort eigenvalues and eigenvectors
   c=rot90(c,2);
   v=fliplr(v);
end

c(c<0)=0; % chybicka zaokruhlovania

la = 2*sqrt(c(2,2))*sqrt(2);
sa = 2*sqrt(c(1,1))*sqrt(2);
lao = mod(deg(atan2(v(1,2),v(2,2))),180);
sao = mod(deg(atan2(v(1,1),v(2,1))),180);

close(h)
