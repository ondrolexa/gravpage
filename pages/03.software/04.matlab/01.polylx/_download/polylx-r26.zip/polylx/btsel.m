function ix=btsel(b,varargin)
%BTSEL Boundary type select. Return object index vector.
%Syntax: ix=btsel(b,types);


if nargin<1
   help btsel
   return
end

if isa(b,'grain')
   ix=gpsel(b,varargin);
   return
end

% GUI choose props
if isempty(varargin)
   utl=btlist(b);
   [tx,c]=listdlg('ListString',utl,'Name','Choose Type(s)','ListSize',[150 200],'CancelString','Exit');
   if c==0
      ix=[];
      return
   end
   tp=utl(tx);
else
   tp=varargin;
end

tlist=lower(get(b,'type'));

ix=[];
for i=1:length(tp);
 ix=[ix;strmatch(lower(tp{i}),tlist,'exact')];
end
ix=unique(ix);
