function [pa,pf]=aparis(g,opt)
%APARIS Return PARIS function and factor after Panozzo&Hurlimann, 1983.
% PARIS is function is calculated as (SURFOR-PAROR)/PAROR
% Syntax: [pa,pf]=aparis(g,[opt]);
% g can be grain and boundary object(s)
%    opt - 0 (default) do not include holes into calculations
%          1 include holes into calculations
%     pa - PARIS function
%     pf - PARIS factor

if nargin<2
 opt=0;
end

%Initialize
n=size(g,2);
pa=zeros(n,180);

h=fwaitbar(0,'Calculating...');

nn=[sin(rad(1:180));cos(rad(1:180))];

for ii=1:n
    [x,y]=get(g(ii),'x','y');
    xd=diff(x);
    yd=diff(y);
    if bitget(opt,1)==1
        q=get(g(ii),'holes');
        for jj=1:get(g(ii),'nholes');
            xd=[xd;diff(q(jj).x)];
            yd=[yd;diff(q(jj).y)];
        end
    end

    %paror
    ff=[x y]*nn; 
    fp=(max(ff)-min(ff))';

    %surfor
    ff=[xd yd]*nn;
    if size(ff,1)>1
        fs=(sum(abs(ff)))';
    else
        fs=abs(ff)';
    end 

    if isa(g,'grain')
        fs=fs/2;
    end

    pa(ii,:)=100*(fs-fp)./fp;

    fwaitbar(ii/n,h);
end

%Calculate bulk PARIS factor
pf=mean(pa,2);
pf(pf<0)=0;

close(h)
