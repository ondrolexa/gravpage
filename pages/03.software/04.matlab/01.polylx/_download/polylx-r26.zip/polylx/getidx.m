function ix=getidx(g,gsub)
%GETIDX Return index vector for subset of objects gsub for objects g, so g(ix)=gsub.
% Syntax: ix=getidx(g,gsub)

ids=get(gsub,'id');
id=get(g,'id');
[dummy,dummy,ix]=intersect(ids,id);

