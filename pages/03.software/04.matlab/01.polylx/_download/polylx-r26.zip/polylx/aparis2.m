function [pf,deltA]=aparis2(g,opt)
%APARIS2 Return paris and area factors after Heilbronner&Keulen, 2006.
% Syntax: [pf,deltA]=aparis2(g,opt);
% g can be grain and boundary object(s). For boundary paris focator is same
% as straightness and deltA is not defined.
%    opt - 0 (default) do not include holes into calculations
%          1 include holes into calculations
%     pf - paris factor
% deltaA - area factor

if nargin<2
 opt=0;
end

if isa(g,'boundary')
    pf=get(g,'Straightness');
    deltA=[];
    return
end

if ~isa(g,'grain')
    help aparis2
    return
end

gc=gconvhull(g);

if bitget(opt,1)==1
    p=get(g,'perimeter');
    a=get(g,'area');
else
    p=get(g,'outperimeter');
    a=get(g,'outarea');    
end

pf=200*(p-get(gc,'perimeter'))./get(gc,'perimeter');
deltA=100*(get(gc,'area')-a)./a;

