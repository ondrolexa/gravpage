function [b1,ix]=bgsel(g,b,opt)
%BGSEL Boundary grain select. Return object index vector of boundaries beetween grains g.
% boundaries beetween grains g
% Used when gsub is subset of grains.
%Syntax: [bsub,ix]=bgsel(gsub,b,opt)
% opt ... 0 do not include outer boundaries (default)
%     ... 1 include outer boundaries

if nargin<2
 disp('Not enough arguments');
 help btsel;
 ix=[];
 return
end

if nargin<3
 opt=0;
end

id=get(g,'id');
ida=get(b,'ida');
idb=get(b,'idb');

poc=length(g);

ix=[];

if opt==1
 for i=1:poc
  ix=[ix;find(ida==id(i));find(idb==id(i))];
 end
else
 for i=1:poc
  ixa=find(ida==id(i));
  [dummy,ixb,dummy]=intersect(idb(ixa),id);
  ix=[ix;ixa(ixb)];
 end
end

ix=unique(ix);
b1=b(ix);
