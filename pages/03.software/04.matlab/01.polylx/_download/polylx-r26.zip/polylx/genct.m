function ct=genct(gb,mn)
%GENCT Generate color table for grain/boundary objects based on phase/type.
% Syntax: ct=genct(g,[opt])
%    g   - grain/boundary objects or cell array of legend entries
%    opt   - 0 automatically define colors (default). 1 manually define colors

if nargin<2
    mn=0;
end

switch class(gb)
    case 'grain'
        %Color table for grains
        ph=gplist(gb);
    case 'boundary'
        %Color table for boundaries
        ph=btlist(gb);
    case 'cell'
        %Color table with defined entries
        ph=gb;
    otherwise
        help genct
        return
end

pf=length(ph);
% set colours
cmap=jet(pf);
if mn==1
    for ii=1:pf
        ac=uisetcolor(cmap(ii,:),['Define color for ' ph{ii}]);
        if length(ac)==3
            cmap(ii,:)=ac;
        end
    end
end
for ii=1:pf
    ct(ii,1)=ph(ii);
    ct(ii,2)={cmap(ii,:)};
end
