function pal=makepal(g,prop,varargin)
%MAKEPAL Routine to generate universal color palette for plot.
% Syntax:  pal=makepal(g,prop);
%          pal=makepal(g,prop,'unique',['auto/manual']);
%          pal=makepal(g,prop,'gradual',[nbins]);
% g can be grain and boundary object(s)
%   prop - double or cell array of values on which the pallette is based.
%          Must have same number of elements as g
%          when prop is color table (genct) it will be converted to palette
% Ondrej Lexa 2006

%TODO graduate manual

if nargin<2
    switch class(g)
        case 'grain'
            prop=get(g,'phase');
        case 'boundary'
            prop=get(g,'type');
        otherwise
            error('First argument must be grain or boundary object!');
    end
end
        
if nargin<3
    varargin{1}='unique';
end
if nargin<4
    varargin{2}='auto';
end

poc=length(g);
pal=cell(poc,3);

if size(prop,2)==2 % color table passed instead properties
    pal=[repmat({[0]},poc,1) repmat({''},poc,1) repmat({[0 0 0]},poc,1)];
    gpl=get(g,'phase');
    for i=1:length(prop);
        ix=strmatch(prop{i,1},gpl,'exact');
        pal(ix,1)={i};
        pal(ix,2)={[prop{i,1} ' (' num2str(length(ix)) ')']};
        pal(ix,3)=prop(i,2);
    end
else
    if strcmpi(varargin{1},'unique')
        if strcmp(class(prop),'double')
            prop=cellstr(num2str(prop(:)));
        end
        if ischar(prop)
            prop=cellstr(prop);
        end
        zoz=unique(prop);
        % Create autopallete
        cpal=jet(length(zoz));
        if strcmpi(varargin{2},'manual')
            for i=1:length(zoz)
                ac=uisetcolor(cpal(i,:),['Define color for class ' zoz{i}]);
                if length(ac)==3
                    cpal(i,:)=ac;
                end
            end
        end
        for i=1:length(zoz);
            ix=strmatch(zoz{i},prop,'exact');
            pal(ix,1)={i};
            pal(ix,2)={[zoz{i} ' (' num2str(length(ix)) ')']};
            pal(ix,3)={cpal(i,:)};
        end
    end  
    if strcmpi(varargin{1},'gradual')
        if ~strcmp(class(prop),'double')
            error('For graduate pallete values must be numeric')
        end
        if nargin>3
            nbins=varargin{2};
        else
            nbins=20;
        end
        % Create autopallete
        cpal=jet(nbins);
        edg=linspace(min(prop),max(prop),nbins+1);
        if strcmpi(varargin{2},'manual')
            for i=1:nbins
                ac=uisetcolor(cpal(i,:),['Define color for class ' num2str(edg(i)) '-' num2str(edg(i+1))]);
                if length(ac)==3
                    cpal(i,:)=ac;
                end
            end
        end
        [dummy,bins]=histc(prop,edg);
        for i=1:nbins-1
            ix=find(bins==i);
            if ~isempty(ix)
                pal(ix,1)={i};
                pal(ix,2)={[num2str(edg(i)) '-' num2str(edg(i+1)) ' (' num2str(length(ix)) ')']};
                pal(ix,3)={cpal(i,:)};
            end
        end
        ix=find(bins>=nbins);
        pal(ix,1)={nbins};
        pal(ix,2)={[num2str(edg(nbins)) '-' num2str(edg(nbins+1)) ' (' num2str(length(ix)) ')']};
        pal(ix,3)={cpal(end,:)};
    end
end
