function [mn,gmn,st,c,q]=astrip(g,k,prop)
%ASTRIP Determine a 3D sphere diameter distribution from 2d grainsize. Old.
% Syntax: [mn,st,c,f]=astrip(g,k,prop);
% g can be grain object(s)
%  k...    number of bins
%  prop... property EAD(default), feret ...
% return mn-mean, st-standart deviation, c-centres of bins, f-frequencies
% Not tested !
if nargin<3
 prop='EAD';
end

f=get(g,prop);

if nargin<2
 k=ceil(1+3*log10(length(f)));
end

ed=linspace(0,max(f),k+1)';
ded=diff(ed);
c=cumsum([ded(1)/2;ded(2:end)]);
n=histc(f,ed);
n(end-1)=n(end-1)+n(end);
n=n(1:end-1);
no=n;

q=[];
for i=k:-1:1
 hs=geths(i);
 r=n(end)/hs(end);
 n=n-r*hs;
 q=[r;q];
 n=n(1:end-1);
 %pause
end
%bar(c,[q no],1);
v=2/3*pi*c.^3.*q;
bar(c,[100*q/sum(q) 100*v/sum(v) 100*no/sum(no)]);
legend({'3D diameter','Volume fraction','Feret diameter'});
mn=(c'*q)/sum(q);
gmn=exp((log(c)'*q)/sum(q));
st=sqrt(((c-mean(c)).^2)'*q/sum(q));

function hs=geths(k)

ds=1/k;
ix=(1:k)';
hs=sqrt(1-ds*(ix-1))-sqrt(1-ds*ix);

