function [rstat,tt]=phistnorm(a,varargin)
%PHISTNORM Plot histogram, normal distibution fit and calculate statistics.
% Syntax: stat=phistnorm(a,options);
% a could be grain/boundary object, column vector or cell array of column vectors
% for grouped plot.
% options are string evaluated by function (these are default values):
% 'scale'       ... 0...counts, 1...percents, 2...probability density
% 'nbins'       ... number of bins. default auto
% 'axislimits'  ... axis limits. default all data range
% 'barwidth'    ... bar width. Default 1
% 'color'       ... define color of bars
% 'linewidth'   ... width of distribution line. Default 2
% 'linecolor'   ... define color of fit line. Default 'r'
% 'confidence'  ... 1..plot confidence lines, )...none Default 1
% 'xlabel'      ... Label of x axis. Default based on input.
% Output is stat vector or matrix if cell is passed as input with colums
% contain mean, standard deviation

% when grain object is passed
if isa(a,'grain')
   a=get(a,'ead');
end 
if isa(a,'boundary')
    a=get(a,'CumLength');
end

%linearize and filter NaN's anf Inf's
a=a(:);
a=a(~isnan(a));
a=a(~isinf(a));
poc=size(a,1);
mini=min(a);
maxi=max(a);
% calculate stats
stat=[mean(a) std(a)];

% Process input arguments
rr=maxi-mini;
opts.axislimits=[mini-0.05*rr maxi+0.05*rr];
opts.scale=1;
opts.linewidth=2;
opts.linecolor='r';
opts.nbins=ceil(rr/(3.49*std(a)*poc^(-1/3))); %ceil(1+7*log10(mean(poc)));
opts.barwidth=1;
opts.confidence=1;
opts.xlabel=inputname(1);
if isempty(opts.xlabel)
    opts.xlabel='x';
end
opts.color='b';
opts=parseargs(varargin,opts);
% Recalculate nbins, mini and maxi when axislimits specified
aa=a(a>=opts.axislimits(1)&a<=opts.axislimits(2));
opts.nbins=ceil((max(aa)-min(aa))/(3.49*std(aa)*length(aa)^(-1/3)));
opts=parseargs(varargin,opts);

h=linspace(opts.axislimits(1),opts.axislimits(2)+10*eps,opts.nbins+1);
h_c=h(1:end-1)+(h(2)-h(1))/2;
binw=h(2)-h(1);
fx=linspace(opts.axislimits(1),opts.axislimits(2),200);

% calculate frequencies
tn=histc(a,h);
tn=tn(1:end-1);
nf=poc*binw*exp(-(fx-stat(1)).^2/2/stat(2)^2)./(stat(2)*sqrt(2*pi));

switch opts.scale
    case 1
        % recalculate on percents
        tn=100*tn/poc;
        nf=100*nf/poc;
    case 2
        tn=tn/poc/binw;
        nf=nf/poc/binw;
end

hh=bar(h(1:end-1)+(h(2)-h(1))/2,tn,opts.barwidth);
set(get(hh,'children'),'facecolor',opts.color);
hold on
hf=plot(fx,nf);
hold off
set(hf,'color',opts.linecolor);
set(hf,'linewidth',opts.linewidth);

ax=axis;
ax(1)=opts.axislimits(1);
ax(2)=opts.axislimits(2);
axis(ax);

%confidence intervals
if opts.confidence==1
    hk=line([stat(1)-2*stat(2) stat(1)-stat(2) stat(1)+stat(2) stat(1)+2*stat(2);stat(1)-2*stat(2) stat(1)-stat(2) stat(1)+stat(2) stat(1)+2*stat(2)],[0 0 0 0;ax(4) ax(4) ax(4) ax(4)]);
    set(hk,'color','k');
end

switch opts.scale
    case 1
        ylab='Percents';
    case 2
        ylab='Probability density';
    otherwise
        ylab='Counts';
end

tt=['No.:' num2str(poc) ' Mean:' num2str(stat(1)) ' StdDev.:' num2str(stat(2))];

if nargout>0
    rstat=stat;
end

if nargout<2
    title(tt);
end
    
ylabel(ylab);
xlabel(opts.xlabel);