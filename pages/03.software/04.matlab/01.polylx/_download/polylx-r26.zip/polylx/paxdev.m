function stat=paxdev(lao,sao,varargin)
%PAXDEV Plot histogram of projection axes deviation from orthogonality.
% Syntax: stat=paxdev(g,options);
%         stat=paxdev(lao,sao,options);
% when object is passed aparor is used to obtain lao and sao
% options are passed to phist, see help phist
% stat are statistics from phist output, see help phist.

if nargin<1
    help paxdev;
    return;
end

% when grain object is passed parr
if isa(lao,'grain')||isa(lao,'boundary')
   if nargin>1
       varargin=[{sao} varargin];
   end
   g=lao;
   [dummy,dummy,dummy,lao,sao]=aparor(g);
end 

% calculate deviations
ix1=find(lao>sao);
ix2=find(lao<sao);
d=[sao(ix1)-lao(ix1)+90;sao(ix2)-lao(ix2)-90];
stat=phist(d,varargin{:});
xlabel('Deviation of projection axes from right angle');
