function fnm=txtwrite(dsc,fnm)
%TXTWRITE Write ASCII delimited file with column headers.
%  Syntax: txtwrite(dsc,[fnm])
%   dsc   - could be cell array or double array
%
% Ondrej Lexa (c) 2003

if nargin<1
   help txtwrite
   return
end

if nargin<2
   [filename, path]=uiputfile('*.*', 'Export data');
   if filename==0
       fnm=[];
       return
   end
   fnm=[path filename];
end

if isa(dsc,'double')
 dsc=num2cell(dsc);
end


dlm = ',';
dlm = sprintf(dlm); % Handles special characters.
NEWLINE = sprintf('\r\n');

fid = fopen(fnm ,'w');
if fid == (-1), error(['Could not write to file ' fnm]); end

[br,bc]=size(dsc);

for i = 1:br
  for j = 1:bc
       hhh=dsc{i,j};
       if ~ischar(hhh)
          str = num2str(hhh);
       else
          str=['"' hhh '"'];
       end
       fwrite(fid, str, 'uchar');    
       if(j < bc)
           fwrite(fid, dlm, 'uchar');    
       end
   end
   fwrite(fid, NEWLINE, 'char');
end
fclose(fid);
