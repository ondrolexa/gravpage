function gi=ggincl(g,b,gsub)
%GGINCL Get grains which are inclusions of choosen grains.
% NOT YET IMPLEMENTED PROPERLY. DO NOT USE.
%Syntax: gi=ggincl(g,b,gsub);

if nargin<2
 disp('Not enough arguments');
 help ggincl;
 gi=[];
 return
end

nh=get(gsub,'nholes');
ix=find(nh>0);
id=get(g,'id');
ida=get(b,'ida');
idb=get(b,'idb');
gi=[];

for i=1:length(ix)
    
   n=[idb(find(ida==id(get(gsub(ix(i)),'id'))));ida(find(idb==id(get(gsub(ix(i)),'id'))))];
   h=get(gsub(ix(i)),'holes');
   for j=1:length(n),
      xx=get(g(id==n(j)),'x');
      yy=get(g(id==n(j)),'y');
      for k=1:nh(ix(i))
         if size(h(k).x,1)==size(xx,1)
            if flipud(h(k).x)==xx
               if flipud(h(k).y)==yy
                  gi=[gi g(id==n(j))];
               end
            end
         end
      end
   end
end
