function [g,b]=dbread(sample)
%DBREAD Read a grain geometry from database.
% When second output argument is provided, boundaries are automatically
% constructed.
% Syntax:  g=dbread;
%          [g,b]=dbread;
%          [g,b]=dbread(sample);

% Ondrej Lexa 2006

global polylx_prefs
%Check connection
if dbconnect

    if nargin<1
        res=dbcommand(['SELECT name FROM samples ORDER BY name']);
        if isempty(res)
            disp('No samples in open database. Aborting.');
            g=[];
            dbclose;
            return
        else
            [sel,ok] = listdlg('ListString',res,'SelectionMode','single','Name','Select sample');
            if ok==0
                g=[];
                dbclose;
                return
            else
                sample=res{sel};
            end
        end
    end

    % read sample
    res=dbcommand(['SELECT id FROM samples WHERE name=''' sample '''']);
    if isempty(res)
        disp(['No sample ' sample ' in open database. Aborting.']);
        g=[];
    else
        if strcmpi(polylx_prefs.driver,'MySQL')
            id_sample=res{1};
            h=fwaitbar(0,'Reading grains from database...');
            res=dbcommand(['SELECT id_grain,phase,AsText(geometry) FROM grains WHERE id_sample=' num2str(id_sample)]);

            poc=size(res,2);
            if poc>0
                g(1:poc)=grain;

                for i=1:poc;
                    wkt=res{3,i};
                    if ~ischar(wkt)
                        wkt=char(wkt');
                    end
                    co=sscanf(strrep(wkt(strfind(wkt,'((')+2:strfind(wkt,'))')-1),'),(',',NaN NaN,'),'%f %f,',[2,inf]);
                    g(i)=grain(res{1,i},res{2,i},co(1,:)',co(2,:)');
                    fwaitbar(i/poc,h);
                end
                close(h)
            end
            if nargout>1
                h=fwaitbar(0,'Reading boundaries from database...');
                res=dbcommand(['SELECT id_boundary,id_graina,id_grainb,phasea,phaseb,AsText(geometry) FROM boundaries WHERE id_sample=' num2str(id_sample)]);

                poc=size(res,2);
                if poc>0
                    b(1:poc)=boundary;
                    for i=1:poc;
                        wkt=res{6,i};
                        if ~ischar(wkt)
                            wkt=char(wkt');
                        end
                        co=sscanf(wkt(strfind(wkt,'(')+1:strfind(wkt,')')-1),'%f %f,',[2,inf]);
                        b(i)=boundary(res{1,i},res{2,i},res{3,i},res{4,i},res{5,i},co(1,:)',co(2,:)');
                        fwaitbar(i/poc,h);
                    end
                else
                    b=bmake(g);
                end
                close(h)
            end
        else
            dbcommand(['SET search_path TO ' sample ',public']);
            h=fwaitbar(0,'Reading grains from database...');
            res=dbcommand(['SELECT id_grain,phase,AsText(geometry) FROM grains']);
            poc=size(res,2);
            if poc>0
                g(1:poc)=grain;

                for i=1:poc;
                    wkt=res{3,i};
                    co=sscanf(strrep(wkt(strfind(wkt,'((')+2:strfind(wkt,'))')-1),'),(',',NaN NaN,'),'%f %f,',[2,inf]);
                    g(i)=grain(res{1,i},res{2,i},co(1,:)',co(2,:)');
                    fwaitbar(i/poc,h);
                end
                close(h)
            end
            if nargout>1
                b=bmake(g);
            end
        end
    end
    dbclose;
end
