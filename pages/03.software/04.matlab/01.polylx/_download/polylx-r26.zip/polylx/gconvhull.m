function gc=gconvhull(g)
%GCONVHULL Transform each grain into grain defined by convex hull of original grain.
% Syntax: gc=gconvhull(g);

if nargin<1
    gc=[];
    return
end

if ~isa(g,'grain');
    gc=[];
    return
end

h=fwaitbar(0,'Calculating...');
poc=length(g);
for i=1:poc
    [x,y]=get(g(i),'x','y');
    k=convhull(x,y);
    tt=plgeo(x(k),y(k));
    if sign(tt(1))>0
        gc(i)=grain(get(g(i),'id'),[char(get(g(i),'phase')) '-ch'],x(k),y(k),get(g(i),'UserData'));
    else
        gc(i)=grain(get(g(i),'id'),[char(get(g(i),'phase')) '-ch'],flipud(x(k)),flipud(y(k)),get(g(i),'UserData'));
    end
    fwaitbar(i/poc,h);
end
close(h)