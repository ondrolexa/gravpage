function dsc=dump(g,varargin)
%DUMP Dump grain/boundary properties to cell array.
% Syntax: dsc=dump(g);
%         dsc=dump(g,prop);  
%  g      - grain/boundary objects
%  prop   - properties of grain/boundary object to dump. See GET

% Ondrej Lexa (c) 2003

if nargin<1
   help dump
   return
end

if isempty(varargin)
 if isa(g,'grain')
   tlist=get(g);
   [typa,valid]=listdlg('PromptString','Select measurements:','ListString',tlist,'InitialValue',[2,5,7,9,11,12,14,18]);
 elseif isa(g,'boundary')
   tlist=get(g);
   [typa,valid]=listdlg('PromptString','Select measurements:','ListString',tlist,'InitialValue',[6,9,10,12,14]);
 else
   error('First argument must be grain/boundary object.');
 end
 if valid~=1
   disp ('Aborted.')
   return
 end
else
 tlist=varargin;
 typa=1:length(tlist);
end

dsc={class(g) tlist{typa}};
dt=num2cell(get(g,'id'));

for i=1:length(typa)
   f=get(g,tlist{typa(i)});
   if isa(f,'cell')
     dt=[dt f];
   else
     dt=[dt num2cell(f)];
   end
end

dsc=[dsc;dt];
