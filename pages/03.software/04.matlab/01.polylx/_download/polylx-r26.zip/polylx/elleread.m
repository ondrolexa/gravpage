function [g,out]=elleread(varargin)
%ELLEREAD Read grain geometry and attributes from ELLE inputfile.
% Syntax:  g=elleread;
%          g=elleread(filename);
%          [g,bb]=elleread(filename)
%    bb    - bounding box

% Ondrej Lexa 2006

% possible flynns attributes
possatt={'E_OPTIONS';'REGIONS';'PARENTS';'EXPAND';'COLOUR';'VELOCITY';'VEL_X';'VEL_Y';'STRESS';'TAU_XX';'TAU_YY';'TAU_ZZ';'TAU_XY';'TAU_1';'PRESSURE';'NUM_STRESS_VALS';'CONC_A';'NUM_NB';'TRPL_ONLY';'CAXIS';'CAXIS_X';'CAXIS_Y';'CAXIS_Z';'EULER_3';'E3_ALPHA';'E3_BETA';'E3_GAMMA';'ENERGY';'GBE_LUT';'VISCOSITY';'S_EXPONENT';'AGE';'CYCLE';'NUM_FLYNN_AGE_VALS';'DISLOCDEN';'MINERAL';'MINERAL_A';'MINERAL_B';'MINERAL_C';'STRAIN';'INCR_S';'BULK_S';'NUM_STRAIN_VALS';'FLYNN_STRAIN';'E_XX';'E_XY';'E_YY';'E_YX';'E_ZZ';'F_INCR_S';'F_BULK_S';'NUM_FLYNN_STRAIN_VALS';'SPLIT';'GRAIN';'F_ATTRIB_A';'F_ATTRIB_B';'F_ATTRIB_C';'F_ATTRIB_I';'F_ATTRIB_J';'F_ATTRIB_K'};

% GUI open file
pth=[]; fnm=[];
if isempty(varargin)
    [fnm, pth]=uigetfile({'*.elle','ELLE files (*.elle)'},'Open ELLE file');
    if fnm==0
        g=[]; flynn=[];
        return
    end
    filename=[pth fnm];
else
    filename=varargin{1};
    if ~exist(filename,'file')
        g=[]; flynn=[];
        error('First argument must be valid filename with extension. Aborted.');
    end
    ix=find(filename=='\');
    if isempty(ix);
        ix=0;
    end
    fnm=filename(ix(end)+1:end);
    pth=filename(1:ix(end));
end

fid=fopen([pth fnm]);
i=0;
while ~feof(fid);
    tline=fgetl(fid);
    ix=find(tline=='#',1);
    if ~isempty(ix);
        tline=tline(1:ix-1);
    end
    if ~isempty(tline)
        i=i+1;
        str{i,1}=tline;
    end
end 
fclose(fid);

%Find section starts and ends
ix=find(~cellfun(@isempty,regexp(str,'^[A-Z][A-Z_0-9][A-Z_0-9]*','start','once')));
zac=ix+1;
kon=[ix(2:end)-1;length(str)];

%CellBoundingBox
ixbx=strmatch('CellBoundingBox',str);
if isempty(ixbx)
    bb=[0 0;1 0;1 1;0 1];
else
    bb=str2num(strvcat(str{ixbx}(16:end),str{ixbx+1},str{ixbx+2},str{ixbx+3}));
end
bbdx=bb(2,1)-bb(1,1);
bbdy=bb(3,2)-bb(2,2);

%UnitLength
ixul=strmatch('UnitLength',str);
if isempty(ixul)
    ul=1;
else
    ul=str2num(str{ixul}(12:end));
end

%CumulativeSimpleShear
ixcss=strmatch('CumulativeSimpleShear',str);
if isempty(ixcss)
    css=0;
else
    css=str2num(str{ixcss}(22:end));
end

%FLYNNS
fix=strmatch('FLYNNS',str(ix));
h=fwaitbar(0,'Reading geometry...');
for i=0:(kon(fix)-zac(fix))
    [id,rem]=strtok(str{zac(fix)+i});
    flynn(i+1).id=str2num(id);
    [dummy,rem]=strtok(rem);
    locs{i+1}=str2num(rem);
    fwaitbar(i/(kon(fix)-zac(fix)),h);
end
close(h)

%LOCATION
lix=strmatch('LOCATION',str(ix));
loc=str2num(strvcat(str{zac(lix):kon(lix)}));

%Find FLYNNS attributes
[dummy,dix]=intersect(strtok(str(ix)),possatt);
ix2=sort(ix(dix));
ix3=sort(kon(dix));
ixopt=strncmp(str(ix2+1),'Default',7);

h=fwaitbar(0,'Parsing attributes...');
for i=1:length(ix2)
    [att,rem]=strtok(str{ix2(i)},char(9));
    %Check possible space in attribute name
    att=deblank(fliplr(deblank(fliplr(att))));
    att=strrep(att,' ','_');
    if ixopt(i)
        [dummy,dv]=strtok(str{ix2(i)+1});
        dv=deblank(fliplr(deblank(fliplr(dv))));
        offset=2;
    else
        offset=1;
    end
    if isempty(rem)
        %just one attribute
        [dummy,svalrem]=strtok(str{ix2(i)+offset});
        [firstval,svalrem]=strtok(svalrem);
        if ~isempty(str2num(firstval))
            %numeric
            if ixopt(i)
                [flynn.(att)]=deal(str2num(dv));
            end
            for k=ix2(i)+offset:ix3(i)
                [sid,sval]=strtok(str{k});
                fid=find(cat(1,flynn.id)==str2num(sid));
                if ~isempty(fid)
                    flynn(fid).(att)=str2num(sval);
                end
                fwaitbar((i-1+(k-ix2(i)-2)/ix3(i))/length(ix2),h);
            end
        else
            %string
            if ixopt(i)
                [flynn.(att)]=deal(dv);
            end
            for k=ix2(i)+offset:ix3(i)
                [sid,sval]=strtok(str{k});
                sval=deblank(fliplr(deblank(fliplr(sval))));
                fid=find(cat(1,flynn.id)==str2num(sid));
                if ~isempty(fid)
                    flynn(fid).(att)=sval;
                end
                fwaitbar((i-1+(k-ix2(i)-2)/ix3(i))/length(ix2),h);
            end
        end
    else
        %splitting
        poc=0;
        rem=str{ix2(i)};
        while ~isempty(rem)
            poc=poc+1;
            if ixopt(i)
                [dummy,dvv]=strtok(str{ix2(i)+1});
                dvv=deblank(fliplr(deblank(fliplr(dvv))));
                for j=1:poc
                    dvv=strtok(dvv);
                end
                offset=2;
            else
                offset=1;
            end
            [att,rem]=strtok(rem,char(9));
            %Check possible space in attribute name
            att=deblank(fliplr(deblank(fliplr(att))));
            att=strrep(att,' ','_');
            [dummy,svalrem]=strtok(str{ix2(i)+offset});
            for j=1:poc;
                [firstval,svalrem]=strtok(svalrem);
            end
            if ~isempty(str2num(firstval))
                %numeric
                if ixopt(i)
                    [flynn.(att)]=deal(str2num(dvv));
                end
                for k=ix2(i)+offset:ix3(i)
                    [sid,svalrem]=strtok(str{k});
                    for j=1:poc;
                        [sval,svalrem]=strtok(svalrem);
                    end
                    fid=find(cat(1,flynn.id)==str2num(sid));
                    if ~isempty(fid)
                        flynn(fid).(att)=str2num(sval);
                    end
                    fwaitbar((i-1+(k-ix2(i)-2)/ix3(i))/length(ix2),h);
                end
            else
                %string
                if ixopt(i)
                    [flynn.(att)]=deal(dvv);
                end
                for k=ix2(i)+offset:ix3(i)
                    [sid,svalrem]=strtok(str{k});
                    for j=1:poc;
                        [sval,svalrem]=strtok(svalrem);
                    end
                    fid=find(cat(1,flynn.id)==str2num(sid));
                    if ~isempty(fid)
                        flynn(fid).(att)=sval;
                    end
                    fwaitbar((i-1+(k-ix2(i)-2)/ix3(i))/length(ix2),h);
                end
            end
        end
    end
    fwaitbar((i-1)/length(ix2),h);
end
close(h)
nm=true;
ix=[];
fn=fieldnames(flynn);
if nargin>1
    ix=strmatch(varargin{2},fn,'exact');
    if ~isempty(ix)
        nm=false;
    end
end
if nm
    [ffn,ii]=setdiff(fn,'id');
    for i=1:length(ffn)
       if isa(flynn(1).(ffn{i}),'char')
           ffn{i}=[ffn{i} '(' num2str(length(unique({flynn.(ffn{i})}))) ')'];
       else
           ffn{i}=[ffn{i} '(' num2str(size(unique(cat(1,flynn.(ffn{i})),'rows'),1)) ')'];
       end
    end
    if ~isempty(ii)
        if length(ffn)==1
            ix=1;
        else
            [ix,ok]=listdlg('ListString',ffn,'SelectionMode','single','Name','Attributes','PromptString','Choose phase attribute:');
            if ok
                ix=ii(ix);
            end
        end
    else
        ix=[];
    end
end
h=fwaitbar(0,'Creating grains...');
bx=[];
for i=1:length(flynn)
    addbx=true;
    [c,ia,ib]=intersect(locs{i},loc(:,1));
    xx=zeros(length(ia),1);
    yy=xx;
    xx(ia)=loc(ib,2);
    yy(ia)=loc(ib,3);
    xx=[xx; xx(1)];
    yy=[yy; yy(1)];
    dy=diff(yy);
    id=find(abs(dy)>bbdy/2,1);
    while ~isempty(id)
        addbx=false;
        if dy(id)>0
            xx(id)=mod(xx(id)-bb(1,1)+css*bbdy,bbdx)+bb(1,1);
            %xx(id)=xx(id)+mod(css,bbdx)*bbdy;
            yy(id)=yy(id)+bbdy;
        else
            xx(id+1)=mod(xx(id+1)-bb(1,1)+css*bbdy,bbdx)+bb(1,1);
            %xx(id+1)=xx(id+1)+mod(css,bbdx)*bbdy;
            yy(id+1)=yy(id+1)+bbdy;
        end
        dy=diff(yy);
        id=find(abs(dy)>bbdy/2,1);
    end
    dx=diff(xx);
    id=find(abs(dx)>bbdx/2,1);
    while ~isempty(id)
        addbx=false;
        if dx(id)>0
            xx(id)=xx(id)+bbdx;
        else
            xx(id+1)=xx(id+1)+bbdx;
        end
        dx=diff(xx);
        id=find(abs(dx)>bbdx/2,1);
    end
    geom=plgeo(xx,yy);
    if sign(geom(1))~=1
        xx=flipud(xx);
        yy=flipud(yy);
    end
    if isempty(ix)
        g(i)=grain(flynn(i).id,'NotDefined',xx*ul,yy*ul);
    else
        g(i)=grain(flynn(i).id,flynn(i).(fn{ix}),xx*ul,yy*ul,rmfield(flynn(i),fn([1,ix])));
    end
    if addbx
        bx=[bx i];
    end
    fwaitbar(i/length(flynn),h);
end
% scale bounding box
out.CellBoundingBox=bb*ul;
out.InBox=bx;
out.UnitLength=ul;
out.CumulativeSimpleShear=css;
close(h)
