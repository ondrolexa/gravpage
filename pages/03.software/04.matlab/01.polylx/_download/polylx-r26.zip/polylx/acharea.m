function res=acharea(g,opt)
%ACHAREA Calculate area, perimeter, centroid of convex hull and bounding box of grains or boundaries.
% Syntax: res=acharea(g);
%         res=acharea(g,opt);
% res = [ area  perimeter  x_cen  y_cen x_min x_max y_min y_max]
% When opt is defined function returns only single property
% 1..area 2..perimeter 3.. x_cen 4..y_cen 5..x_min 6..x_max 7..y_min 8..y_max
% g is grain/boundary object(s)

if nargin<1
    help acharea
    return
end

x=[];
y=[];
for i=1:length(g);
    x=[x;get(g(i),'x')];
    y=[y;get(g(i),'y')];
end
k=convhull(x,y);
res=plgeo(x(k),y(k));
res(1)=abs(res(1));
res=[res min(x) max(x) min(y) max(y)];

if nargin>1
    res=res(opt);
end
