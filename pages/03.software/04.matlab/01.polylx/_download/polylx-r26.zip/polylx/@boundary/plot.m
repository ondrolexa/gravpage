function plot(g,varargin)
%BOUNDARY/PLOT Plot boundary objects b on active figure
%   PLOT(b,options) plot grain objects b on active figure.
%Options
%  'noleg'    ... do not place legend
%  'vertex'   ... plot vertices
%   ct or pal ... colortable (GENCT) or pallete (MAKEPAL)
%   bb        ... bounding box. double of size [4 2]. see ELLEREAD

poc=length(g);
leg=1;
vert=0;
lw=1;
pltbx=0;
% process inputs
for i=1:length(varargin)
    switch class(varargin{i})
        case 'char'
            switch lower(varargin{i})
                case {'on','leg=1'}
                    leg=1;
                case {'noleg','off','leg=0'}
                    leg=0;
                case 'vertex'
                    vert=1;
                otherwise
                    error('Wrong argument !');
            end
        case 'cell'
            %check template
            if size(varargin{i},2)==2
                tmpl=varargin{i};
                pal=[repmat({[0]},poc,1) repmat({''},poc,1) repmat({[0 0 0]},poc,1)];
                for ii=1:size(tmpl,1)
                    ix=btsel(g,tmpl{ii,1});
                    if ~isempty(ix)
                        pal(ix,1)={ii};
                        pal(ix,2)={[tmpl{ii,1} ' (' num2str(length(ix)) ')']};
                        pal(ix,3)={tmpl{ii,2}};
                    end
                end
            else
                pal=varargin{i};
            end
        case 'double'
            if all(size(varargin{i})==[4 2])
                bb=varargin{i};
                pltbx=1;
            elseif all(size(varargin{i})==[1 1])
                lw=varargin{i};
            end
        otherwise
            error('Wrong argument !');
    end
end
if ~exist('pal','var')
    pal=makepal(g);
end
%Check pallete
if ~all(size(pal)==[poc 3])==iscell(pal)
    error('Palette is not compatible with passed grains objects! Use makepal.');
end
% Clear figure when not holded
if ~ishold
 clf
end
set(gca,'Box','on','TickDir','out','XminorTick','on','YminorTick','on');
htlist=[];
zoz=unique(pal(:,2));
for i=1:length(zoz)
    if ~isempty(zoz{i})
        ix=strmatch(zoz{i},pal(:,2));
        if ~isempty(ix)
            cx=[];
            cy=[];
            for m=1:length(ix)
                cx=[cx;NaN;get(g(ix(m)),'x')];
                cy=[cy;NaN;get(g(ix(m)),'y')];
            end
            ht=line(cx(2:end),cy(2:end),'Color',pal{ix(1),3},'LineWidth',lw);
            if vert
                set(ht,'Marker','.')
            end
            htlist=[htlist;ht ix(1)];
        end
    end
end
axis equal
% Show legend
if leg==1
    [dummy,ix]=sort(cat(1,pal{htlist(:,2),1}));
    h=legend(htlist(ix,1),pal(htlist(ix,2),2),0);
    set(h,'FontSize',8);
end
% Plot boundaing box from elle files
if pltbx==1
    bb=[bb;bb(1,:)];
    line(bb(:,1),bb(:,2),'Color','k');
end
