function varargout = get(b, varargin)
%BOUNDARY/GET - return boundary properties

if nargout~=(nargin-1)&&nargout>1
    error('Wrong Number of arguments')
end

n=length(b);
val2=[];
noerr=0;
if nargin>1
    for i=1:length(varargin);
        switch lower(varargin{i})
            case 'id'
                val = cat(1,b.id);
            case 'ida'
                val = cat(1,b.ida);
            case 'idb'
                val = cat(1,b.idb);
            case 'phasea'
                val=cell(length(b),1);
                [val{:}]=deal(b.phasea);
            case 'phaseb'
                val=cell(length(b),1);
                [val{:}]=deal(b.phaseb);
            case 'type'
                val=cell(length(b),1);
                [val{:}]=deal(b.type);
            case 'x'
                if n == 1
                    val = b.x;
                else
                    error('This property is valid only for single boundary object.')
                end
            case 'y'
                if n == 1
                    val = b.y;
                else
                    error('This property is valid only for single boundary object.')
                end
            case 'xcentre'
                for ii=1:n
                    val(ii) = (max(b(ii).x) + min(b(ii).x))/2;
                end
                val=val(:);
            case 'ycentre'
                for ii=1:n
                    val(ii) = (max(b(ii).y) + min(b(ii).y))/2;
                end
                val=val(:);
            case 'cumlength'
                val = cat(1,b.cumlength);
            case 'length'
                val = cat(1,b.length);
            case 'width'
                val = cat(1,b.width);
            case 'axialratio'
                val = cat(1,b.width)./cat(1,b.length);
                val(val<1e-10)=NaN;
                val=1./val;
            case 'orientation'
                val = cat(1,b.orientation);
            case 'f'
                val = cat(1,b.cumlength)./cat(1,b.length);
            case 'straightness'
                val = (cat(1,b.cumlength)-cat(1,b.length))./cat(1,b.length);
            case 'logstraightness'
                val = log10((cat(1,b.cumlength)-cat(1,b.length))./cat(1,b.length));
            case 'userdata'
                if nargin>i+1&&~isempty(strmatch(varargin{i+1},fieldnames(b(1).userdata),'exact'))
                    if isnumeric(b(1).userdata.(varargin{i+1}))
                        for ii=1:length(b)
                            val(ii,:) = b(ii).userdata.(varargin{i+1});
                        end
                    else
                        for ii=1:length(b)
                            val{ii,:} = b(ii).userdata.(varargin{i+1});
                        end
                    end
                    noerr=1;
                else
                    if i>1||nargin>2
                        error('UserData cannot be collated.');
                    else
                        for ii=1:length(b)
                            val(ii) = b(ii).userdata;
                        end
                        if isempty(fieldnames(val))
                            val=struct([]);
                        end
                    end
                end
            otherwise
                if ~noerr
                    error([varargin{i},' is not valid boundary property']);
                else
                    val=[];
                    noerr=0;
                end
        end
        try
            val2=[val2 val];
        catch
            error('Not allowed combination of properties.');
        end
    end
    if nargout==size(val2,2)
        for i=1:nargout
            varargout{i}=val2(:,i);
        end
    else
        varargout{1}=val2;
    end
else
    if nargout>0
        varargout{1}={'ID','IDA','IDB','PhaseA','PhaseB','Type','XCentre','YCentre','CumLength','Length','Width','Orientation','AxialRatio','Straightness','LogStraightness','UserData'};
    else
        disp('Available boundary properties are:');
        disp('  ID');
        disp('  IDA');
        disp('  IDB');
        disp('  PhaseA');
        disp('  PhaseB');
        disp('  Type');
        disp('  X (for single boundary only)');
        disp('  Y (for single boundary only)');
        disp('  XCentre');
        disp('  YCentre');
        disp('  CumLength');
        disp('  Length');
        disp('  Width');
        disp('  Orientation');
        disp('  AxialRatio');
        disp('  Straightness');
        disp('  LogStraightness - log10 of straightness');
        disp('  UserData');
    end
end
