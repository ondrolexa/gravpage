function [la,sa,lao,sao]=aorten(g,plt)
%AORTEN Return results of Ellipse fitting using orientation tensor.
% Syntax: [la,sa,lao,sao]=aorten(g,plt);
% g can be grain and boundary object(s)
% Plot option plt 1..plot crosses 2..plot ellipses 3..ellipses and crosses

if nargin<2
    plt=0;
end

%Initialize
poc=length(g);
la=[]; sa=[]; lao=[]; sao=[];

h=fwaitbar(0,'Calculating...');
for ii=1:poc
    [x,y]=get(g(ii),'x','y');
    if isa(g,'grain')
        x=x(1:end-1)-get(g(ii),'xcentre');
        y=y(1:end-1)-get(g(ii),'ycentre');
    else
        x=x-get(g(ii),'xcentre');
        y=y-get(g(ii),'ycentre');
    end
    
    m=([x y]'*[x y])/length(x);
    
    % Calculate eigenvalues and eigenvectors
    [v,c]=eig(m);
    if c(2,2)<c(1,1)  % Sort eigenvalues and eigenvectors
        c=rot90(c,2);
        v=fliplr(v);
    end

    c(c<0)=0; % chybicka zaokruhlovania

    la = [la; 2*sqrt(c(2,2))*sqrt(2)];
    sa = [sa; 2*sqrt(c(1,1))*sqrt(2)];
    lao = [lao; mod(deg(atan2(v(1,2),v(2,2))),180)];
    sao = [sao; mod(deg(atan2(v(1,1),v(2,1))),180)];

    fwaitbar(ii/poc,h);
end
close(h)

if plt~=0
    if bitget(plt,1)==1
        pcross(la/2,sa/2,lao,[get(g,'xcentre') get(g,'ycentre')],'k');
    end
    if bitget(plt,2)==1
        pellipse(la/2,sa/2,lao,[get(g,'xcentre') get(g,'ycentre')],'k');
    end
end
