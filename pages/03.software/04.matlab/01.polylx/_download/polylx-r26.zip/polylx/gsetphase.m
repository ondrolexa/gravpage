function gn=gsetphase(g,ix,ph)
%GSETPHASE Change phase name of choosen grains.
% All grains choosen by index vector ix are assigned to be of phase ph
% Syntax: gn=gsetphase(g,ix,ph);
%  g     - grain objects
%  ix    - index vector of choosen grains. All grains when empty
%  ph    - new phase name

if nargin<3
    help gsetphase
    gn=[];
    return
end

if isempty(ix)
    ix=1:length(g);
end

for i=1:length(g)
    if any(ix==i)
        [x,y]=get(g(i),'x','y');
        nh=get(g(i),'nholes');
        if nh~=0
            h=get(g(i),'holes');
            for j=1:nh
                x=[x;NaN;h(j).x];
                y=[y;NaN;h(j).y];
            end
        end
        gn(i)=grain(get(g(i),'id'),ph,x,y,get(g(i),'userdata'));
    else
        gn(i)=g(i);
    end
end
