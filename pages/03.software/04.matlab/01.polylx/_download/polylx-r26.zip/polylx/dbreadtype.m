function b=dbreadtype(samples,type)
%DBREADTYPE Read all boundaries of choosen type from MySQL database.
% Syntax:  b=dbreadtype;
%          b=dbreadtype(samples,type);

global polylx_prefs
%Check connection
if dbconnect
    if ~strcmpi(polylx_prefs.driver,'MySQL')
        dbclose
        error('Supported only for MySQL database');
    end
    if nargin<1
        samples=dbcommand(['SELECT name FROM samples']);
        if isempty(samples)
            disp('No samples in open database. Aborting.');
            g=[];
            dbclose
            return
        end
    end
    if nargin<2
        res=dbcommand('SELECT phasea,phaseb FROM boundaries');
        if isempty(res)
            disp('No boundaries of given type in open database. Aborting.');
            b=[];
            dbclose;
            return
        else
            tt=unique([res(1,:) res(2,:)]);
            poc=length(tt);
            ix=0;
            for i=1:poc
                for j=i:poc
                    ix=ix+1;
                    bb{ix}=[tt{i} '-' tt{j}];
                end
            end
            tl=bb';

            [sel,ok] = listdlg('ListString',tl,'SelectionMode','single','Name','Select sample');
            if ok==0
                g=[];
                dbclose;
                return
            else
                type=tl{sel};
            end
        end
    end
    ix=strfind(type,'-');
    pa=type(1:ix-1);
    pb=type(ix+1:end);
    
    if ~exist('samples','var')
        h=fwaitbar(0,'Reading boundaries from database...');
        res=dbcommand(['SELECT boundaries.id_boundary,boundaries.id_graina,boundaries.id_grainb,samples.name,AsText(geometry) FROM samples INNER JOIN boundaries ON (samples.id=boundaries.id_sample) WHERE ((boundaries.phasea="' pa '") AND (boundaries.phaseb="' pb '")) OR ((boundaries.phasea="' pb '") AND (boundaries.phaseb="' pa '"))']);
        
        poc=size(res,2);
        if poc>0
            b(1:poc)=boundary;
            
            for i=1:poc;
                wkt=res{5,i};
                if ~ischar(wkt)
                    wkt=char(wkt');
                end
                co=sscanf(wkt(strfind(wkt,'(')+1:strfind(wkt,')')-1),'%f %f,',[2,inf]);
                b(i)=boundary(res{1,i},res{2,i},res{3,i},res{4,i},'',co(1,:)',co(2,:)');
                fwaitbar(i/poc,h);
            end
            close(h)
        end
    else
        ii=1;
        for k=1:length(samples)
            res=dbcommand(['SELECT boundaries.id_boundary,boundaries.id_graina,boundaries.id_grainb,samples.name,AsText(geometry) FROM samples INNER JOIN boundaries ON (samples.id=boundaries.id_sample) WHERE samples.name="' samples{k} '" AND (((boundaries.phasea="' pa '") AND (boundaries.phaseb="' pb '")) OR ((boundaries.phasea="' pb '") AND (boundaries.phaseb="' pa '")))']);
            poc=size(res,2);
            if poc>0
                b(ii:poc+1)=boundary;
                h=fwaitbar(0,['Reading boundaries ' num2str(k) ' of ' num2str(length(samples)) ' from database...']);
                for i=1:poc;
                    wkt=res{5,i};
                    if ~ischar(wkt)
                        wkt=char(wkt');
                    end
                    co=sscanf(wkt(strfind(wkt,'(')+1:strfind(wkt,')')-1),'%f %f,',[2,inf]);
                    b(ii+i-1)=boundary(res{1,i},res{2,i},res{3,i},res{4,i},'',co(1,:)',co(2,:)');
                    fwaitbar(i/poc,h);
                end
                ii=ii+poc;
                close(h)
            end
        end
    end
end

dbclose;
