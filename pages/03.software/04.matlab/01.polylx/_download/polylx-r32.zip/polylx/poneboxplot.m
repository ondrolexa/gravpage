function [hhigh, llow] = poneboxplot(data, xpos, varargin)
%PONEBOXPLOT Routine to plot box-and-whisker plot of data on given x position.
% Syntax: poneboxplot(data,xpos,options);
% The bottom and top of the box are the 25th and 75th  percentile
% (the lower Q1 and upper Q3 quartiles, respectively), and the band near
% the middle of the box is the 50th percentile (the median).
% The ends of the whiskers represent the 2nd and the 98th percentile.
% Optionally datarange and outliers are plotted.
% data is vector and xpos is scalar position of the boxplot  on x axis.
% options are passed as pairs of option name and option value:
% 'halfwidth'   ... Halfwidth of boxplot. Default 0.3
% 'outliers'    ... 0 ... do not plot 1 ... plot outliers. Default 1
% 'datarange'   ... 0 ... do not plot 1 ... plot datarange. Default 1

% This file is part of polyLX.
% 
% polyLX is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% polyLX is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with polyLX.  If not, see <http://www.gnu.org/licenses/>.

% polyLX - MATLAB toolbox for microstructure analyses
% Copyright (C) 2010 Ondrej Lexa

if nargin<2
    help poneboxplot
    return
end

% initialize defaults and parse arguments
opts.halfwidth=0.3;
opts.datarange=1;
opts.outliers=1;
opts=parseargs(varargin,opts);

% linearize data
data=real(data(:));
% do
foo = percentil(data, [2, 25, 50, 75, 98]);
q1 = foo(2); q2 = foo(3); q3 = foo(4);
bottom = foo(1); top = foo(5);

xleft=xpos-opts.halfwidth; xright=xpos+opts.halfwidth;

high = max(data);
low  = min(data);
%top = min( high, q3+1.5*(q3-q1) );
%bottom = max( low, q1-1.5*(q3-q1) );
outliers = data( data<bottom | data>top );
xvals = xpos*ones(size(outliers));

hold on
plot([xleft xleft xright xright xleft],[q1 q3 q3 q1 q1], 'k-',...
   [xleft xright], [q2 q2], 'k-', ...
   [xpos xpos (xpos-opts.halfwidth/3) (xpos+opts.halfwidth/3)],... 
   [q3 top top top],'k-', ...
   [xpos xpos (xpos-opts.halfwidth/3) (xpos+opts.halfwidth/3)],... 
   [q1 bottom bottom bottom],'k-');
if opts.datarange == 1
    plot([xpos xpos], [top high],'k:',...
        [xpos xpos], [bottom low], 'k:');
end
if opts.outliers == 1
    plot(xvals, outliers, 'k.')
end
hold off
if nargout>0
    hhigh=high;
    llow=low;
end