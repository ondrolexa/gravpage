function [g,pth,fnm]=sxmread(varargin)
%SXMREAD Read grain geometry from Image SXM XY coordinates file.
% Syntax:  [g,path,filename]=sxmread;
%          [g,path,filename]=sxmread(filename);

% This file is part of polyLX.
% 
% polyLX is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% polyLX is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with polyLX.  If not, see <http://www.gnu.org/licenses/>.

% polyLX - MATLAB toolbox for microstructure analyses
% Copyright (C) 2010 Ondrej Lexa

% GUI open file
pth=[]; fnm=[];
if isempty(varargin)
    [fnm, pth]=uigetfile({'*.*','Image SXM file'},'Open Image SXM file');
    if fnm==0
        g=[];
        return
    end
    filename=[pth fnm];
else
    filename=varargin{1};
    if ~exist(filename,'file')
        g=[];
        error('First argument must be valid filename with extension. Aborted.');
    end
    [pth,n,e]=fileparts(filename);
    fnm=[n e];
    pth=[pth filesep];
end

fid=fopen(filename);
C=textscan(fid,'%s');
fclose(fid);
C=C{1,1};

% find grains
ixpoly=[find(strcmp('0', C));length(C)+1;length(C)+2];
poc=length(ixpoly)/2;

h=waitbar(0,'Please wait...','Name','Reading geometry...');

zac=1;
for i=1:poc
    x=str2double(C(zac:2:ixpoly(2*i)-3));
    y=-str2double(C(zac+1:2:ixpoly(2*i)-2));
    if length(x)>3
        geom=plgeo(x,y);
        if sign(geom(1))~=1
            x=flipud(x);
            y=flipud(y);
        end
        g(i)=polylxgrain(i,'Grain',x,y);
    end
    zac=ixpoly(2*i)+1;
    waitbar(i/poc,h);
end
close(h)
