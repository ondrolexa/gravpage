function plot(g,varargin)
%PLOT Plot grain objects g on active figure
%Syntax: plot(g,options);
% options are passed as pairs of option name and option value:
%  'grains'   ... 0.. do not plot 1.. plot Default 1.
%  'outlines' ... 0.. do not plot 1.. plot Default 0.
%  'cross'    ... 0.. do not plot 1.. plot Default 0.
%  'scale'    ... scaling of cross axes. Default 0.5
%  'leg'      ... nonzero show legend. Defaut 1.
%  'vertex'   ... nonzero plot vertices. Default 0.
%  'pal'      ... colortable (GENCT) or pallete (MAKEPAL Default)
%  'color'    ... color of outlines or crosses. Default 'k'.
%  'width'    ... width of lines. Default 1.
%  'box'      ... 4x2 matrix plot bounding box (see ELLEREAD) Default 0.

% This file is part of polyLX.
% 
% polyLX is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% polyLX is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with polyLX.  If not, see <http://www.gnu.org/licenses/>.

% polyLX - MATLAB toolbox for microstructure analyses
% Copyright (C) 2010 Ondrej Lexa

% Process input arguments
opts.grains=1;
opts.outlines=0;
opts.cross=0;
opts.leg=1;
opts.vertex=0;
opts.pal=makepal(g);
opts.color='k';
opts.width=1;
opts.box=0;
opts.scale=0.5;
opts=parseargs(varargin,opts);

if ~any([opts.grains opts.outlines opts.cross])
    disp('Nothing to do...')
    return
end

% Outlines are exclusive
if opts.outlines || opts.cross
    opts.grains=0;
end

poc=length(g);

%Check colortable
if size(opts.pal,2)==2
    pal=[repmat({[0]},poc,1) repmat({''},poc,1) repmat({[0 0 0]},poc,1)];
    for ii=1:size(opts.pal,1)
        ix=gpsel(g,opts.pal{ii,1});
        if ~isempty(ix)
            pal(ix,1)={ii};
            pal(ix,2)={[opts.pal{ii,1} ' (' num2str(length(ix)) ')']};
            pal(ix,3)={opts.pal{ii,2}};
        end
    end
    opts.pal=pal;
end

%Check pallete
if ~all(size(opts.pal)==[poc 3])
    error('Palette is not compatible with passed grains objects! Use makepal.');
end

% Clear figure when not holded
if ~ishold
    clf
end
set(gca,'Box','on','TickDir','out','XminorTick','on','YminorTick','on');
% Plot grains
if opts.grains
    a=get(g,'outarea');
    [dummy,zorder]=sort(a);
    zorder=flipud(zorder);
    htlist=[];
    bkc=get(gca,'Color');
    for i=1:poc
        if opts.pal{zorder(i),1}>0
            %plot outerarea
            [x,y]=get(g(zorder(i)),'x','y');
            ht=patch(x,y,opts.pal{zorder(i),3},'ButtonDownFcn','getsel','Tag','grain','SelectionHighlight','off','LineWidth',opts.width,'UserData',[zorder(i) get(g(zorder(i)),'xcentre') get(g(zorder(i)),'ycentre') opts.pal{zorder(i),3}]);
            if opts.vertex
                set(ht,'Marker','.')
            end
            htlist=[htlist; ht];
            %plot holes
            h=get(g(zorder(i)),'holes');
            for j=1:get(g(zorder(i)),'nholes')
                patch(h(j).x,h(j).y,bkc);
            end
        else
            htlist=[htlist; patch];
        end
    end
end
% Plot outlines
if opts.outlines
    for i=1:poc
        [x,y]=get(g(i),'x','y');
        line(x,y,'Color',opts.color,'LineWidth',opts.width);
        h=get(g(i),'holes');
        for j=1:length(h)
            line(h(j).x,h(j).y,'Color',opts.color,'LineWidth',opts.width);
        end
    end
end
% Plot crosses
if opts.cross
    c=get(g,'xcentre','ycentre');
    [l,w,o]=get(g,'length','width','orientation');
    for i=1:poc    
        a=opts.scale*[sind(o(i))*l(i)/2 cosd(o(i))*l(i)/2];
        b=opts.scale*[sind(o(i)+90)*w(i)/2 cosd(o(i)+90)*w(i)/2];
        la=[c(i,:)-a;c(i,:)+a];
        lb=[c(i,:)-b;c(i,:)+b];
        line([la(:,1) lb(:,1)],[la(:,2) lb(:,2)],'Color',opts.color,'LineWidth',opts.width);
    end
end
axis equal
axis tight
ax=axis;
dax=diff(ax);
axis([ax(1)-dax(1)/100 ax(2)+dax(1)/100 ax(3)-dax(3)/100 ax(4)+dax(3)/100]);

% Add callback and show legend for grains plot
if opts.grains
    set(gcf, 'WindowButtonDownFcn', 'rectsel')
    if opts.leg
        [u,i,dummy]=unique(opts.pal(zorder,2));
        uhtlist=htlist(i);
        [dummy,ix]=sort(cat(1,opts.pal{zorder(i),1}));
        h=legend(uhtlist(ix(~cellfun(@isempty,cellstr(get(uhtlist,'tag'))))),u(ix(~cellfun(@isempty,cellstr(get(uhtlist,'tag'))))));
        set(h,'FontSize',8);
    end
end

% Plot boundaing box from elle files
if all(size(opts.box)==[4 2])
    bb=[opts.box;opts.box(1,:)];
    line(bb(:,1),bb(:,2),'Color','k');
end
