function ix=gpsel(g,varargin)
%GPSEL Grain phase select. Return indexes into objects array with phase(s) ph.
% Syntax: ix=gpsel(g,ph);

% This file is part of polyLX.
% 
% polyLX is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% polyLX is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with polyLX.  If not, see <http://www.gnu.org/licenses/>.

% polyLX - MATLAB toolbox for microstructure analyses
% Copyright (C) 2010 Ondrej Lexa

% GUI choose props
if isempty(varargin)
    upl=gplist(g);
    [phx,c]=listdlg('ListString',upl,'Name','Choose Phase(s)','ListSize',[150 200],'CancelString','Exit');
    if c==0
        ix=[];
        return
    end
    tp=upl(phx);
else
    tp=varargin;
end

plist=get(g,'phase');

ix=[];
for i=1:length(tp);
    ix=[ix;find(strcmp(tp{i},plist))];
end
ix=unique(ix);
