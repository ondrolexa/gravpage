function varargout = get(g, varargin)
%GET Get grain properties

% This file is part of polyLX.
% 
% polyLX is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% polyLX is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with polyLX.  If not, see <http://www.gnu.org/licenses/>.

% polyLX - MATLAB toolbox for microstructure analyses
% Copyright (C) 2010 Ondrej Lexa

if nargout~=(nargin-1)&&nargout>1
    error('Wrong Number of arguments')
end

n=length(g);
val2=[];
noerr=0;
if nargin>1
    for i=1:length(varargin);
        switch lower(varargin{i})
            case 'id'
                val = cat(1,g.id);
            case 'phase'
                val=cell(length(g),1);
                [val{:}]=deal(g.phase);
            case 'x'
                if n == 1
                    val = g.x;
                else
                    error('This property is valid only for single grain object.')
                end
            case 'y'
                if n == 1
                    val = g.y;
                else
                    error('This property is valid only for single grain object.')
                end
            case 'area'
                val = cat(1,g.area);
            case 'perimeter'
                val = cat(1,g.perimeter);
            case {'length','la','feret'}
                val = cat(1,g.length);
            case {'loglength'}
                val = log10(cat(1,g.length));
            case {'width','sa'}
                val = cat(1,g.width);
            case {'axialratio','ar'}
                val = cat(1,g.length)./cat(1,g.width);
            case {'logaxialratio','logar'}
                val = log10(cat(1,g.length)./cat(1,g.width));
            case {'invaxialratio','iar'}
                val = cat(1,g.width)./cat(1,g.length);
            case {'orientation','lao'}
                val = cat(1,g.orientation);
            case 'sao'
                val = mod(cat(1,g.orientation)+90,180);
            case {'xcentre','xc'}
                val = cat(1,g.xcentre);
            case {'ycentre','yc'}
                val = cat(1,g.ycentre);
            case 'ead'
                val = 2*sqrt(cat(1,g.area)/pi);
            case 'logead'
                val = log10(2*sqrt(cat(1,g.area)/pi));
            case 'ear'
                val = sqrt(cat(1,g.area)/pi);
            case 'eap'
                val = 2*pi*sqrt(cat(1,g.area)/pi);
            case 'elongation'
                val = (pi*cat(1,g.length).^2)./(4*cat(1,g.area));
            case 'roundness'
                val = (4*cat(1,g.area))./(pi*cat(1,g.length).^2);
            case 'circularity'
                val = (4*pi*cat(1,g.area))./(cat(1,g.perimeter).^2);
            case 'compactness'
                val = 4*cat(1,g.area)./(cat(1,g.perimeter).*cat(1,g.length));
            case 'gsi'
                val = 2*pi*sqrt(cat(1,g.area)/pi)./cat(1,g.length);
            case 'gsf'
                val = (cat(1,g.length)./cat(1,g.width)).^(0.318).*cat(1,g.perimeter)./(2*sqrt(cat(1,g.area)));
            case {'f','fractdim'}
                val= cat(1,g.perimeter)./(2*pi*sqrt(cat(1,g.area)/pi));
            case 'nholes'
                val = cat(1,g.nholes);
            case 'holes'
                if n == 1
                    if g.nholes~=0
                        val=g.holes;
                    else
                        val=struct([]);
                    end
                else
                    disp('This property is valid only for single object.')
                end
            case 'outarea'
                for ii=1:n
                    val(ii) = g(ii).area + sum(cat(1,g(ii).holes.area));
                end
                val=val(:);
            case 'outperimeter'
                for ii=1:n
                    val(ii) = g(ii).perimeter - sum(cat(1,g(ii).holes.perimeter));
                end
                val=val(:);
            case 'outead'
                for ii=1:n
                    oa(ii) = g(ii).area + sum(cat(1,g(ii).holes.area));
                end
                oa=oa(:);
                val = 2*sqrt(oa/pi);
            case 'outear'
                for ii=1:n
                    oa(ii) = g(ii).area + sum(cat(1,g(ii).holes.area));
                end
                oa=oa(:);
                val = sqrt(oa/pi);
            case 'outeap'
                for ii=1:n
                    oa(ii) = g(ii).area + sum(cat(1,g(ii).holes.area));
                end
                oa=oa(:);
                val = 2*pi*sqrt(oa/pi);
            case 'outelongation'
                for ii=1:n
                    oa(ii) = g(ii).area + sum(cat(1,g(ii).holes.area));
                end
                oa=oa(:);
                val = (pi*cat(1,g.length).^2)./(4*oa);
            case 'outroundness'
                for ii=1:n
                    oa(ii) = g(ii).area + sum(cat(1,g(ii).holes.area));
                end
                oa=oa(:);
                val = (4*oa)./(pi*cat(1,g.length).^2);
            case 'outcircularity'
                for ii=1:n
                    oa(ii) = g(ii).area + sum(cat(1,g(ii).holes.area));
                    op(ii) = g(ii).perimeter - sum(cat(1,g(ii).holes.perimeter));
                end
                oa=oa(:);
                op=op(:);
                val = 4*oa./(op.*cat(1,g.length));
            case 'outellipticity'
                for ii=1:n
                    oa(ii) = g(ii).area + sum(cat(1,g(ii).holes.area));
                end
                oa=oa(:);
                val = pi*cat(1,g.length).^2./oa/2;
            case 'outcompactness'
                for ii=1:n
                    oa(ii) = g(ii).area + sum(cat(1,g(ii).holes.area));
                    op(ii) = g(ii).perimeter - sum(cat(1,g(ii).holes.perimeter));
                end
                oa=oa(:);
                op=op(:);
                val = (op.^2)./(4*pi*oa);
            case 'outgsi'
                for ii=1:n
                    oa(ii) = g(ii).area + sum(cat(1,g(ii).holes.area));
                end
                oa=oa(:);
                val = 2*pi*sqrt(oa/pi)./cat(1,g.length);
            case 'outgsf'
                for ii=1:n
                    oa(ii) = g(ii).area + sum(cat(1,g(ii).holes.area));
                    op(ii) = g(ii).perimeter - sum(cat(1,g(ii).holes.perimeter));
                end
                oa=oa(:);
                op=op(:);
                val = (cat(1,g.length)./cat(1,g.width)).^(0.318).*op./(2*sqrt(oa));
            case {'outf','outfractdim'}
                for ii=1:n
                    oa(ii) = g(ii).area + sum(cat(1,g(ii).holes.area));
                    op(ii) = g(ii).perimeter - sum(cat(1,g(ii).holes.perimeter));
                end
                oa=oa(:);
                op=op(:);
                val= op./(2*pi*sqrt(oa/pi));
            case 'userdata'
                if nargin>i+1 && any(strcmp(varargin{i+1},fieldnames(g(1).userdata)))
                    if isnumeric(g(1).userdata.(varargin{i+1}))
                        for ii=1:length(g)
                            val(ii,:) = g(ii).userdata.(varargin{i+1});
                        end
                    else
                        for ii=1:length(g)
                            val{ii,:} = g(ii).userdata.(varargin{i+1});
                        end
                    end
                    noerr=1;
                else
                    if i>1||nargin>2
                        error('UserData cannot be collated.');
                    else
                        for ii=1:length(g)
                            val(ii) = g(ii).userdata;
                        end
                        if isempty(fieldnames(val))
                            val=struct;
                        end
                    end
                end
            case 'xhex'
                if n == 1
                    x = g.x;
                    if g.nholes>0
                        h = g.holes;
                        for ii=1:length(h)
                            x = [x;NaN;h(ii).x];
                        end
                    end
                    val = reshape(dec2hex(typecast(x,'uint8')),1,[]);
                else
                    error('This property is valid only for single grain object.')
                end
            case 'yhex'
                if n == 1
                    y = g.y;
                    if g.nholes>0
                        h = g.holes;
                        for ii=1:g.nholes
                            y = [y;NaN;h(ii).y];
                        end
                    end
                    val = reshape(dec2hex(typecast(y,'uint8')),1,[]);
                else
                    error('This property is valid only for single grain object.')
                end
            case 'wkt'
                if n == 1
                    val='POLYGON((';
                    co=sprintf('%.8f %.8f,',[g.x g.y]');
                    val=[val co(1:end-1)];
                    h=g.holes;
                    for ii=1:g.nholes
                        co=sprintf('%.8f %.8f,',[h(ii).x h(ii).y]');
                        val=[val '),(' co(1:end-1)];
                    end
                    val=[val '))'];
                else
                    error('This property is valid only for single grain object.')
                end
            otherwise
                if ~noerr
                    error([varargin{i},' is not valid grain property.']);
                else
                    val=[];
                    noerr=0;
                end
        end
        try
            val2=[val2 val];
        catch
            error('Not allowed combination of properties.');
        end
    end
    if nargout==size(val2,2)
        for i=1:nargout
            varargout{i}=val2(:,i);
        end
    else
        varargout{1}=val2;
    end
else
    if nargout>0
        varargout{1}={'ID','Phase','XCentre','YCentre','Area','OutArea','Perimeter','OutPerimeter','Length','LogLength','Width','Orientation','SAO','AxialRatio','LogAxialRatio','InvAxialRatio','EAD','OutEAD','EAR','OutEAR','EAP','OutEAP','LogEAD','Elongation','OutElongation','Roundness','OutRoundness','Circularity','OutCircularity','Compactness','OutCompactness','GSI','OutGSI','GSF','OutGSF','FractDim','OutFractDim','NHoles','UserData'};
    else
        disp('Available grain properties are:');
        disp('  ID');
        disp('  Phase');
        disp('  X (for single grain only)');
        disp('  Y (for single grain only)');
        disp('  XCentre/XC');
        disp('  YCentre/YC');
        disp('  [Out]Area');
        disp('  [Out]Perimeter');
        disp('  Length/LA/Feret');
        disp('  LogLength - log10 of length');
        disp('  Width/SA');
        disp('  Orientation/LAO');
        disp('  SAO');
        disp('  AxialRatio/AR');
        disp('  LogAxialRatio/LOGAR - log10 of axial ratio');
        disp('  InvAxialRatio/IAR - inverse of axial ratio');
        disp('  [Out]EAD - Equal area diameter');
        disp('  [Out]EAR - Equal area radius');
        disp('  [Out]EAP - Equal area perimeter');
        disp('  LogEAD - log10 of Equal area diameter');
        disp('  [Out]Elongation');
        disp('  [Out]Roundness');
        disp('  [Out]Circularity');
        disp('  [Out]Compactness');
        disp('  [Out]GSI - Grain shape index');
        disp('  [Out]GSF - Grain shape factor');
        disp('  [Out]F or [Out]FractDim - shape factor or fractal dimension');
        disp('  NHoles');
        disp('  Holes (for single grain only)');
        disp('  UserData');
        disp('  WKT - Well-known text representation (for single grain only)');
    end
end
