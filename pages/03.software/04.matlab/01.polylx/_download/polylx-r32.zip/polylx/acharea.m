function res=acharea(g,opt)
%ACHAREA Calculate area, perimeter, centroid of convex hull and bounding box of grains or boundaries.
% Syntax: res=acharea(g);
%         res=acharea(g,opt);
% res = [ area  perimeter  x_cen  y_cen x_min x_max y_min y_max]
% When opt is defined function returns only single property
% 1..area 2..perimeter 3.. x_cen 4..y_cen 5..x_min 6..x_max 7..y_min 8..y_max
% g is grain/boundary object(s)

% This file is part of polyLX.
% 
% polyLX is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% polyLX is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with polyLX.  If not, see <http://www.gnu.org/licenses/>.

% polyLX - MATLAB toolbox for microstructure analyses
% Copyright (C) 2010 Ondrej Lexa

if nargin<1
    help acharea
    return
end

x=[];
y=[];
for i=1:length(g);
    x=[x;get(g(i),'x')];
    y=[y;get(g(i),'y')];
end
k=convhull(x,y);
res=plgeo(x(k),y(k));
res(1)=abs(res(1));
res=[res min(x) max(x) min(y) max(y)];

if nargin>1
    res=res(opt);
end
