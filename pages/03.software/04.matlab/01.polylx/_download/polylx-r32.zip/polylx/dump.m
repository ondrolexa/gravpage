function dsc=dump(g,varargin)
%DUMP Dump grain/boundary properties to cell array.
% Syntax: dsc=dump(g);
%         dsc=dump(g,prop);  
%  g      - grain/boundary objects
%  prop   - properties of grain/boundary object to dump. See GET

% This file is part of polyLX.
% 
% polyLX is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% polyLX is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with polyLX.  If not, see <http://www.gnu.org/licenses/>.

% polyLX - MATLAB toolbox for microstructure analyses
% Copyright (C) 2010 Ondrej Lexa

if nargin<1
    help dump
    dsc=[];
    return
end
if ~isa(g,'polylxgrain') && ~isa(g,'polylxboundary')
    help dump
    dsc=[];
    return
end

if isempty(varargin)
    if isa(g,'polylxgrain')
        tlist=get(g);
        [typa,valid]=listdlg('PromptString','Select measurements:','ListString',tlist,'InitialValue',[2,5,7,9,11,12,14,18]);
    else
        tlist=get(g);
        [typa,valid]=listdlg('PromptString','Select measurements:','ListString',tlist,'InitialValue',[6,9,10,12,14]);
    end
    if valid~=1
        disp ('Aborted.')
        dsc=[];
        return
    end
else
    tlist=varargin;
    typa=1:length(tlist);
end

dsc={class(g) tlist{typa}};
dt=num2cell(get(g,'id'));

for i=1:length(typa)
   f=get(g,tlist{typa(i)});
   if isa(f,'cell')
       dt=[dt f];
   else
       dt=[dt num2cell(f)];
   end
end

dsc=[dsc;dt];
