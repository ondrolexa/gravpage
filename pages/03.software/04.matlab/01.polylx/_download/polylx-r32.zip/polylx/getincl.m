function ix=getincl(g,b)
%GETINCL Get index to grains inclusions.
%Syntax: ix=getincl(g,b);
%        ix=getincl(g);

% This file is part of polyLX.
% 
% polyLX is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% polyLX is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with polyLX.  If not, see <http://www.gnu.org/licenses/>.

% polyLX - MATLAB toolbox for microstructure analyses
% Copyright (C) 2010 Ondrej Lexa

ix=[];
if nargin<1
    help getincl
    return
end
if ~isa(g,'polylxgrain')
    help getincl
    return
end

if nargin<2
    b=bmake(g);
end

nh=find(get(g,'nholes')>0);
ixa=get(b,'ixa');
ixb=get(b,'ixb');

for i=1:length(nh)
    idd=union(ixb(ixa==nh(i)),ixa(ixb==nh(i)));
    for j=1:length(idd)
        if all(union(ixb(ixa==idd(j)),ixa(ixb==idd(j)))==nh(i))
            % check if real inclusion
            if get(b(ixa==idd(j)),'cumlength')==get(g(idd(j)),'outperimeter')
                ix=[ix idd(j)];
            end
        end
    end
end

