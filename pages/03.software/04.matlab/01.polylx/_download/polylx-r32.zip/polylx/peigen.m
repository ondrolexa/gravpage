function pe=peigen(g,varargin)
%PEIGEN Plot bulk eigenvalues ratio vs. choosen property of grains/boundaries.
% of grain/boundaries
% Syntax: pe=peigen(g,options);
% g    - grain/boundary objects
% options are passed as pairs of option name and option value:
% 'spo'     ... method see opt in aortentot. Default 0
% 'prop'    ... x axis property. Default orientation from AORTENTOT
% 'xlim'    ... x axis limits [xmin xmax]. Default automatic.

% This file is part of polyLX.
% 
% polyLX is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% polyLX is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with polyLX.  If not, see <http://www.gnu.org/licenses/>.

% polyLX - MATLAB toolbox for microstructure analyses
% Copyright (C) 2010 Ondrej Lexa

if nargin<1
   help peigen
   return
end

% Process input arguments
opts.spo=0;
opts.prop='Orientation';
opts.xlim=[];
opts=parseargs(varargin,opts);

if isa(g,'polylxgrain')
   ph=gplist(g);
   pe={'SPO',opts.prop,'Ratio'};
elseif isa(g,'polylxboundary')
   ph=btlist(g);
   pe={'BPO',opts.prop,'Ratio'};
else
   error('First argument must be grain/boundary object.');
end

% go
ppoc=length(ph);
r=[]; xval=[]; cnt=[];

for i=1:ppoc
   cnt=[cnt;length(g(ph{i}))];
   [ra,rb,oa]=aortentot(g(ph{i}),opts.spo);
   r=[r;ra/rb];
   if strcmpi(opts.prop,'orientation')
       xx=oa;
   else
       xx=mean(get(g(ph{i}),opts.prop));
   end
   xval=[xval;xx];
end

%ommit single lines
xval=xval(r<1000);
cnt=cnt(r<1000);
ph=ph(r<1000);
r=r(r<1000);

cla; hold on;
for i=1:length(xval);
    act=ph{i};
    ix=findstr(act,'-');
    if isa(g,'polylxboundary')&&~isempty(ix)
      if strcmp(act(1:ix(1)-1),act(ix(1)+1:end))
         plot(xval(i),r(i),'k.');
         text(xval(i),r(i),[ph{i} ' - ' int2str(cnt(i))],'HorizontalAlignment','center','VerticalAlignment','top');
      else
         plot(xval(i),r(i),'k*');
         text(xval(i),r(i),[ph{i} ' - ' int2str(cnt(i))],'HorizontalAlignment','center','VerticalAlignment','top');
      end
    else
      plot(xval(i),r(i),'k.');
      text(xval(i),r(i),[ph{i} ' - ' int2str(cnt(i))],'HorizontalAlignment','center','VerticalAlignment','top');
    end
end
xlabel(opts.prop);
ylabel('Bulk orientation tensor eigenvalue ratio')
%set(gca,'XTick',0:20:180);
%set(gca,'XGrid','on');
if ~isempty(opts.xlim)
    set(gca,'XLim',opts.xlim);
end
set(gca,'YScale','log');
set(gca,'YTick',1:(ceil(1.2*max(r)-1)/10):(1.2*max(r)));
%set(gca,'YGrid','on');
hold off

pe=[pe;[ph num2cell(xval) num2cell(r)]];
