function [g,pth,fnm]=jmlread(varargin)
%JMLREAD Read grain geometry from JUMP GML file.
% Syntax:  [g,path,filename]=jmlread;
%          [g,path,filename]=jmlread(filename);

% This file is part of polyLX.
% 
% polyLX is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% polyLX is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with polyLX.  If not, see <http://www.gnu.org/licenses/>.

% polyLX - MATLAB toolbox for microstructure analyses
% Copyright (C) 2010 Ondrej Lexa

% GUI open file
if isempty(varargin)
    [fnm, pth]=uigetfile({'*.jml','JUMP GML (*.jml)'},'Open JUMP GML file');
    if fnm==0
        g=[]; pth=[]; fnm=[];
        return
    end
    filename=[pth fnm];
else
    filename=varargin{1};
    if isempty(strfind(filename,'.jml'))||~exist(filename,'file')
        error('First argument must be valid filename of JUMP GML with extension. Aborted');
    end
    ix=find(filename=='\');
    if isempty(ix);
        ix=0;
    end
    fnm=filename(ix(end)+1:end);
    pth=filename(1:ix(end));
end
% Read the entire JML file
fid = fopen(filename,'rt');
if (fid==-1) 
	error(sprintf('Cannot open %s for reading.',filename))
end
jmlstring = fscanf(fid,'%c');
fclose(fid);
% Parse column names
coldef=gettag(jmlstring,'<ColumnDefinitions>');
tag='<name>';
[namedef,n]=gettag(coldef{1},'<name>');
fd={};
for i=1:n
    fd{i}=namedef{i};
end
if ~isempty(fd)
    % Select id field
    idfield=find(strcmpi('id',fd));
    if isempty(idfield)
       idfield=find(strcmpi('gid',fd));
       if isempty(idfield)
          disp('There is no ID or GID attribute in your shape file. Values will be generated.');
          idfield=0;
       end
    end
    % Select phase field
    phfield=find(strcmpi('phase',fd));
    if isempty(phfield)
      [phfield,valid]=listdlg('PromptString','Select Phase field:','SelectionMode','Single','ListString',fd);
      if valid~=1
         fd={};
      end
    end
end
% Parse feature collection
[feature,poc]=gettag(jmlstring,'<feature>');
% Parse features
idx=1;
h=waitbar(0,'Please wait...','Name','Reading geometry...');
for i=1:poc
    geodef=gettag(feature{i},'<geometry>');
    if ~isempty(geodef)
        poldef=gettag(geodef{1},'<gml:Polygon>');
        outdef=gettag(poldef{1},'<gml:outerBoundaryIs>');
        linring=gettag(outdef{1},'<gml:LinearRing>');
        coords=gettag(linring{1},'<gml:coordinates>');
        if ~isempty(coords)
            co=str2num(coords{1});
            x=co(:,1);
            y=co(:,2);
            [indef,n]=gettag(poldef{1},'<gml:innerBoundaryIs>');
            for j=1:n
                linring=gettag(indef{j},'<gml:LinearRing>');
                coords=gettag(linring{1},'<gml:coordinates>');            
                co=str2num(coords{1});
                x=[x;NaN;co(:,1)];
                y=[y;NaN;co(:,2)];
            end
            
            if ~isempty(fd)
                props=gettag(feature{i},'<property name="','</property>');
                phase=props{phfield};
                phase=phase(length(fd{phfield})+3:end);
                if isempty(phase)
                    phase='NotDefined';
                end
                if idfield~=0
                    id=props{idfield};
                    id=id(length(fd{idfield})+3:end);
                    g(idx)=polylxgrain(str2num(id),deblank(phase),x,y);
                else
                    g(idx)=polylxgrain(idx,deblank(phase),x,y);
                end
            else
                g(idx)=polylxgrain(idx,'A',x,y);
            end
            idx=idx+1;
        end        
    end
    waitbar(i/poc,h);
end
close(h)
function [t,n]=gettag(s,tag1,tag2)
% helper function to parse jml
if nargin<3
    tag2=[tag1(1) '/' tag1(2:end)];
end
za=strfind(s,tag1)+length(tag1);
ko=strfind(s,tag2)-1;
if length(za)~=length(ko)
    error('Wrong file format.');
end
n=length(za);
t={};
for i=1:n
    t{i}=s(za(i):ko(i));
end
