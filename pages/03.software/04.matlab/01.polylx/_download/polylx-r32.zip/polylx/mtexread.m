function g=mtexread(grains,varargin)
%MTEXREAD Read grains from M-TEX grains object.
% Syntax:  g=mtexread(grains);
%          g=mtexread(grains, options);
% options are passed as pairs of option name and option value:
% 'ver'     ... mtex version as decimal number. Default 3.4
% 'bunge'   ... add euler angles (bunge notation) to udata. Default 1
% 'caxisdc' ... add c-axis directional cosines to udata. Default 0

% This file is part of polyLX.
% 
% polyLX is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% polyLX is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with polyLX.  If not, see <http://www.gnu.org/licenses/>.

% polyLX - MATLAB toolbox for microstructure analyses
% Copyright (C) 2010 Ondrej Lexa
% Thanks to Filippe Ferreira <filippeof@gmail.com> for bugfix

% GUI open file

if nargin<1
    help mtexread;
    g=[];
    return;
end

% initialize defaults and parse arguments
if exist('startup_mtex')==2
    v=getMTEXpref('version');
    nb=strfind(getMTEXpref('version'), 'MTEX ') + 5;
    opts.ver=str2num(v(nb:nb+2));
else
    opts.ver=3.4;
end
opts.bunge=1;
opts.caxisdc=0;
opts=parseargs(varargin,opts);

% read grains
h=waitbar(0,'Please wait...', 'Name','Reading geometry...');

if opts.ver<3.3
    poc=length(grains);
    for i=1:poc
        pp=polytope(grains(i));
        xy=get(pp,'xy');
        if hashole(pp)
            holes=get(pp,'holes');
            for j=1:length(holes)
                xy=[xy;NaN NaN;get(holes(j),'xy')];
            end
        end
        g(i)=polylxgrain(get(grains(i),'id'),num2str(get(grains(i),'phase')),xy(:,1),xy(:,2));
        waitbar(i/poc,h);
    end
elseif opts.ver<4
    ph=get(grains,'phase');
    ix=ph>0;
    ph=ph(ix);
    V=get(grains,'V');
    F=get(grains,'boundaryEdgeOrder');
    F=F(ix);
    pm=get(grains,'phaseMap');
    pn=get(grains,'minerals');
    mr=get(grains,'meanRotation');
    mr=mr(ix);
    CS=get(grains,'CSCell');
    SS=get(grains,'SS');
    poc=length(F);
    for i=1:poc
        if ~iscell(F{i})
            xy=V(F{i},:);
            geom=plgeo(xy(:,1),xy(:,2));
            if sign(geom(1))~=1
                xy=flipud(xy);
            end
        else
            xy=V(F{i}{1},:);
            geom=plgeo(xy(:,1),xy(:,2));
            if sign(geom(1))~=1
                xy=flipud(xy);
            end
            for j=2:length(F{i})
                xyh=V(F{i}{j},:);
                geom=plgeo(xyh(:,1),xyh(:,2));
                if sign(geom(1))~=-1
                    xyh=flipud(xyh);
                end
                xy=[xy;NaN NaN;xyh];
            end
        end
        ix=find(ph(i)==pm);
        udata=struct;
        or=orientation(mr(i),CS{ix},SS);
        vc=or*Miller(0,0,1);
        if opts.bunge
            udata.bunge=Euler(or)/degree;
        end
        if opts.caxisdc
            udata.caxisdc=[gety(vc) getx(vc) -getz(vc)];
        end
        g(i)=polylxgrain(i,pn{ix},xy(:,1),xy(:,2),udata);
        waitbar(i/poc,h);
    end
elseif opts.ver<4.5
    ph=grains.phase;
    ix=ph>0;
    ph=ph(ix);
    V=grains.V;
    F=grains.poly;
    F=F(ix);
    pm=grains.phaseMap;
    pn=grains.mineralList;
    mr=grains.meanRotation;
    mr=mr(ix);
    CS=grains.CSList;
    SS=specimenSymmetry('triclinic');
    poc=length(F);
    for i=1:poc
        if ~iscell(F{i})
            xy=V(F{i},:);
            geom=plgeo(xy(:,1),xy(:,2));
            if sign(geom(1))~=1
                xy=flipud(xy);
            end
        else
            xy=V(F{i}{1},:);
            geom=plgeo(xy(:,1),xy(:,2));
            if sign(geom(1))~=1
                xy=flipud(xy);
            end
            for j=2:length(F{i})
                xyh=V(F{i}{j},:);
                geom=plgeo(xyh(:,1),xyh(:,2));
                if sign(geom(1))~=-1
                    xyh=flipud(xyh);
                end
                xy=[xy;NaN NaN;xyh];
            end
        end
        ix=find(ph(i)==pm);
        udata=struct;
        or=orientation(mr(i),CS{ix},SS);
        vc=or*Miller(0,0,1,CS{ix});
        if opts.bunge
           udata.bunge=Euler(or)/degree;
        end
        if opts.caxisdc
           udata.caxisdc=[gety(vc) getx(vc) -getz(vc)];
        end
        g(i)=polylxgrain(i,pn{ix},xy(:,1),xy(:,2),udata);
        waitbar(i/poc,h);
    end
else
    ph=grains.phase;
    ix=ph>0;
    ph=ph(ix);
    V=grains.V;
    F=grains.poly;
    F=F(ix);
    pm=grains.phaseMap;
    pn=grains.mineralList;
    mr=grains.meanRotation;
    mr=mr(ix);
    CS=grains.CSList;
    SS=specimenSymmetry('triclinic');
    poc=length(F);
    for i=1:poc
        Faces = F(i);
        s     = cellfun('prodofsize',Faces).';
        cs    = [0 cumsum(s)];
        % reduce face-vertex indices to required
        Faces = [Faces{:}];
        vert  = sparse(Faces,1,1,size(V,1),1);
        Vertices = V(vert>0,:);
        vert  = cumsum(full(vert)>0);
        Faces = nonzeros(vert(Faces));
        % fill the faces-edge list for patch
        Face = NaN(numel(s),max(s));
        for k=1:numel(s)
        Face(k,1:s(k)) = Faces( cs(k)+1:cs(k+1) );
        end
        ix = find(Face==1);
        if length(ix)>2
            oFace = Faces(ix(1):ix(2));
            xy=Vertices(oFace,:);
            geom=plgeo(xy(:,1),xy(:,2));
            if sign(geom(1))~=1
                xy=flipud(xy);
            end
            for j = 2:length(ix)-1
                iFace = Faces(ix(j)+1:ix(j+1)-1);
                xyh=Vertices(iFace,:);
                geom=plgeo(xyh(:,1),xyh(:,2));
                if sign(geom(1))~=-1
                    xyh=flipud(xyh);
                end
                xy=[xy;NaN NaN;xyh];
            end
        else
            xy=Vertices(Face,:);
            geom=plgeo(xy(:,1),xy(:,2));
            if sign(geom(1))~=1
                xy=flipud(xy);
            end
        end
        ix=find(ph(i)==pm);
        udata=struct;
        or=orientation(mr(i),CS{ix},SS);
         vc=or*Miller(0,0,1,CS{ix});
         if opts.bunge
            udata.bunge=Euler(or)/degree;
         end
        if opts.caxisdc
            udata.caxisdc=[gety(vc) getx(vc) -getz(vc)];
        end
        g(i)=polylxgrain(i,pn{ix},xy(:,1),xy(:,2),udata);
        waitbar(i/poc,h);
    end
end
close(h)
