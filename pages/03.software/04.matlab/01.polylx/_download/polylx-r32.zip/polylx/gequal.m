function gn=gequal(g,varargin)
%GEQUAL Transform grain objects to equivalent shapes.
% Syntax: gn=gequal(g,options);
% g is grain object
% options are passed as pairs of option name and option value:
% 'shape'  ... could be 'rectangle','circle'
% 'scale'  ... 0.. bounding rectangle 1.. equal area rectangle. Default 1.

% This file is part of polyLX.
% 
% polyLX is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% polyLX is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with polyLX.  If not, see <http://www.gnu.org/licenses/>.

% polyLX - MATLAB toolbox for microstructure analyses
% Copyright (C) 2010 Ondrej Lexa

if ~isa(g,'polylxgrain')
    error('First argument must be grain objects');
end

% Process input arguments
opts.shape='circle';
opts.scale=1;
opts=parseargs(varargin,opts);

% main
n=length(g);
gn(1,n)=polylxgrain;

h=waitbar(0,'Please wait...','Name','Transforming...');

for ii=1:n
    switch lower(opts.shape)
        case {'circle','circ','c'}
            ang=[0:5:360]';
            gn(ii)=polylxgrain(get(g(ii),'id'),...
                              get(g(ii),'phase'),...
                              get(g(ii),'xcentre')+get(g(ii),'ead')*sind(ang),...
                              get(g(ii),'ycentre')+get(g(ii),'ead')*cosd(ang),...
                              get(g(ii),'userdata'));
        case{'rectangle','rect','r'}
            xy=get(g(ii),'xcentre','ycentre');
            [l,w,o]=get(g(ii),'length','width','orientation');
            if opts.scale
                sc=sqrt(get(g(ii),'area')/(l*w));
            else
                sc=1;
            end
            a=sc*[sind(o)*l/2 cosd(o)*l/2];
            b=sc*[sind(o+90)*w/2 cosd(o+90)*w/2];
            r=[xy+a+b;xy-a+b;xy-a-b;xy+a-b;xy+a+b];
            gn(ii)=polylxgrain(get(g(ii),'id'),...
                              get(g(ii),'phase'),...
                              r(:,1),...
                              r(:,2),...
                              get(g(ii),'userdata'));
        otherwise
            fprintf('Shape %s is not supported.\n',opts.shape)
            help gequal
    end
    waitbar(ii/n,h);
end
close(h)
