function b=bsmake(g)
%BSMAKE Routine to construct boundaries segments objects from grain or boundary objects.
% Syntax:  b=bsmake(g);
%    g   - grain/boundary objects

% This file is part of polyLX.
% 
% polyLX is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% polyLX is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with polyLX.  If not, see <http://www.gnu.org/licenses/>.

% polyLX - MATLAB toolbox for microstructure analyses
% Copyright (C) 2010 Ondrej Lexa

if isa(g,'polylxgrain')
    %Decompose grains
    h=waitbar(0,'Please wait...','Name','Decomposing grain objects...');
    idx=0;
    poc=length(g);
    for i=1:poc
        waitbar(i/poc,h);
        [x,y]=get(g(i),'x','y');
        for j=1:length(x)-1
            idx=idx+1;
            b(idx)=polylxboundary(idx,i,0,char(get(g(i),'phase')),'ZZ',x(j:j+1),y(j:j+1));
        end
        waitbar(i/poc,h);
    end
elseif isa(g,'polylxboundary')
    %Decompose boundaries
    h=waitbar(0,'Please wait...','Name','Decomposing boundary objects...');
    idx=0;
    poc=length(g);
    for i=1:poc
        waitbar(i/poc,h);
        [x,y]=get(g(i),'x','y');
        for j=1:length(x)-1
            idx=idx+1;
            b(idx)=polylxboundary(idx,get(g(i),'ixa'),get(g(i),'ixb'),char(get(g(i),'phasea')),char(get(g(i),'phaseb')),x(j:j+1),y(j:j+1));
        end
        waitbar(i/poc,h);
    end   
else
    help bsmake
    b=[];
end

close(h);
