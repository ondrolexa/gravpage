function [gn,sd]=gsurfor(g,varargin)
%GSURFOR Return results of SURFOR analysis after R.Panozzo.
% Surface projection function. Note that for grains values of projection are divided by 2
% to be comparable with PAROR and with geometry of grains.
% Syntax: gn=gsurfor(g,options);
%    [gn,sd]=gsurfor(g,options);
% g can be grain or boundary object(s)
% When grain objects are passed gn are grains objects with calculated
% properties centre, la,sa,lao,sao. When boundary objects are passed gn is
% structure with fields x[y]centre, lao, sao, la, sa. To plot data from
% structure use PELLIPSE or PCROSS
% sd is Nx180 matrix with individual projection values
% options are passed as pairs of option name and option value:
% 'fit'      ... 0.. nofit 1.. fit best ellipse projection. Default 0.
% 'holes'    ... 0.. no holes 1.. include holes. Default 0.
% 'res'      ... resolution i.e. number of vertexes Default 91.
%                res 5 is enough to get la,sa,lao,sao

% This file is part of polyLX.
% 
% polyLX is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% polyLX is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with polyLX.  If not, see <http://www.gnu.org/licenses/>.

% polyLX - MATLAB toolbox for microstructure analyses
% Copyright (C) 2010 Ondrej Lexa

if nargin<1
    help gsurfor;
    return;
end

% Process input arguments
opts.fit=0;
opts.holes=0;
opts.res=91;
opts=parseargs(varargin,opts);
if opts.res<5
    opts.res=5;
end

%Initialize
n=length(g);
sd=zeros(n,180);
switch class(g)
    case 'polylxgrain'
        gn(1,n)=polylxgrain;
    case 'polylxboundary'
        gn(1,n)=struct('xcentre',[],'ycentre',[],'lao',[],'sao',[],'la',[],'sa',[]);
    otherwise
        disp('First argument must be grain or boundary object.')
        gn=[];
        return
end
the=linspace(0,360,opts.res)';

%half of rotation matrix
nn=[sind(1:180);cosd(1:180)];
nn2=[cosd(1:180);-sind(1:180)];

h=waitbar(0,'Please wait...','Name','Calculating...');
for ii=1:n
    x=diff(get(g(ii),'x'));
    y=diff(get(g(ii),'y'));

    if opts.holes && isa(g,'polylxgrain')
        q=get(g(ii),'holes');
        for jj=1:get(g(ii),'nholes');
            x=[x;diff(q(jj).x)];
            y=[y;diff(q(jj).y)];
        end
    end

    ff=[x y]*nn;
    if size(ff,1)>1
        f=(sum(abs(ff)))';
    else
        f=abs(ff)';
    end

    if isa(g,'polylxgrain')
        f=f/2;
    end

    if opts.fit
        [la,sa,lao]=fitpd(f); % fit ellipse
        la=2*la;
        sa=2*sa;
    else
        [la,lao]=max(f);
        sao=mod(lao+90,180);
        sa=f(sao+180*(1-sign(sao)));
    end

    sd(ii,:)=f;
    %midpoint of grain in orthogonal position
    ff=[x y]*[sind(lao);cosd(lao)];
    ff2=[x y]*[cosd(lao);-sind(lao)];
    cc=[(max(ff2)+min(ff2))/2;(max(ff)+min(ff))/2];
    %midpoint in original coordinates
    xc=[cosd(lao) sind(lao)]*cc;
    yc=[-sind(lao) cosd(lao)]*cc;
    co=cosd(lao);
    si=sind(lao);
    x=si*cosd(the)*la/2+co*sind(the)*sa/2+xc+get(g(ii),'xcentre');
    y=co*cosd(the)*la/2-si*sind(the)*sa/2+yc+get(g(ii),'ycentre');
    if isa(g,'polylxgrain')
        gn(ii)=polylxgrain(get(g(ii),'id'),...
                           get(g(ii),'phase'),...
                           x,...
                           y,...
                           get(g(ii),'userdata'));
    else
        gn(ii).xcentre=xc;
        gn(ii).ycentre=yc;
        gn(ii).lao=lao;
        gn(ii).sao=mod(lao+90,180);
        gn(ii).la=la;
        gn(ii).sa=sa;
    end
    waitbar(ii/n,h);
end
close(h)
