function dbdelete(sample)
%DBDELETE Delete sample(s) in database.
% Syntax:  g=dbdelete;
%          g=dbdelete(samples);
% samples should be cell array

% This file is part of polyLX.
% 
% polyLX is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% polyLX is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with polyLX.  If not, see <http://www.gnu.org/licenses/>.

% polyLX - MATLAB toolbox for microstructure analyses
% Copyright (C) 2010 Ondrej Lexa

global polylx_prefs
%Check connection
if dbconnect

    if nargin<1
        res=dbcommand(['SELECT name FROM samples ORDER BY name']);
        if isempty(res)
            disp('No samples in open database. Aborting.');
            dbclose;
            return
        else
            [sel,ok] = listdlg('ListString',{res.name},'Name','Select sample(s)');
            if ok==0
                dbclose;
                return
            else
                sample={res(sel).name};
            end
        end
    end
    if ischar(sample)
        sample={sample};
    end
    
    % delete samples
    bt=questdlg(['Are you sure that you want to permanently delete selected samples from database ?'],'Delete sample from database','Yes','No','No');
    if ~strcmp(bt,'Yes')
        return
    end
    for i=1:length(sample)
        res=dbcommand(['SELECT id FROM samples WHERE name=''' sample{i} '''']);
        if isempty(res)
            disp(['No sample ' sample{i} ' in database. Skipped.']);
        else
            id_sample=res.id;
            dbcommand(['DELETE FROM grains WHERE id_sample=' num2str(id_sample)]);
            dbcommand(['DELETE FROM boundaries WHERE id_sample=' num2str(id_sample)]);
            dbcommand(['DELETE FROM samples WHERE id=' num2str(id_sample)]);
        end
    end
    if strcmpi(polylx_prefs.driver,'SQlite3')
        disp('Rebuilding database. Please wait...');
        dbcommand('VACUUM');
    end
end
