function [gok,gbad,w]=grainfilter(c,g)
%GRAINFILTER Return grains with well developed CIP maxima.
% Syntax:
%      [gok,gbad,w]=grainfilter(c,g);
%
% Require stereoLX toolbox

% This file is part of polyLX.
% 
% polyLX is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% polyLX is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with polyLX.  If not, see <http://www.gnu.org/licenses/>.

% polyLX - MATLAB toolbox for microstructure analyses
% Copyright (C) 2010 Ondrej Lexa

[dt,gc]=graindata(c,g);
ixok=[];
ixbad=[];
w=[];
for i=1:length(gc);
    cg=grainmask(c,gc(i));
    dtc=get(cg,'data');
    cc=geodata(dtc,'linear','CIP');
    [res,ev]=ortensor(cc);
    if log(ev(3)/ev(2))>log(ev(2)/ev(1))
        ixok=[ixok i];
        w=[w log(ev(3)/ev(1))];
    else
        fprintf('Skipped: %d\n',i);
        ixbad=[ixbad i];
    end
end
gok=gc(ixok);
gbad=gc(ixbad);
