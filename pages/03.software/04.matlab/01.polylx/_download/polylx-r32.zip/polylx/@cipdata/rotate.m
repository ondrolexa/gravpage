function cr = rotate(c,rotax,rotang)
%ROTATE Rotate cipdata.

% This file is part of polyLX.
% 
% polyLX is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% polyLX is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with polyLX.  If not, see <http://www.gnu.org/licenses/>.

% polyLX - MATLAB toolbox for microstructure analyses
% Copyright (C) 2010 Ondrej Lexa

% input rotation params
if nargin<2
    rr = inputdlg({'Axis dir:','Axis dip:','Rotation angle:'},'Rotatate data:',1,{'90','0','0'});
    if isempty(rr)
        cr=[];
        return
    end
    rotax = [str2double(rr{1}) str2double(rr{2})];
    rotang = str2double(rr{3});
end

%get dip and dir data without mask
dd=[c.azi(:) c.incp(:)];

% to direction cosines
dc = [cos(dd(:,2)*pi/180).*cos(dd(:,1)*pi/180) cos(dd(:,2)*pi/180).*sin(dd(:,1)*pi/180) sin(dd(:,2)*pi/180)];
dcr = [cos(rotax(2)*pi/180).*cos(rotax(1)*pi/180) cos(rotax(2)*pi/180).*sin(rotax(1)*pi/180) sin(rotax(2)*pi/180)];
% Uses Rodrigues's formula to create a 3x3 rotation matrix R.
U=[0 -dcr(3) dcr(2);dcr(3) 0 -dcr(1);-dcr(2) dcr(1) 0];
R=eye(3)+U*sin(rotang*pi/180)+U^2*(1-cos(rotang*pi/180));
% rotate data
dc2 = (R*dc')';
% to azimuth dip
ix = find(dc2(:,3)<0);
dc2(ix,:) = -dc2(ix,:);
incpr = reshape(asin(dc2(:,3))*180/pi,size(c.incp));
dipdir = real(acos(dc2(:,1)./cos(asin(dc2(:,3)))))*180/pi;
dipdir(dc2(:,2)<0) = 360-dipdir(dc2(:,2)<0);
azir = reshape(dipdir,size(c.azi));
cr = cipdata(azir,incpr,c.mask,sprintf('%s - Rotated %d° around %d/%d',c.name,rotang,rotax(1),rotax(2)));