function display(c)
%DISPLAY Command window display of cipdata

% This file is part of polyLX.
% 
% polyLX is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% polyLX is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with polyLX.  If not, see <http://www.gnu.org/licenses/>.

% polyLX - MATLAB toolbox for microstructure analyses
% Copyright (C) 2010 Ondrej Lexa

if isempty(get(c,'azi'))
    disp(' ');
    disp([inputname(1),' = ']);
    disp(' ');
    disp('Empty CIPDATA');
else
    disp(' ');
    disp([inputname(1),' = ']);
    disp(' ');
    disp(sprintf('CIPDATA: %s',c.name));
    disp(sprintf('Width: %d  Height: %d',c.width,c.height));
    disp(sprintf('Number of datapixels: %d',length(c)));
    disp(' ');
end
