function [sample,att]=dbselect
%DBSELECT Select samples and their attributes from database.
% Syntax: sample=dbselect
%         [sample,att]=dbselect
% sample is cell array of sample names
% att is structure with sample attributes

% This file is part of polyLX.
% 
% polyLX is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% polyLX is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with polyLX.  If not, see <http://www.gnu.org/licenses/>.

% polyLX - MATLAB toolbox for microstructure analyses
% Copyright (C) 2010 Ondrej Lexa

%Check connection
if dbconnect
    sample={};
    res=dbcommand(['SELECT name, label, X, Y FROM samples ORDER BY name']);
    if isempty(res)
        disp('No samples in open database. Aborting.');
    else
        [sel,ok] = listdlg('ListString',{res.name},'Name','Select samples');
        if ok~=0
            sample={res(sel).name};
            att=res(sel);
        end
    end
    dbclose;
end
