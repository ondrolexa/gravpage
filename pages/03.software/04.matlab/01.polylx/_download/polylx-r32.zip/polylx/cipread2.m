function c = cipread2(dirname)
%CIPREAD2 Read cipdata in TIFF format.
% Syntax:
%      c = cipread2;
%      c = cipread2('workdirname');

% This file is part of polyLX.
% 
% polyLX is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% polyLX is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with polyLX.  If not, see <http://www.gnu.org/licenses/>.

% polyLX - MATLAB toolbox for microstructure analyses
% Copyright (C) 2013 Ondrej Lexa

%remember actual directory
adir = pwd;

if nargin<1
    dirname = pwd;
end

%ask for datafiles
cd(dirname)
[fazi, pazi]=uigetfile({'*.azi','AZI file (*.AZI)'},'Open AZI file from CIP1A');
if fazi == 0
    c=[];
    return
end
[fincp, pincp]=uigetfile({'*.inc*','INC file (*.INC)'},'Open INC file from CIP1B');
if fincp == 0
    c=[];
    return
end
[fmask, pmask]=uigetfile({'*.*','Mask file (*.*)'},'Open mask file from input');
if fmask == 0
    c=[];
    return
end

cd(adir);
% read images
azi = double(imread(fullfile(pazi,fazi)));
incp = double(imread(fullfile(pincp,fincp)));
mask =~logical(imread(fullfile(pmask,fmask)));
%Apply and extend mask, recalculate azimuths, dips
mask = mask & incp<=180;
%incp(~mask) = nan;
incp = incp-90;
%extend mask to invalid data
mask = mask & azi<=180;
%azi(~mask) = nan;
azi(incp<0) = azi(incp<0)+180;
incp = abs(incp);
%get name
[dummy,name] = fileparts(fullfile(pazi,fazi));
%creatre object
c = cipdata(azi,incp,mask,name);
