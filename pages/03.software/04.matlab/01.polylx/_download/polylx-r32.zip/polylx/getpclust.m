function r=getpclust(g,b,ix,cm)
%GETPCLUST Return index vector/cell array to interconnected phase cluster.
% Syntax:  ix=getpclust(g,b,ix);
%   ix - index of seed(s) for interconnected cluster
%   cm - connection matrix from getcm(g,b)

% This file is part of polyLX.
% 
% polyLX is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% polyLX is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with polyLX.  If not, see <http://www.gnu.org/licenses/>.

% polyLX - MATLAB toolbox for microstructure analyses
% Copyright (C) 2010 Ondrej Lexa
if nargin<4
    cm=getcm(g,b);
end

if nargin<3
    help getpclust
    return
end

if ~isempty(b)
    r={};
    for i=1:length(ix)
        iix=ix(i);
        go=1;
        ph=get(g(iix),'phase');
        while go==1
            nnb=getneigh(cm,iix);
            if ~isempty(nnb)
                nnb=nnb(gpsel(g(nnb),ph));
                nix=union(iix,nnb);
                if isempty(setdiff(nix,iix))
                    go=0;
                end
                iix=nix;
            else
                go=0;
            end
        end
        r{i}=iix;
    end

    if length(ix)==1
        r=r{i};
    end
else
    if length(ix)==1
        r=ix;
    else
        r=num2cell(ix);
    end
end