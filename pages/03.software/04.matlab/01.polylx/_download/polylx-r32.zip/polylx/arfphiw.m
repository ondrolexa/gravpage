function [rs,wrs,Isym]=arfphiw(rf,lao,wgt,nsteps)
%ARFPHIW Estimation of weighted strain ratio from rf/phi modelling.
% Syntax: [rs,wrs,Isym]=arfphiw(ar,ang,w,[nsteps]);
%  ar    - axial ratios Rf
%  ang   - axes orientations phi
%   w    - weight e.g. size or areas of grains
% nsteps - number of iterations. Default 50
% Output:
%  rs     - estimated strain ratio
%  wrs    - value of weighted test
%  Isym   - Index of symmetry

% This file is part of polyLX.
% 
% polyLX is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% polyLX is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with polyLX.  If not, see <http://www.gnu.org/licenses/>.

% polyLX - MATLAB toolbox for microstructure analyses
% Copyright (C) 2010 Ondrej Lexa

if nargin<4
    nsteps=[];
end

if nargin<3
    wgt=[];
end

% when grain object is passed
if isa(rf,'polylxgrain')
    g=rf;
    if exist('lao','var')
        nsteps=lao;
    else
        nsteps=[];
    end
    rf=get(g,'AxialRatio');
    lao=get(g,'Orientation');
    wgt=get(g,'EAD');
end

if ~isa(rf,'double') || ~exist('lao','var')
    help arfphiw
    return
end

if isempty(nsteps)
    nsteps=50;
end

if isempty(wgt)
    wgt=ones(size(rf));
else
    wgt=wgt/sum(wgt);
end

%Calculate vector mean
xr=sum(sin(rad(2*lao)));
yr=sum(cos(rad(2*lao)));
mdang=deg(atan2(xr,yr))/2;    % mean direction
phi=lao-mdang;
ixxx=find(phi>90);
phi(ixxx)=phi(ixxx)-180;
ixxx=find(phi<-90);
phi(ixxx)=phi(ixxx)+180;
clf;
ppp=get(gcf,'Position');
ppp(3)=1100; ppp(1)=10;
set(gcf,'Position',ppp);
subplot(1,3,1)
plot(phi,rf,'k.')
xlabel('Phi');
ylabel('Rf');
title('Strained');
a=axis;
a(1:3)=[-90 90 1];
axis(a);
set(gca,'XTick',-90:30:90);
tt=get(gca,'YTick');
set(gca,'YScale','log');
set(gca,'YTick',tt);
set(gca,'YGrid','on');
set(gca,'XGrid','on');

% settings
poc=length(rf);
e={}; en={}; wrs=[]; 
kk=rf((phi>-10)&(phi<10));
stp=(sqrt(mean(kk)+std(kk))-1)/200;
rs=(1+(0:nsteps)*stp).^2;
subplot(1,3,3)
%set(gca,'YScale','log');
xlabel('Rs');
ylabel('Weighted axial ratio');
title('Weight plot');
hold on


% nacte elipsy
for i=1:poc
    anr=phi(i)*pi/180;
    r=[cos(anr) -sin(anr);...
       sin(anr)  cos(anr)];
    p=[sqrt(rf(i)) 0;0 1/sqrt(rf(i))];
    e{i}=(r*p)*(r*p)';
end
for i=0:nsteps-1
    tm=[1/(1+i*stp) 0;0 (1+i*stp)];
    for j=1:poc
        en{j}=tm*e{j}*tm';
    end
    r=eanal(en);
    wrs=[wrs; sum(r.*wgt)];
    plot((1+i*stp)^2,wrs(end),'k.');
    drawnow
end
a=axis;
a(1:2)=[1 (1+nsteps*stp)^2];
axis(a)

subplot(1,3,2)
ix=find(wrs==min(wrs));
ix=ix(round(length(ix)/2));
rs=rs(ix);
wrs=wrs(ix);
tm=[1/(1+ix*stp) 0;0 (1+ix*stp)];
for j=1:poc
    en{j}=tm*e{j}*tm';
end
[r,f]=eanal(en);
plot(f,r,'b.')
xlabel('Phi');
ylabel('Ri');
title(['De-strained  Rs=' num2str(rs)]);
a=axis;
a(1:3)=[-90 90 1];
axis(a);
set(gca,'XTick',-90:30:90)
tt=get(gca,'YTick');
set(gca,'YScale','log');
set(gca,'YTick',tt);
set(gca,'YGrid','on');
set(gca,'XGrid','on');
if nargout>2
    hm=1./mean(1./rf);   % harmonic mean
    Isym=1-(abs(length(find(rf>hm&phi<=0))-length(find(rf>hm&phi>0)))+abs(length(find(rf<=hm&phi<=0))-length(find(rf<=hm&phi>0))))/length(rf);
end



%------------------------------------------------------------
% Helper functions
function [r,f]=eanal(e)
r=[]; f=[];
for i=1:length(e)
    [v,d]=eig(e{i});   ev=sqrt(diag(d));
    if ev(1)>ev(2)
        r=[r;ev(1)/ev(2)];
        vc=v(:,1);
    else
        r=[r;ev(2)/ev(1)];
        vc=v(:,2);
    end
    if vc(2)>0
        vc=-vc;
    end
    ot=acos(vc'*[-1;0])*180/pi;
    if ot>90
        ot=ot-180;
    end
    f=[f;ot];
end
