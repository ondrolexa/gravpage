function b=dbreadtype(samples,type)
%DBREADTYPE Read all boundaries of choosen type from MySQL database.
% Syntax:  b=dbreadtype;
%          b=dbreadtype(samples,type);
% samples should be cell array (see dbselect) while type string

% This file is part of polyLX.
% 
% polyLX is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% polyLX is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with polyLX.  If not, see <http://www.gnu.org/licenses/>.

% polyLX - MATLAB toolbox for microstructure analyses
% Copyright (C) 2010 Ondrej Lexa

global polylx_prefs
%Check connection
if dbconnect
    if nargin<1
        res=dbcommand(['SELECT name FROM samples']);
        samples={res.name};
        if isempty(samples)
            disp('No samples in open database. Aborting.');
            g=[];
            dbclose
            return
        end
    end
    if nargin<2
        res=dbcommand('SELECT phasea,phaseb FROM boundaries');
        if isempty(res)
            disp('No boundaries of given type in open database. Aborting.');
            b=[];
            dbclose;
            return
        else
            tt=unique([{res.phasea} {res.phaseb}]);
            poc=length(tt);
            ix=0;
            for i=1:poc
                for j=i:poc
                    ix=ix+1;
                    bb{ix}=[tt{i} '-' tt{j}];
                end
            end
            tl=bb';

            [sel,ok] = listdlg('ListString',tl,'SelectionMode','single','Name','Select sample');
            if ok==0
                b=[];
                dbclose;
                return
            else
                type=tl{sel};
            end
        end
    end
    ix=strfind(type,'-');
    pa=type(1:ix-1);
    pb=type(ix+1:end);
    
    ii=1;
    for k=1:length(samples)
        if strcmpi(polylx_prefs.driver,'SQlite3')
            res=dbcommand(['SELECT boundaries.id_boundary, boundaries.id_graina, boundaries.id_grainb, boundaries.X, boundaries.Y FROM boundaries INNER JOIN samples ON samples.id=boundaries.id_sample WHERE samples.name="' samples{k} '" AND (((boundaries.phasea="' pa '") AND (boundaries.phaseb="' pb '")) OR ((boundaries.phasea="' pb '") AND (boundaries.phaseb="' pa '"))) ORDER BY boundaries.id']);
        else
            res=dbcommand(['SELECT boundaries.id_boundary, boundaries.id_graina, boundaries.id_grainb, ''WKT'' as X, AsText(geometry) as Y FROM boundaries INNER JOIN samples ON (samples.id=boundaries.id_sample) WHERE samples.name="' samples{k} '" AND (((boundaries.phasea="' pa '") AND (boundaries.phaseb="' pb '")) OR ((boundaries.phasea="' pb '") AND (boundaries.phaseb="' pa '"))) ORDER BY boundaries.id']);
        end
        poc=length(res);
        if poc>0
            b(ii:poc+1)=polylxboundary;
            h=waitbar(0,'Please wait...','Name',['Reading boundaries ' num2str(k) ' of ' num2str(length(samples)) ' from database...']);
            for i=1:poc;
                b(ii+i-1)=polylxboundary(res(i).id_boundary,res(i).id_graina,res(i).id_grainb,samples{k},'',res(i).X,res(i).Y);
                waitbar(i/poc,h);
            end
            ii=ii+poc;
            close(h)
        end
    end
    dbclose;
end
