function gn=gorten2(g,varargin)
%GORTEN2 Return parameters of covariance matrix of decomposed grain/boundary.
% Syntax: gn=gorten2(g,options);
% g can be grain or boundary object(s)
% When grain objects are passed gn are grains objects with calculated
% properties centre, la,sa,lao,sao. When boundary objects are passed gn is
% structure with fields x[y]centre, lao, sao, la, sa. To plot data from
% structure use PELLIPSE or PCROSS
% options are passed as pairs of option name and option value:
% 'res'      ... resolution i.e. number of vertexes Default 91.
%                res 5 is enough to get la,sa,lao,sao

% This file is part of polyLX.
% 
% polyLX is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% polyLX is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with polyLX.  If not, see <http://www.gnu.org/licenses/>.

% polyLX - MATLAB toolbox for microstructure analyses
% Copyright (C) 2010 Ondrej Lexa

if nargin<1
    help gorten2;
    return;
end

% Process input arguments
opts.res=91;
opts=parseargs(varargin,opts);
if opts.res<5
    opts.res=5;
end

%Initialize
n=length(g);
switch class(g)
    case 'polylxgrain'
        gn(1,n)=polylxgrain;
    case 'polylxboundary'
        gn(1,n)=struct('xcentre',[],'ycentre',[],'lao',[],'sao',[],'la',[],'sa',[]);
    otherwise
        disp('First argument must be grain or boundary object.')
        gn=[];
        return
end
the=linspace(0,360,opts.res)';
if isa(g,'polylxgrain')
    aa=get(g,'area');
else
    aa=pi*get(g,'length').*get(g,'width')/4;
end

h=waitbar(0,'Please wait...','Name','Calculating...');
for ii=1:n
    
    dx=diff(get(g(ii),'x'));
    dy=diff(get(g(ii),'y'));
    if isa(g,'polylxboundary')
        dx=[dx;-dx];
        dy=[dy;-dy];
    end
    
    % calculate covariance matrix
    m=cov([dx dy]);
    
    % Calculate eigenvalues and eigenvectors
    [v,c]=eig(m);
    if c(2,2)<c(1,1)  % Sort eigenvalues and eigenvectors
        c=rot90(c,2);
        v=fliplr(v);
    end
    
    c(c<0)=0; % chybicka zaokruhlovania
    ra = sqrt(c(2,2));
    rb = sqrt(c(1,1));
    % scale axes
    if rb>0
        kk=aa(ii)/(pi*ra*rb);
    else
        kk=1;
    end
    
    la=2*sqrt(kk)*ra;
    sa=2*sqrt(kk)*rb;
    lao = mod(deg(atan2(v(1,2),v(2,2))),180); % orientation
    co=cosd(lao);
    si=sind(lao);
    x=si*cosd(the)*la/2+co*sind(the)*sa/2+get(g(ii),'xcentre');
    y=co*cosd(the)*la/2-si*sind(the)*sa/2+get(g(ii),'ycentre');
    if isa(g,'polylxgrain')
        gn(ii)=polylxgrain(get(g(ii),'id'),...
                           get(g(ii),'phase'),...
                           x,...
                           y,...
                           get(g(ii),'userdata'));
    else
        gn(ii).xcentre=get(g(ii),'xcentre');
        gn(ii).ycentre=get(g(ii),'ycentre');
        gn(ii).lao=lao;
        gn(ii).sao=mod(lao+90,180);
        gn(ii).la=la;
        gn(ii).sa=sa;
    end
    waitbar(ii/n,h);
end
close(h)
