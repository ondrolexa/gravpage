function [x2,y2,grid] = dengrid( xdata, ydata, ntimes, xbin, ybin, xmin, xmax, ymin, ymax);
%DENGRID Return the density grid of a points.  
% [x2,y2,grid] = dengrid( xdata, ydata, ntimes, xbin, ybin, xmin, xmax, ymin, ymax);
% Parameters:
% xdata: The vector of x values
% ydata: The vector of y values
% xbin: The number of bins along the x-axis you want
% ybin: The number of bins along th y-axis you want
% xmin,xmax,ymin,ymax - limits of countig boxes
% ntimes: Number of spline interpolations

% This file is part of polyLX.
% 
% polyLX is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% polyLX is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with polyLX.  If not, see <http://www.gnu.org/licenses/>.

% polyLX - MATLAB toolbox for microstructure analyses
% Copyright (C) 2010 Ondrej Lexa

if nargin<2
    disp('Not enough input arguments');
    return
end

xdata=xdata(:);
ydata=ydata(:);

if nargin<9
    xmin = min(xdata);
    xmax = max(xdata);
    ymin = min(ydata);
    ymax = max(ydata);
end

if nargin<5
    xbin=10;
    ybin=10;
end

if nargin<3
    ntimes=0;
end


grid = zeros(ybin+1, xbin+1);   % Create the output matrix

xstep = (xmax-xmin)/xbin;
ystep = (ymax-ymin)/ybin;


xcentres = linspace(xmin+xstep/2,xmax-xstep/2,xbin);
ycentres = linspace(ymin+ystep/2,ymax-ystep/2,ybin);

[x,y]=meshgrid(xcentres,ycentres);


% censor data
ix=xdata>=xmin&xdata<=xmax&ydata>=ymin&ydata<=ymax;
xdata=xdata(ix);
ydata=ydata(ix);

for i=1:length(xdata)
    xtemp = fix( ( xdata(i)-xmin ) / xstep )+1;
    ytemp = fix( ( ydata(i)-ymin ) / ystep )+1;
    grid(ytemp, xtemp) = grid(ytemp, xtemp)+1;
end

%correct limit values
for i=1:size(grid,1);
   grid(i,end-1)=grid(i,end-1)+grid(i,end);
end
for i=1:size(grid,2);
   grid(end-1,i)=grid(end-1,i)+grid(end,i);
end
grid=grid(1:end-1,1:end-1);

%smooth grid
if ntimes>0
    xstep2=(xmax-xmin)/((2^ntimes)*xbin);
    ystep2=(ymax-ymin)/((2^ntimes)*ybin);
    xcentres2=linspace(xmin+xstep2/2,xmax-xstep2/2,xbin*2^ntimes+1);
    ycentres2=linspace(ymin+ystep2/2,ymax-ystep2/2,ybin*2^ntimes+1);
    [x2,y2]=meshgrid(xcentres2,ycentres2);
    grid=interp2(x,y,grid,x2,y2,'spline');
    grid(grid<0)=0;
else
    x2=x;
    y2=y;
end
