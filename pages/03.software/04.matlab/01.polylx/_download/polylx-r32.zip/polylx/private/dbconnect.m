function res=dbconnect(dbserver,dbname,dbuser,dbpassword,dbdriver)
%DBCONNECT Open the connection to database

% This file is part of polyLX.
% 
% polyLX is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% polyLX is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with polyLX.  If not, see <http://www.gnu.org/licenses/>.

% polyLX - MATLAB toolbox for microstructure analyses
% Copyright (C) 2010 Ondrej Lexa

global polylx_prefs
res=false;
avdrivers={'SQlite3','MySQL'};

if nargin==5
    polylx_prefs=struct('server',dbserver,'database',dbname,'username',dbuser,'password',dbpassword,'driver',dbdriver);
end
if nargin==2
    polylx_prefs=struct('server',dbserver,'database','','username','','password','','driver',dbdriver);
end
    
if ~exist('polylx_prefs','var')
    ok=false;
else
    if ~isfield(polylx_prefs,'driver')
        ok=false;
    else
        if strcmpi(polylx_prefs.driver,'SQlite3')
            if ~isfield(polylx_prefs,'server')|isempty(polylx_prefs.server)
                ok=false;
            else
                ok=true;
            end
        else
            if ~isfield(polylx_prefs,'server')|~isfield(polylx_prefs,'database')|~isfield(polylx_prefs,'username')|~isfield(polylx_prefs,'password')|~isfield(polylx_prefs,'driver')|~(~isempty(polylx_prefs.server)&~isempty(polylx_prefs.database)&~isempty(polylx_prefs.username)&~isempty(polylx_prefs.driver))
                ok=false;
            else
                ok=true;
            end
        end
    end
end

while ~ok
    [sel,ok]=listdlg('ListString',avdrivers,'SelectionMode','single','ListSize',[120 50],'Name','Connection','PromptString','Select database type');
    if isempty(sel)
        return
    end
    driver=avdrivers{sel};
    if strcmpi(driver,'SQlite3')
        [fname,path] = uigetfile('*.plx','PolyLX database');
        if isa(fname,'double')
            clear global polylx_prefs
            return
        end
        polylx_prefs=struct('server',fullfile(path,fname),'driver',driver);
        ok=true;
    else
        answer=inputdlg({'Database server:','Database:','Username:','Password:'},'Database connection',1,{'localhost','polylx','',''});
        if isempty(answer)
            clear global polylx_prefs
            return
        end
        polylx_prefs=struct('server',answer{1},'database',answer{2},'username',answer{3},'password',answer{4},'driver',driver);
        ok=~isempty(polylx_prefs.server)&~isempty(polylx_prefs.database)&~isempty(polylx_prefs.username)&~isempty(polylx_prefs.driver);
    end
end
if ~isfield(polylx_prefs,'connected')
    if strcmpi(polylx_prefs.driver,'SQlite3')
        sql = {'PRAGMA synchronous=OFF','PRAGMA journal_mode=OFF','PRAGMA encoding=''UTF-8'''};
        % Define connection string
        try
            dbconn = mksqlite(0, 'open', polylx_prefs.server);
            for i=1:length(sql)
                mksqlite(dbconn,sql{i});
            end
            polylx_prefs=setfield(polylx_prefs,'connected',dbconn);
        catch ME
            disp('Error occured during database connection.')
            disp(ME.message)
            clear global polylx_prefs
            return
        end
    else
        setdbprefs('DataReturnFormat','structure');
        % Define connection string
        dbconn = database(polylx_prefs.database,polylx_prefs.username,polylx_prefs.password,'com.mysql.jdbc.Driver',['jdbc:mysql://' polylx_prefs.server '/' polylx_prefs.database]);
        if ~isempty(dbconn.Message)
            disp(dbconn.Message)
            clear global polylx_prefs
            return
        else
            polylx_prefs=setfield(polylx_prefs,'connected',dbconn);
        end
    end
end
res=true;
