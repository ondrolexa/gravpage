function g=genssi(w,h,mind,maxd,mpok)
%GENSSI Routine to generate anti-clustered circular grains.
% Syntax: g=genssi(w,h,mind,maxd,mpok);
% w     ... width of rectangular domain [100]
% h     ... heighth of rectangular domain [100]
% mind  ... minimal diameter [4]
% maxd  ... maximal diameter [14]
% mpok  ... maximum number of attempt to place object before stop process [10000]

% This file is part of polyLX.
% 
% polyLX is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% polyLX is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with polyLX.  If not, see <http://www.gnu.org/licenses/>.

% polyLX - MATLAB toolbox for microstructure analyses
% Copyright (C) 2010 Ondrej Lexa

if nargin<5
   mpok=10000;
end
if nargin<4
   maxd=14;
end
if nargin<3
   mind=4;
end
if nargin<2
   w=100;
end
if nargin<1
   h=100;
end


ang=linspace(0,2*pi,72)'; 
ang=ang(1:end-1);
x=w*rand(1,1);
y=h*rand(1,1);
r=((maxd-mind)*rand(1,1)+mind)/2;
g(1)=polylxgrain(1,'c',x+sin(ang)*r,y+cos(ang)*r);
pok=0;

while pok<mpok;
   pok=0;
   dr=10;
   while ((dr>0)&&(pok<mpok));
      xt=w*rand(1,1);
      yt=h*rand(1,1);
      rt=((maxd-mind)*rand(1,1)+mind)/2;
      dx=xt-x;
      dy=yt-y;
      d=min(sqrt(dx.^2+dy.^2)-r);
      dr=rt-d;
      pok=pok+1;
   end
   if dr<=0
      x=[x;xt];
      y=[y;yt];
      r=[r;rt];
      g(length(g)+1)=polylxgrain(length(g)+1,'c',xt+sin(ang)*rt,yt+cos(ang)*rt);
      disp(['Added ' num2str(length(x)) ' circle after ' num2str(pok) ' attempts.']);
   end
end

