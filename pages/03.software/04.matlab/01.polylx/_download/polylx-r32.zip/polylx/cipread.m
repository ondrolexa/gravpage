function c = cipread(dirname)
%CIPREAD Read cipdata.
% Syntax:
%      c = cipread;
%      c = cipread('workdirname');

% This file is part of polyLX.
% 
% polyLX is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% polyLX is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with polyLX.  If not, see <http://www.gnu.org/licenses/>.

% polyLX - MATLAB toolbox for microstructure analyses
% Copyright (C) 2010 Ondrej Lexa

%remember actual directory
adir = pwd;

if nargin<1
    dirname = pwd;
end

%ask for datafiles
cd(dirname)
[fazi, pazi]=uigetfile({'*.AZI','AZI file (*.AZI)'},'Open AZI file from CIP1A');
if fazi == 0
    c=[];
    return
end
[fincp, pincp]=uigetfile({'*.INC*','INC file (*.INC)'},'Open INC file from CIP1B');
if fincp == 0
    c=[];
    return
end
[fmask, pmask]=uigetfile({'*.*','Mask file (*.*)'},'Open mask file from input');
if fmask == 0
    c=[];
    return
end

cd(adir);
%reshape inputfiles to image size
f = fopen(fullfile(pazi,fazi),'r');
aa = fread(f);
fclose(f);
f = fopen(fullfile(pincp,fincp),'r');
ii = fread(f);
fclose(f);
f = fopen(fullfile(pmask,fmask),'r');
mm = fread(f);
fclose(f);
%ask for image size
[dummy,fnm,dummy]=fileparts(fmask);
if exist(fullfile(pmask,[fnm '.size']),'file')
    fid=fopen(fullfile(pmask,[fnm '.size']),'r');
    sz=fscanf(fid,'%d',2);
    ix=sz(1);
    iy=sz(2);
else
    ok = false;
    while ~ok
        sz=inputdlg({'Width:','Heigth:'},'Image size:',1,{'1200','1000'});
        ix=str2double(sz{1});
        iy=str2double(sz{2});
        ok = (ix*iy == length(aa));
    end
    fid=fopen(fullfile(pmask,[fnm '.size']),'w');
    fprintf(fid,'%d\n',[ix iy]);
    fclose(fid);
end
% reshape to image
azi = reshape(aa,ix,iy)';
incp = reshape(ii,ix,iy)';
mask = reshape(mm(1:ix*iy)>0,ix,iy)';
%Apply and extend mask, recalculate azimuths, dips
mask = mask & incp<=180;
%incp(~mask) = nan;
incp = incp-90;
%extend mask to invalid data
mask = mask & azi<=180;
%azi(~mask) = nan;
azi(incp<0) = azi(incp<0)+180;
incp = abs(incp);
%get name
[dummy,name] = fileparts(fullfile(pazi,fazi));
%creatre object
c = cipdata(azi,incp,mask,name);
