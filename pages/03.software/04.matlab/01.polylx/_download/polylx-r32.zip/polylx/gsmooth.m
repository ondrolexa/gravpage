function gn=gsmooth(g,varargin)
%GSMOOTH Smooth outlines of grain objects.
% Syntax: gn=gsmooth(g,options);
% Options are:
%  'method'  ... 'dp' Douglas-Peucker simplification. Default.
%            ... 'bezier' quadratic bezier curves approximation.
%            ... 'average' averaging of neighborough coordinates.
%                          Works well for staircase boundaries.
%            ... 'renee' Regularize outlines with pchip (similar to SCASMO)
%            ... 'fourier' Elliptic Fourier smooth
%  'tol'     ... Distance tolerance for Douglas-Peucker and bezier.
%                Default 1/100 of mode of EAD.
%  'step'    ... Approximate length of segments for renee method.
%  'nh'      ... number of harmonics used for reconstruction defined
%                as fraction of all calculated harmonics. 0 for 1 and 1 for
%                floor(N/2). Default 0.25
%  'nn'      ... number of vertices on reconstructed outline defined as
%                fraction so number of vertices is nN*N. Default 0.5

% This file is part of polyLX.
% 
% polyLX is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% polyLX is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with polyLX.  If not, see <http://www.gnu.org/licenses/>.

% polyLX - MATLAB toolbox for microstructure analyses
% Copyright (C) 2010 Ondrej Lexa

if nargin<1
    help gsmooth
    return
end

% initialize defaults and parse arguments
opts.method='dp';
ead=get(g,'ead');
opts.tol=exp(mean(log(ead))-std(log(ead))^2)/100;
opts.step=exp(mean(log(ead)))/5;
opts.nh=0.25;
opts.nn=0.5;
opts=parseargs(varargin,opts);

pocet=length(g);
h=waitbar(0,'Please wait...','Name',['Smoothing... [' opts.method ']']);
switch opts.method
    case 'average'
        for ii=1:pocet
            [x,y]=get(g(ii),'x','y');
            xm=mean([x(1:end-1) x(2:end)],2);
            xm=[xm;xm(1);NaN];
            ym=mean([y(1:end-1) y(2:end)],2);
            ym=[ym;ym(1);NaN];
            nh=get(g(ii),'nholes');
            if nh>0
                hh=get(g(ii),'holes');
                for j=1:nh
                    txm=mean([hh(j).x(1:end-1) hh(j).x(2:end)],2);
                    xm=[xm;txm;txm(1);NaN];
                    tym=mean([hh(j).y(1:end-1) hh(j).y(2:end)],2);
                    ym=[ym;tym;tym(1);NaN];
                end
            end
            xm=xm(1:end-1);
            ym=ym(1:end-1);
            gn(ii)=polylxgrain(get(g(ii),'id'),char(get(g(ii),'phase')),xm,ym,get(g(ii),'UserData'));
            waitbar(ii/pocet,h);
        end
        close(h)
    case 'dp'
        disp(['Using tolerance ' num2str(opts.tol)])
        cix=1;
        for ii=1:pocet
            [x,y]=get(g(ii),'x','y');
            [nx,ny]=dpsimply(x(1:end-1),y(1:end-1),opts.tol);
            if length(nx)>2
                nx=[nx;nx(1);NaN];
                ny=[ny;ny(1);NaN];
                nh=get(g(ii),'nholes');
                if nh>0
                    hh=get(g(ii),'holes');
                    for j=1:nh
                        [tnx,tny]=dpsimply(hh(j).x(1:end-1),hh(j).y(1:end-1),opts.tol);
                        if length(tnx)>2
                            nx=[nx;tnx;tnx(1);NaN];
                            ny=[ny;tny;tny(1);NaN];
                        else
                            disp(['Hole ' num2str(j) ' of grain ' num2str(ii) ' degenerate and was discarded.'])
                        end
                    end
                end
                nx=nx(1:end-1);
                ny=ny(1:end-1);
                gn(cix)=polylxgrain(get(g(ii),'id'),char(get(g(ii),'phase')),nx,ny,get(g(ii),'UserData'));
                cix=cix+1;
            else
                disp(['Grain ' num2str(ii) ' degenerate and was discarded.'])
            end
            waitbar(ii/pocet,h);
        end
        close(h)
    case 'bezier'
        disp(['Using tolerance ' num2str(opts.tol)])
        cix=1;
        for ii=1:pocet
            [x,y]=get(g(ii),'x','y');
            [nx,ny]=bezcurve(x,y);
            [nx,ny]=dpsimply(nx(1:end-1),ny(1:end-1),opts.tol);
            if length(nx)>2
                nx=[nx;nx(1);NaN];
                ny=[ny;ny(1);NaN];
                nh=get(g(ii),'nholes');
                if nh>0
                    hh=get(g(ii),'holes');
                    for j=1:nh
                        [tnx,tny]=bezcurve(hh(j).x,hh(j).y);
                        [tnx,tny]=dpsimply(tnx(1:end-1),tny(1:end-1),opts.tol);
                        if length(tnx)>2
                            nx=[nx;tnx;tnx(1);NaN];
                            ny=[ny;tny;tny(1);NaN];
                        else
                            disp(['Hole ' num2str(j) ' of grain ' num2str(ii) ' degenerate and was discarded.'])
                        end
                    end
                end
                nx=nx(1:end-1);
                ny=ny(1:end-1);
                gn(cix)=polylxgrain(get(g(ii),'id'),char(get(g(ii),'phase')),nx,ny,get(g(ii),'UserData'));
                cix=cix+1;
            else
                disp(['Grain ' num2str(ii) ' degenerate and was discarded.'])
            end
            waitbar(ii/pocet,h);
        end
        close(h)
    case 'renee'
        disp(['Using step ' num2str(opts.step)])
        cix=1;
        for ii=1:pocet
            [x,y]=get(g(ii),'x','y');
            [nx,ny]=renee(x,y,opts.step);
            s=[0;cumsum(sqrt(diff(x).^2+diff(y).^2))];
            ns=[[0:opts.step:s(end)]';s(end)];
            ss=[s(1:end-1)-s(end);s;s(2:end)+s(end)];
            xx=[x(1:end-1);x;x(2:end)];
            yy=[y(1:end-1);y;y(2:end)];
            x1=pchip(ss,xx,ns);
            y1=pchip(ss,yy,ns);
            nh=get(g(ii),'nholes');
            xh=NaN;
            yh=NaN;
            if nh>0
                hh=get(g(ii),'holes');
                for j=1:nh
                    sh=[0;cumsum(sqrt(diff(hh(j).x).^2+diff(hh(j).y).^2))];
                    nsh=[[0:opts.step:sh(end)]';sh(end)];
                    ssh=[sh(1:end-1)-sh(end);sh;sh(2:end)+sh(end)];
                    xxh=[hh(j).x(1:end-1);hh(j).x;hh(j).x(2:end)];
                    yyh=[hh(j).y(1:end-1);hh(j).y;hh(j).y(2:end)];
                    x1h=pchip(ssh,xxh,nsh);
                    y1h=pchip(ssh,yyh,nsh);
                    if length(x1h)>3
                        xh=[xh;x1h;NaN];
                        yh=[yh;y1h;NaN];
                    end
                end
            end
            if isnan(xh(end))
                xh=xh(1:end-1);
                yh=yh(1:end-1);
            end
            if length(x1)>3
                gn(cix)=polylxgrain(get(g(ii),'id'),char(get(g(ii),'phase')),[x1;xh],[y1;yh],get(g(ii),'UserData'));
                cix=cix+1;
            else
               disp(['Grain ' num2str(ii) ' degenerate and was discarded.'])
            end 
            waitbar(ii/pocet,h);
        end
        close(h)
    case 'fourier'
        disp(['Using nh ' num2str(opts.nh) ' and nn ' num2str(opts.nn)])
        for ii=1:pocet
            xy=get(g(ii),'x','y');
            fd=fourierdesc(xy);
            K=max(1,min(size(fd,2), round(opts.nh*size(fd,2))));
            N=max(3,round(opts.nn*size(xy,1)));
            xc=mean(xy);
            [k,l]=meshgrid(1:K,0:N);
            nxy=[xc(1)+sum(repmat(fd(1,1:K),N+1,1).*cos(2*pi*k.*l/N)+repmat(fd(2,1:K),N+1,1).*sin(2*pi*k.*l/N),2) ...
                 xc(2)+sum(repmat(fd(3,1:K),N+1,1).*cos(2*pi*k.*l/N)+repmat(fd(4,1:K),N+1,1).*sin(2*pi*k.*l/N),2)];
            gn(ii)=polylxgrain(get(g(ii),'id'),char(get(g(ii),'phase')),nxy(:,1),nxy(:,2),get(g(ii),'UserData'));
            waitbar(ii/pocet,h);
        end
        close(h)
    otherwise
        gn=g;
end

function [nx,ny]=dpsimply(x,y,tol,sx,sy)

if nargin<5
    sx=x(1);
    sy=y(1);
end

x0=x(1);
dx=x(end)-x0;
y0=y(1);
dy=y(end)-y0;
tria=abs((x-x0)*dy-(y-y0)*dx)/sqrt(dx*dx+dy*dy);
[mx,ix]=max(tria);
if mx>tol
    sx=[sx;x(ix)];
    sy=[sy;y(ix)];
    [sx,sy]=dpsimply(x(1:ix),y(1:ix),tol,sx,sy);
    if nargin<5
        [sx,sy]=dpsimply([x(ix:end);x(1)],[y(ix:end);y(1)],tol,sx,sy);
    else
        [sx,sy]=dpsimply(x(ix:end),y(ix:end),tol,sx,sy);
    end
end
nx=sx;
ny=sy;
if nargin<5
    nx=[nx;x(end)];
    ny=[ny;y(end)];
    [dummy,ia,dummy]=intersect([x y],[nx ny],'rows');
    ia=sort(ia);
    nx=x(ia);
    ny=y(ia);
end

function [xs,ys]=bezcurve(x,y)
x=[x(:);x(2)];
y=[y(:);y(2)];
t=linspace(0,1,20)';
xs=[];
ys=[];
for i=2:length(x)-1
    xs=[xs(1:end-1);(x(i-1)+x(i))*(1 - t).^2/2 + 2*x(i)*(1-t).*t + (x(i)+x(i+1))*t.^2/2];
    ys=[ys(1:end-1);(y(i-1)+y(i))*(1 - t).^2/2 + 2*y(i)*(1-t).*t + (y(i)+y(i+1))*t.^2/2];
end
