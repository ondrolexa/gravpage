function [g,pth,fnm]=shpread(varargin)
%SHPREAD Read grain/boundary geometry from ArcView shapefile.
% Syntax:  [g,path,filename]=shpread;
%              [g,path,filename]=shpread(filename);

% This file is part of polyLX.
% 
% polyLX is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% polyLX is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with polyLX.  If not, see <http://www.gnu.org/licenses/>.

% polyLX - MATLAB toolbox for microstructure analyses
% Copyright (C) 2010 Ondrej Lexa

% GUI open file
pth=[]; fnm=[];
if nargin<1
    [fnm, pth]=uigetfile({'*.shp','ESRI Shapefiles (*.shp)'},'Open Shapefile');
    if fnm==0
        g=[];
        return
    end
    filename=[pth fnm];
else
    filename=varargin{1};
    if isempty(strfind(filename,'.shp'))||~exist(filename,'file')
        g=[];
        error('First argument must be valid filename of shapefile with extension. Aborted.');
    end
    ix=find(filename=='\');
    if isempty(ix);
        ix=0;
    end
    fnm=filename(ix(end)+1:end);
    pth=filename(1:ix(end));
end
dbfile=strrep(filename,'.shp','.dbf');
klasik=true;
if nargin>1
    if isa(varargin{2},'char')
        klasik=false;
        fakephase=varargin{2};
    end
end

% helpers
big=[256^3 256^2 256 1]';

fid=fopen(filename,'r','l');
fdb=fopen(dbfile,'r','l');

% Read header of shape file

% File code (Big order)
[bfc,c]=fread(fid,4,'uint8');
filecode=sum(bfc.*big);

if filecode~=9994
    g=[];
    error('Not valid shape file. Aborted.')
end

% Skip unused
[skip,c]=fread(fid,5,'uint32');

% File length (BIG order)
[bfl,c]=fread(fid,4,'uint8');
filelength=sum(bfl.*big);

% Version
[vers,c]=fread(fid,1,'uint32');

% Shape type
[shptype,c]=fread(fid,1,'uint32');

if (shptype~=5)&(shptype~=3)
    g=[];
    error('Only polygon/polyline shapefiles are supported. Aborted.')
end

% Bounding box
[bbox,c]=fread(fid,4,'double');
[skip,c]=fread(fid,4,'double');

% Read fields from dbf file

[valid,c]=fread(fdb,1,'uint8');
if valid~=3
    disp ('Not valid dbf file')
    return
end
[skip,c]=fread(fdb,3,'uint8');
[recnum,c]=fread(fdb,1,'uint32');
[headb,c]=fread(fdb,1,'uint16');
[skip,c]=fread(fdb,22,'uint8');

numfields=((headb-33)/32);

if (numfields<1)
    g=[];
    error('There is no attributes table in this shapefile. Aborted.')
end

for i=1:numfields
   fd(i).name=deblank(char(fread(fdb,11,'uint8')'));
   fd(i).type=char(fread(fdb,1,'uint8'));
   [skip,c]=fread(fdb,4,'uint8');
   fd(i).length=fread(fdb,1,'uint8');
   fd(i).dec=fread(fdb,1,'uint8');
   [skip,c]=fread(fdb,14,'uint8');
end
[skip,c]=fread(fdb,1,'uint8');

% Select id field
idfield=find(strcmpi('id',{fd.name}));
if isempty(idfield)
    noid=true;
    disp('There is no ID field in your attribute table. ID will be sequential.')
else
    noid=false;
end

if shptype==5&&klasik==true;
    % Select phase field
    phfield=find(strcmpi('phase',{fd.name}));
    if isempty(phfield)
        [phfield,valid]=listdlg('PromptString','Select Phase field:','SelectionMode','Single','Name','shpread','ListString',{fd.name});
        if valid~=1
            klasik=false;
            fakephase='None';
        end
    end
end

if shptype==3
    if all([any(strcmpi({fd.name},'id')) any(strcmpi({fd.name},'ida')) any(strcmpi({fd.name},'idb')) any(strcmpi({fd.name},'phasea')) any(strcmpi({fd.name},'phaseb'))])
        klasik=true;
    else
        klasik=false;
        [tpfield,valid]=listdlg('PromptString','Select Type field:','SelectionMode','Single','Name','shpread','ListString',{fd.name});
    end
end


% Set current position
cp=50;
idx=0;
h=waitbar(0,'Please wait...','Name','Reading geometry...');

while cp<filelength
    % read dbf record
    [skip,c]=fread(fdb,1,'uint8');
    udata=[];
    % force id to numeric
    if ~noid
        fd(idfield).type='N';
    end
    for j=1:numfields
        if fd(j).type=='N'
            rec{j}=str2double(char(fread(fdb,fd(j).length,'uint8')'));
            %null id
            if isempty(rec{j})
                rec{j}=0;
            end
        else
            rec{j}=deblank(char(fread(fdb,fd(j).length,'uint8')'));
        end
        udata.(fd(j).name)=rec{j};
    end
    % remove Id
    if ~noid
        udata=rmfield(udata,fd(idfield).name);
    end

    % Record number(BIG order)
    [brn,c]=fread(fid,4,'uint8');
    recnum=sum(brn.*big);
    % Record ID
    if noid
        recid=idx;
    else
        recid=rec{idfield};
    end
    % Content length(BIG order)
    [bcl,c]=fread(fid,4,'uint8');
    [skip,c]=fread(fid,1,'uint32');
    contlen=sum(bcl.*big);
    % update position
    cp=cp+contlen+4;
    % Record content
    [bbox,c]=fread(fid,4,'double');
    [numparts,c]=fread(fid,1,'uint32');
    [numpoints,c]=fread(fid,1,'uint32');
    [parts,c]=fread(fid,numparts,'uint32');
    [points,c]=fread(fid,numpoints*2,'double');
    if numparts>0
        pts=reshape(points,2,size(points,1)/2)';
        parts=[parts;size(pts,1)];
        idx=idx+1;
        x=[];
        y=[];
        for i=1:numparts
            x=[x;pts((parts(i)+1):(parts(i+1)),1);NaN];
            y=[y;pts((parts(i)+1):(parts(i+1)),2);NaN];
        end
        x=x(1:end-1);
        y=y(1:end-1);
        if shptype==5
            if klasik
                %Remove phase field from userdata
                udata=rmfield(udata,fd(phfield).name);
                if isempty(rec{phfield})
                    rec{phfield}='None';
                end
                % add grain
                [gg, err]=polylxgrain(recid,rec{phfield},x,y,udata);
                if ~err
                    g(idx)=gg;
                else
                    disp(['Skipping invalid object ID: ' num2str(recid)]);
                    idx=idx-1;
                end
                    
            else
                [gg, err]=polylxgrain(recid,fakephase,x,y,udata);
                if ~err
                    g(idx)=gg;
                else
                    disp(['Skipping invalid object ID: ' num2str(recid)]);
                    idx=idx-1;
                end
            end
        else
            % add boundary
            if klasik
                %Remove klasik fields from userdata
                for i=2:5
                    udata=rmfield(udata,fd(i).name);
                end
                g(idx)=polylxboundary(rec{1},rec{2},rec{3},rec{4},rec{5},x,y,udata);
            else
                if isempty(tpfield)
                    g(idx)=polylxboundary(recid,1,1,'None','None',x,y,udata);
                else
                    g(idx)=polylxboundary(recid,1,1,rec{tpfield},'',x,y,udata);
                end
            end
        end
    else
        % Null or degenerated shape. Skip
        disp(['Skipping invalid object ID: ' num2str(recid)]);
    end
    waitbar(cp/filelength,h);
end
close(h)
fclose(fdb);
fclose(fid);
