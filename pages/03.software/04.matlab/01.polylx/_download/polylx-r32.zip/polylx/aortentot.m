function [la,sa,lao,sao]=aortentot(g,opt)
%AORTENTOT Return results of covariance matrix eigenanalysis.
% Syntax: [la,sa,lao,sao]=aortentot(g,opt);
% g can be grain and boundary object(s)
% opt 0 ... use decomposed segments of all objects (default)
%     1 ... use centre to outline vectors all objects
%     2 ... use long axes of uniform length (one per object)
%     3 ... use long axes of proportional length (one per object)

% This file is part of polyLX.
% 
% polyLX is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% polyLX is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with polyLX.  If not, see <http://www.gnu.org/licenses/>.

% polyLX - MATLAB toolbox for microstructure analyses
% Copyright (C) 2010 Ondrej Lexa

if nargin<1
    help aortentot
    error('Wrong arguments.')
end

if ~isa(g,'polylxgrain') && ~isa(g,'polylxboundary')
    help aortentot
    error('Wrong arguments.')
end

if nargin<2
    opt=0;
end

%Initialize
poc=size(g,2);
xx=[];
yy=[];

h=waitbar(0,'Please wait...','Name','Calculating...');
for ii=1:poc
    switch opt
        case 0
            x=diff(get(g(ii),'x'));
            y=diff(get(g(ii),'y'));
            if isa(g,'polylxboundary')
                x=[x;-x];
                y=[y;-y];
            end
        case 1
            x=get(g(ii),'x')-get(g(ii),'xcentre');
            y=get(g(ii),'y')-get(g(ii),'ycentre');
            if isa(g,'polylxgrain')
                x=x(1:end-1);
                y=y(1:end-1);
            end
        case 2
            or=get(g(ii),'orientation');
            x=[sind(or);-sind(or)];
            y=[cosd(or);-cosd(or)];
        case 3
            or=get(g(ii),'orientation');
            la=get(g(ii),'length');
            x=[la*sind(or);-la*sind(or)];
            y=[la*cosd(or);-la*cosd(or)];
        otherwise
            close (h)
            help aortentot
            error ('Wrong argument');
    end
    xx=[xx;x];
    yy=[yy;y];
    waitbar(ii/poc,h);
end

% calculate covariance matrix
m=cov([xx yy]);

% Calculate eigenvalues and eigenvectors
[v,c]=eig(m);
if c(2,2)<c(1,1)  % Sort eigenvalues and eigenvectors
   c=rot90(c,2);
   v=fliplr(v);
end

c(c<0)=0; % chybicka zaokruhlovania

la = c(2,2);
sa = c(1,1);
lao = mod(deg(atan2(v(1,2),v(2,2))),180);
sao = mod(deg(atan2(v(1,1),v(2,1))),180);

close(h)
