function [stat,up]=dblist
%DBLIST Show informations about stored data in database.
% Syntax: res=dblist;
%         [res,up]=dblist;
%
% res   ... array of sample names, number of grains and number of phases
% up    ... list of unique phase names in database

% This file is part of polyLX.
% 
% polyLX is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% polyLX is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with polyLX.  If not, see <http://www.gnu.org/licenses/>.

% polyLX - MATLAB toolbox for microstructure analyses
% Copyright (C) 2010 Ondrej Lexa

global polylx_prefs
%Check connection
if dbconnect

    res=dbcommand('SELECT id,name FROM samples ORDER BY name');
    if isempty(res)
        disp('No samples in open database. Aborting.');
        dbclose
        return
    else
        up={};
        stat={};
        for i=1:length(res)
            stat{1,i}=res(i).name;
            upt=dbcommand(['SELECT phase FROM grains WHERE id_sample=' num2str(res(i).id)]);
            stat{2,i}=length(upt);
            upt=unique({upt.phase});
            stat{3,i}=length(upt);
            up=union(up,upt);
        end
        stat=stat';
        if nargout<1
            disp([{'Sample','Grains','Phases'};stat]);
            clear stat
            clear up
        end
    end
    dbclose;
end
