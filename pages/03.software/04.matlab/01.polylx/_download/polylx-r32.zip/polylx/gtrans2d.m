function gn=gtrans2d(g,varargin)
%GTRANS2D Transform grain objects using transformation matrix tm.
% Syntax: gn=gtrans2d(g,options);
% g is grain object
% options are passed as pairs of option name and option value:
% 'tm'         ... apply 2x2 transformation matrix
% 'rotate'     ... apply rotation
% 'scale'      ... apply scaling
% 'dx'         ... translation in x direction
% 'dy'         ... translation in y direction
% 'centre'     ... 0 centre of transormation is [0,0] 1 ... centre is
%                  object centre. Default 0

% This file is part of polyLX.
% 
% polyLX is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% polyLX is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with polyLX.  If not, see <http://www.gnu.org/licenses/>.

% polyLX - MATLAB toolbox for microstructure analyses
% Copyright (C) 2010 Ondrej Lexa

if nargin<2
   gn=g;
   return
end

if ~isa(g,'polylxgrain')
    error('First argument must be grain objects');
end

% Process input arguments
opts.tm=[1 0;0 1];
opts.rotate=0;
opts.scale=1;
opts.dx=0;
opts.dy=0;
opts.centre=0;
opts=parseargs(varargin,opts);
opts.rotate=opts.rotate*pi/180;

% main
pocet=length(g);
% check homogeneous transformation
if all(size(opts.tm)==3)
    opts.dx=opts.tm(1,3);
    opts.dy=opts.tm(2,3);
    opts.tm = opts.tm(1:2,1:2);
end

h=waitbar(0,'Please wait...','Name','Transforming...');
tm=opts.tm*[cos(opts.rotate) sin(opts.rotate);-sin(opts.rotate) cos(opts.rotate)]*[opts.scale 0;0 opts.scale];
for ii=1:pocet
   [x,y]=get(g(ii),'x','y');
   if opts.centre
       x=x-get(g(ii),'xcentre');
       y=y-get(g(ii),'ycentre');
   end
   co=tm*[x';y'];
   xr=co(1,:)+opts.dx;
   yr=co(2,:)+opts.dy;
   xt=xr-mean(xr);
   yt=yr-mean(yr);
   dx=xt([2:end 1])-xt;
   dy=yt([2:end 1])-yt;
   mirr=sign(sum(yt.*dx-xt.*dy)/2);
   % Check mirror transformations
   if mirr~=1
      xr=fliplr(xr);
      yr=fliplr(yr);
   end
   w=get(g(ii),'Holes');
   for jj=1:length(w)
      co=tm*[w(jj).x';w(jj).y'];
      co=[co(1,:)+opts.dx;co(2,:)+opts.dy];
      if mirr~=1
         xr=[xr NaN fliplr(co(1,:))];
         yr=[yr NaN fliplr(co(2,:))];
      else
         xr=[xr NaN co(1,:)];
         yr=[yr NaN co(2,:)];
      end
   end
   if opts.centre
       gn(ii)=polylxgrain(get(g(ii),'id'),get(g(ii),'phase'),get(g(ii),'xcentre')+xr',get(g(ii),'ycentre')+yr');
   else
       gn(ii)=polylxgrain(get(g(ii),'id'),get(g(ii),'phase'),xr',yr');
   end
   waitbar(ii/pocet,h);
end
close(h)
