function [r,g,b]=azidip2color(azi,dip,varargin)
%AZIDIP2COLOR Return RGB grid from azimuth and dip grid
% Syntax: [r,g,b]=azidip2color(azi,dip,options);
% options are passed as pairs of option name and option value:
% 'axial'   ... 0 - axial 1 - directed LUT. Default 0
% 'lut'     ... Type of color LUT
%           'cip'    ... default coloring with dark center
%           'renee'  ... coloring similar to CIP by Renee Heilbronner
%           'poles' ... coloring with fine resolution around poles

% This file is part of polyLX.
% 
% polyLX is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% polyLX is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with polyLX.  If not, see <http://www.gnu.org/licenses/>.

% polyLX - MATLAB toolbox for microstructure analyses
% Copyright (C) 2010 Ondrej Lexa

% initialize defaults and parse arguments
opts.axial=0;
opts.lut='cip';
opts=parseargs(varargin,opts);

if opts.axial==0
    h = mod(azi+60,180)/180;
else
    h = mod(azi+60,360)/360;
end
switch lower(opts.lut)
    case 'renee'
        rgb = hsv2rgb([1-h(:) (1-dip(:)/90).^1.5 ones(size(dip(:)))]);
    case 'poles'
        h = mod(azi,180)/180;
        rgb = hsv2rgb([(1-dip(:)/180).^2.*0.85.*abs(1-2*h(:)) 1-dip(:)/90 1-dip(:)/90]);
    otherwise
        rgb = hsv2rgb([1-h(:) 1-dip(:)/90 1-dip(:)/90]);
end
r = reshape(rgb(:,1),size(azi));
g = reshape(rgb(:,2),size(azi));
b = reshape(rgb(:,3),size(azi));