function [g,b]=dbread(sample)
%DBREAD Read a grain geometry from database.
% When second output argument is provided, boundaries are automatically
% constructed.
% Syntax:  g=dbread;
%          [g,b]=dbread;
%          [g,b]=dbread(sample);
% sample have to be string

% This file is part of polyLX.
% 
% polyLX is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% polyLX is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with polyLX.  If not, see <http://www.gnu.org/licenses/>.

% polyLX - MATLAB toolbox for microstructure analyses
% Copyright (C) 2010 Ondrej Lexa

global polylx_prefs
%Check connection
if dbconnect
    if nargin<1
        res=dbcommand(['SELECT name FROM samples ORDER BY name']);
        if isempty(res)
            disp('No samples in open database. Aborting.');
            g=[];
            dbclose;
            return
        else
            [sel,ok] = listdlg('ListString',{res.name},'SelectionMode','single','Name','Select sample');
            if ok==0
                g=[];
                dbclose;
                return
            else
                sample=res(sel).name;
            end
        end
    end

    % read sample
    res=dbcommand(['SELECT id FROM samples WHERE name=''' sample '''']);
    if isempty(res)
        disp(['No sample ' sample ' in open database. Aborting.']);
        g=[];
    else
        id_sample=res.id;
        h=waitbar(0,'Please wait...','Name','Reading grains from database...');
        if strcmpi(polylx_prefs.driver,'SQlite3')
            res=dbcommand(['SELECT id_grain, phase, X, Y FROM grains WHERE id_sample=' num2str(id_sample) '  ORDER BY id']);
        else
            res=dbcommand(['SELECT id_grain, phase, ''WKT'' as X, AsText(geometry) as Y FROM grains WHERE id_sample=' num2str(id_sample) '  ORDER BY id']);
        end
        poc=length(res);
        if poc>0
            g(1:poc)=polylxgrain;
            for i=1:poc;
                g(i)=polylxgrain(res(i).id_grain,res(i).phase,res(i).X,res(i).Y);
                waitbar(i/poc,h);
            end
            close(h)
        end
        if nargout>1
            h=waitbar(0,'Please wait...','Name','Reading boundaries from database...');
            if strcmpi(polylx_prefs.driver,'SQlite3')
                res=dbcommand(['SELECT id_boundary, id_graina, id_grainb, phasea, phaseb, X, Y FROM boundaries WHERE id_sample=' num2str(id_sample) ' ORDER BY id']);
            else
                res=dbcommand(['SELECT id_boundary, id_graina, id_grainb, phasea, phaseb, ''WKT'' as X, AsText(geometry) as Y FROM boundaries WHERE id_sample=' num2str(id_sample) ' ORDER BY id']);
            end
            poc=length(res);
            if poc>0
                b(1:poc)=polylxboundary;
                for i=1:poc;
                    b(i)=polylxboundary(res(i).id_boundary,res(i).id_graina,res(i).id_grainb,res(i).phasea,res(i).phaseb,res(i).X,res(i).Y);
                    waitbar(i/poc,h);
                end
            else
                b=bmake(g);
            end
            close(h)
        end
    end
    dbclose;
end
