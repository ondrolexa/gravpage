function varargout = get(b, varargin)
%GET Get boundary properties

% This file is part of polyLX.
% 
% polyLX is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% polyLX is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with polyLX.  If not, see <http://www.gnu.org/licenses/>.

% polyLX - MATLAB toolbox for microstructure analyses
% Copyright (C) 2010 Ondrej Lexa

if nargout~=(nargin-1)&&nargout>1
    error('Wrong Number of arguments')
end

n=length(b);
val2=[];
noerr=0;
if nargin>1
    for i=1:length(varargin);
        switch lower(varargin{i})
            case 'id'
                val = cat(1,b.id);
            case 'ixa'
                val = cat(1,b.ixa);
            case 'ixb'
                val = cat(1,b.ixb);
            case 'phasea'
                val=cell(length(b),1);
                [val{:}]=deal(b.phasea);
            case 'phaseb'
                val=cell(length(b),1);
                [val{:}]=deal(b.phaseb);
            case {'type','phase'}
                val=cell(length(b),1);
                [val{:}]=deal(b.type);
            case 'x'
                if n == 1
                    val = b.x;
                else
                    error('This property is valid only for single boundary object.')
                end
            case 'y'
                if n == 1
                    val = b.y;
                else
                    error('This property is valid only for single boundary object.')
                end
            case {'xcentre','xc'}
                for ii=1:n
                    val(ii) = (max(b(ii).x) + min(b(ii).x))/2;
                end
                val=val(:);
            case {'ycentre','yc'}
                for ii=1:n
                    val(ii) = (max(b(ii).y) + min(b(ii).y))/2;
                end
                val=val(:);
            case 'cumlength'
                val = cat(1,b.cumlength);
            case {'length','la'}
                val = cat(1,b.length);
            case {'loglength'}
                val = log10(cat(1,b.length));
            case {'width','sa'}
                val = cat(1,b.width);
            case {'axialratio','ar'}
                val = cat(1,b.width)./cat(1,b.length);
                val(val<1e-10)=NaN;
                val=1./val;
            case {'logaxialratio','logar'}
                val = cat(1,b.width)./cat(1,b.length);
                val(val<1e-10)=NaN;
                val=log10(1./val);
            case {'invaxialratio','iar'}
                val = cat(1,b.width)./cat(1,b.length);
            case {'orientation','lao'}
                val = cat(1,b.orientation);
            case 'sao'
                val = mod(cat(1,b.orientation)+90,180);
            case 'straightness'
                val = cat(1,b.cumlength)./cat(1,b.length);
            case 'logstraightness'
                val = log10(cat(1,b.cumlength)./cat(1,b.length));
            case 'userdata'
                if nargin>i+1 && any(strcmp(varargin{i+1},fieldnames(b(1).userdata)))
                    if isnumeric(b(1).userdata.(varargin{i+1}))
                        for ii=1:length(b)
                            val(ii,:) = b(ii).userdata.(varargin{i+1});
                        end
                    else
                        for ii=1:length(b)
                            val{ii,:} = b(ii).userdata.(varargin{i+1});
                        end
                    end
                    noerr=1;
                else
                    if i>1||nargin>2
                        error('UserData cannot be collated.');
                    else
                        for ii=1:length(b)
                            val(ii) = b(ii).userdata;
                        end
                        if isempty(fieldnames(val))
                            val=struct([]);
                        end
                    end
                end
            case 'xhex'
                if n == 1
                    val = reshape(dec2hex(typecast(b.x,'uint8')),1,[]);
                else
                    error('This property is valid only for single grain object.')
                end
            case 'yhex'
                if n == 1
                    val = reshape(dec2hex(typecast(b.y,'uint8')),1,[]);
                else
                    error('This property is valid only for single grain object.')
                end
            case 'wkt'
                if n == 1
                    val='LINESTRING(';
                    co=sprintf('%.8f %.8f,',[b.x b.y]');
                    val=[val co(1:end-1)];
                    val=[val ')'];
                else
                    error('This property is valid only for single grain object.')
                end
            otherwise
                if ~noerr
                    error([varargin{i},' is not valid boundary property']);
                else
                    val=[];
                    noerr=0;
                end
        end
        try
            val2=[val2 val];
        catch
            error('Not allowed combination of properties.');
        end
    end
    if nargout==size(val2,2)
        for i=1:nargout
            varargout{i}=val2(:,i);
        end
    else
        varargout{1}=val2;
    end
else
    if nargout>0
        varargout{1}={'ID','IXA','IXB','PhaseA','PhaseB','Type','XCentre','YCentre','CumLength','Length','LogLength','Width','Orientation','SAO','AxialRatio','LogAxialRatio','InvAxialRatio','Straightness','LogStraightness','UserData'};
    else
        disp('Available boundary properties are:');
        disp('  ID');
        disp('  IXA');
        disp('  IXB');
        disp('  PhaseA');
        disp('  PhaseB');
        disp('  Type');
        disp('  X (for single boundary only)');
        disp('  Y (for single boundary only)');
        disp('  XCentre/XC');
        disp('  YCentre/YC');
        disp('  CumLength');
        disp('  Length/LA');
        disp('  LogLength - log10 of length');
        disp('  Width/SA');
        disp('  Orientation/LAO');
        disp('  SAO');
        disp('  AxialRatio/AR');
        disp('  LogAxialRatio/LOGAR - log10 of axial ratio');
        disp('  InvAxialRatio/IAR - inverse of axial ratio');
        disp('  Straightness');
        disp('  LogStraightness - log10 of straightness');
        disp('  UserData');
        disp('  WKT - Well-known text representation (for single grain only)');
    end
end
