function plot(b,varargin)
%PLOT Plot boundary objects b on active figure
%Syntax: plot(b,options);
% options are passed as pairs of option name and option value:
%  'outlines' ... 0.. normal plot 1.. single color plot. Default 0.
%  'leg'      ... nonzero show legend. Defaut 1.
%  'vertex'   ... nonzero plot vertices. Default 0.
%  'pal'      ... colortable (GENCT) or pallete (MAKEPAL Default)
%  'color'    ... color of outlines. Default 'k'.
%  'width'    ... width boundaries. Default 1.
%  'box'      ... 4x2 matrix plot bounding box (see ELLEREAD) Default 0.

% This file is part of polyLX.
% 
% polyLX is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% polyLX is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with polyLX.  If not, see <http://www.gnu.org/licenses/>.

% polyLX - MATLAB toolbox for microstructure analyses
% Copyright (C) 2010 Ondrej Lexa

% Process input arguments
opts.outlines=0;
opts.leg=1;
opts.vertex=0;
opts.pal=makepal(b);
opts.color='k';
opts.width=1;
opts.box=0;
opts=parseargs(varargin,opts);

poc=length(b);

%Check colortable
if size(opts.pal,2)==2
    pal=[repmat({[0]},poc,1) repmat({''},poc,1) repmat({[0 0 0]},poc,1)];
    for ii=1:size(opts.pal,1)
        ix=gpsel(g,opts.pal{ii,1});
        if ~isempty(ix)
            pal(ix,1)={ii};
            pal(ix,2)={[opts.pal{ii,1} ' (' num2str(length(ix)) ')']};
            pal(ix,3)={opts.pal{ii,2}};
        end
    end
    opts.pal=pal;
end

%Check pallete
if ~all(size(opts.pal)==[poc 3])==iscell(opts.pal)
    error('Palette is not compatible with passed boundary objects! Use makepal.');
end
% Clear figure when not holded
if ~ishold
    clf
end
set(gca,'Box','on','TickDir','out','XminorTick','on','YminorTick','on');
if ~opts.outlines
    htlist=[];
    plist=[];
    zoz=unique(opts.pal(:,2));
    for i=1:length(zoz)
        if ~isempty(zoz{i})
            ix=find(strcmp(zoz{i},opts.pal(:,2)));
            if ~isempty(ix)
                cx=[];
                cy=[];
                for m=1:length(ix)
                    cx=[cx;NaN;get(b(ix(m)),'x')];
                    cy=[cy;NaN;get(b(ix(m)),'y')];
                end
                ht=line(cx(2:end),cy(2:end),'Color',opts.pal{ix(1),3},'LineWidth',opts.width);
                if opts.vertex
                    set(ht,'Marker','.')
                end
                htlist=[htlist;ht];
                plist = [plist;ix(1)]; 
            end
        end
    end
else
    for i=1:poc
        [x,y]=get(b(i),'x','y');
        line(x,y,'Color',opts.color,'LineWidth',opts.width);
    end
end
axis equal
axis tight
ax=axis;
dax=diff(ax);
axis([ax(1)-dax(1)/100 ax(2)+dax(1)/100 ax(3)-dax(3)/100 ax(4)+dax(3)/100]);

% Show legend
if opts.leg && ~opts.outlines
    [dummy,ix]=sort(cat(1,opts.pal{plist,1}));
    h=legend(htlist(ix),opts.pal(plist,2));
    set(h,'FontSize',8);
end

% Plot boundaing box from elle files
if all(size(opts.box)==[4 2])
    bb=[opts.box;opts.box(1,:)];
    line(bb(:,1),bb(:,2),'Color','k');
end
