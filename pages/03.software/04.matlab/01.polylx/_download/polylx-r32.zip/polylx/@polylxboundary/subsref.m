function b = subsref(a,s)
%SUBSREF Control polylxboundary class indexing

% This file is part of polyLX.
% 
% polyLX is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% polyLX is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with polyLX.  If not, see <http://www.gnu.org/licenses/>.

% polyLX - MATLAB toolbox for microstructure analyses
% Copyright (C) 2010 Ondrej Lexa

for ii=1:size(s.subs,2)
    switch s.type
        case '()'
            if ischar(s.subs{ii})
                a=a(btsel(a,s.subs{ii}));
            elseif iscell(s.subs{ii})
                a=a(unique(cell2mat(s.subs{ii})));
            else
                a=a(s.subs{ii});
            end
        otherwise
            error('Use type name as index as g(''amp-plg'')')
    end
end
b=a;
