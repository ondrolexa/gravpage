function [c,nv,vf,mn,st,gmn,ed]=astrip(g,varargin)
%ASTRIP Determine a 3D sphere diameter distribution from 2d grainsize.
% Syntax: [c,nv,vf,mn,st,gmn]=astrip(g,options);
% g is grain object(s)
% options are passed as pairs of option name and option value:
% 'nbins'  ... number of bins.
% 'bins'   ... vector of bin edges for calculation
% 'dist'   ... 0 ... normal 1... lognormal Default 0.
% 'prop'   ... grain property used as measure. Default 'ead'
% 'scale'  ... 0...counts/volume 1...percents. Default 1.
% return c-centres of bins, nv-3d frequencies, vf-volume fractions
% mn-mean, st-standart deviation and gmn-logmean

% This file is part of polyLX.
% 
% polyLX is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% polyLX is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with polyLX.  If not, see <http://www.gnu.org/licenses/>.

% polyLX - MATLAB toolbox for microstructure analyses
% Copyright (C) 2010 Ondrej Lexa

if ~isa(g,'polylxgrain')
    help astrip
    return
end

% Process input arguments
opts.nbins=ceil(1+3*log10(length(g)));
opts.bins=0;
opts.prop='ead';
opts.scale=1;
opts.dist=0;
opts=parseargs(varargin,opts);

f=get(g,opts.prop);

if opts.bins==0
    if opts.dist==0
        ed=linspace(min(f),max(f),opts.nbins+1);
    else
        ed=logspace(log10(min(f)),log10(max(f)),opts.nbins+1);
    end
else
    ed=opts.bins(:)';
    opts.nbins=length(opts.bins)-1;
end

if opts.dist==0
    ded=diff(ed);
    c=cumsum([ed(1)+ded(1)/2 ded(2:end)])';
else
    ded=diff(log(ed));
    c=exp(cumsum([log(ed(1))+ded(1)/2 ded(2:end)])');
end

n=histc(f,ed);
n(end-1)=n(end-1)+n(end);
n(end)=0;
na=n(1:end-1);
V=zeros(opts.nbins);
for i=1:opts.nbins
    for j=i:opts.nbins
        V(i,j)=(sqrt(j^2-(i-1)^2)-sqrt(j^2-i^2))/j;
    end
end

% make it work correctly - Ruediger Kilian
for i=1:nbins
    V(:,i)= V(:,i)/nbins*i;
end

nv=inv(V)*na;
vf=2/3*pi*c.^3.*nv;
if opts.scale==1
    nv=100*nv/sum(nv);
    vf=100*vf/sum(vf);
    if opts.dist==0
        bar(c,[nv vf],1,'grouped');
        xlabel(opts.prop);
    else
        bar(log10(c),[nv vf],1,'grouped');
        xlabel(['Log10(' opts.prop ')'])
    end
    ylabel('Percents');
    legend({'3D diameter','Volume fraction'});
else
    if opts.dist==0
        bar(c,nv,1);
        xlabel(opts.prop);
    else
        bar(log10(c),nv,1);
        xlabel(['Log10(' opts.prop ')'])
    end
    ylabel('Counts');
    legend('3D diameter');
end

mn=(c'*nv)/sum(nv);
gmn=exp((log(nv)'*nv)/sum(nv));
st=sqrt(((c-mean(c)).^2)'*nv/sum(nv));
