function [c,inca,phase,med,tin,err,cp,back,mask,fnm,d,dn,eup,sup]=cipmake(varargin)
%CIPMAKE Create CIP data from input.
% Syntax: c=cipmake;
%         c=cipmake(options);
% [c,inca,phase,med,tin,err,cp,back,mask,fnm] = cipmake(options);
% options are passed as pairs of option name and option value:
% 'file'      ... full filename of one of datafile. Default ask for file
% 'size'      ... size of input images [width heigth]. Default as for it.
% 'calcerr'   ... 1 - calculate err(slower). Default 0
% 'bgcirpol'  ... 1 - cirpol background correction 0 - no. Default 1
% 'bgrot'     ... 1 - input data background correction 0 - no. Default 1
% 'meancorr'  ... 1 - use mean correction for Tindex 0 - no. Default 1
% 'tindex'    ... 0 - use raw slice. 1 - use fitted slice. Default 0
% 'writefit'  ... 1 - write fitted slices to raw(slower). Default 0
% 'outputdir' ... Directory to write fitted raw files. Default 'fitted'
% 'cutoff'    ... Cutoff percentils from inca.
%                 Negative values are interpreted as absolute values
%                 for cutoff. When zero, values could be manually selected
%                 on histogram. Default [1 99]
% 'precision' ... 'uint8' or 'uint16'. Default 'uint8'

% This file is part of polyLX.
% 
% polyLX is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% polyLX is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with polyLX.  If not, see <http://www.gnu.org/licenses/>.

% polyLX - MATLAB toolbox for microstructure analyses
% Copyright (C) 2010 Ondrej Lexa

% Process input arguments
opts.file='';
opts.size=[];
opts.calcerr=0;
opts.tindex=0;
opts.bgcirpol=1;
opts.bgrot=1;
opts.meancorr=1;
opts.writefit=0;
opts.outputdir='fitted';
opts.cutoff=[1 99];
opts.precision='uint8';
opts=parseargs(varargin,opts); 

if isempty(opts.file)
    [file, pathname] = uigetfile({'*.000','CIP pictures (*.000)';'*.*',  'All Files (*.*)'},'Pick a CIP file');
    if file==0
        c=[];
        return
    end
    [dummy,fnm,dummy]=fileparts(file);
else
    if exist(opts.file,'file')
        [pathname,fnm,dummy]=fileparts(opts.file);
    else
        error(['File ' opts.file ' does not exists'])
    end
end

%Ask for size
if isempty(opts.size)
    if exist(fullfile(pathname,[fnm '.size']),'file')
        fid=fopen(fullfile(pathname,[fnm '.size']),'r');
        sz=fscanf(fid,'%d',2);
        fclose(fid);
        iw=sz(1);
        ih=sz(2);
    else
        sz=inputdlg({'Width:','Heigth:'},'Image size:',1,{'1200','1000'});
        iw=str2double(sz{1});
        ih=str2double(sz{2});
        fid=fopen(fullfile(pathname,[fnm '.size']),'w');
        fprintf(fid,'%d\n',[iw ih]);
        fclose(fid);
    end
else
    iw=opts.size(1);
    ih=opts.size(2);
end

%Read background
fid=fopen(fullfile(pathname,[fnm '.back']),'rb');
im1=fread(fid,opts.precision);
if strcmpi(opts.precision,'uint16')
    im1=im1/256;
end

back=reshape(im1(1:iw*ih),iw,ih)';
back=back-mean(back(:));
fclose(fid);

% Read rotated images
for i=1:19
    fid=fopen(fullfile(pathname,[fnm num2str((i-1)*10,'.%03d')]),'rb');
    im1=fread(fid,opts.precision);
    if strcmpi(opts.precision,'uint16')
        im1=im1/256;
    end
    dd=reshape(im1(1:iw*ih),iw,ih)';
    if opts.bgrot
        dd=dd-back;
        %dd(dd<0)=0;
    end
    d(:,:,i)=dd;
    fclose(fid);
end

%prepare data storage
inca=zeros(ih,iw);
phase=zeros(ih,iw);
med=zeros(ih,iw);
err=zeros(ih,iw);
if opts.writefit||opts.tindex
    dn=zeros(size(d));
end

x=[0:10:180]';
x1=cosd(2*x);
x2=sind(2*x);

h=waitbar(0,'Please wait...','Name','Calculating...');
for r=1:ih
    for c=1:iw
        v=d(r,c,:);
        v=v(:);        
        m=[ones(size(x1)) x1 x2]\v;
        inca(r,c)=sqrt(m(2)^2+m(3)^2);
        phase(r,c)=atan2(m(2),m(3))*180/pi;
        med(r,c)=m(1);
        if opts.calcerr||opts.tindex||opts.writefit
            nv=m(1)+sqrt(m(2)^2+m(3)^2)*sind(2*x+atan2(m(2),m(3))*180/pi);
            err(r,c)=sum((v-nv).^2);
        end
        if opts.writefit||opts.tindex
            dn(r,c,:)=nv;
        end
    end
    waitbar(r/ih,h);
end
close(h)

%Write fitted slices
if opts.writefit
    mkdir(fullfile(pathname,'..',opts.outputdir))
    for i=1:19
        fid=fopen(fullfile(pathname,'..',opts.outputdir,[fnm num2str((i-1)*10,'.%03d')]),'wb');
        if strcmpi(opts.precision,'uint16')
            fwrite(fid,256*dn(:,:,i)',opts.precision);
        else
            fwrite(fid,dn(:,:,i)',opts.precision);
        end
        fclose(fid);
    end
end

azi=(180-phase)/2;
%Read cirpol
fid=fopen(fullfile(pathname,[fnm '.cirpol']),'rb');
im1=fread(fid,opts.precision);
if strcmpi(opts.precision,'uint16')
    im1=im1/256;
end
cp=reshape(im1(1:iw*ih),iw,ih)';
fclose(fid);

%correct cirpol for background
if opts.bgcirpol
    cp=cp-back;
    %cp=cp-back+max(back(:));
    %cp(cp<0)=0;
end

%Read mask
if exist(fullfile(pathname,[fnm '.mask']),'file')
    fid=fopen(fullfile(pathname,[fnm '.mask']),'rb');
    im1=fread(fid,opts.precision);
    if strcmpi(opts.precision,'uint16')
        im1=im1/256;
    end
    mask=reshape(im1(1:iw*ih),iw,ih)'>0;
    fclose(fid);
else
    mask=true(size(inca));
end

% %Stretch inca
% if length(opts.cutoff)==2
%     if opts.cutoff(1)<0
%         lbound=-opts.cutoff(1);
%     else
%         lbound=percentil(inca(mask),opts.cutoff(1));
%     end
%     if opts.cutoff(2)<0
%         ubound=-opts.cutoff(2);
%     else
%         ubound=percentil(inca(mask),opts.cutoff(2));
%     end
% else
%     f=figure;
%     hist(inca(mask),180)
%     title('Click lower bound and upper bound for stretch')
%     [x,y]=ginput(2);
%     lbound=min(x);
%     ubound=max(x);
%     close(f)
% end
% fprintf('INCA cut off %.0f - %.0f\n',lbound,ubound);
% lcut=inca<lbound;
% inca(lcut)=2*lbound-inca(lcut);
% ucut=inca>ubound;
% inca(ucut)=2*ubound-inca(ucut);
% inca=(inca-lbound)*90/(ubound-lbound);

%Calculate Tindex
fid=fopen(fullfile(pathname,[fnm '.sup']),'rb');
im1=fread(fid,opts.precision);
if strcmpi(opts.precision,'uint16')
    im1=im1/256;
end
sup=reshape(im1(1:iw*ih),iw,ih)';
fclose(fid);
fid=fopen(fullfile(pathname,[fnm '.eup']),'rb');
im1=fread(fid,opts.precision);
if strcmpi(opts.precision,'uint16')
    im1=im1/256;
end
eup=reshape(im1(1:iw*ih),iw,ih)';
fclose(fid);
%Background correction
if opts.bgrot
    sup=sup-back;
    sup(sup<0)=0;
    eup=eup-back;
    eup(eup<0)=0;
end

if opts.tindex
    dd=dn(:,:,19);
else
    dd=d(:,:,19);
end

%Mean correction
if opts.meancorr
    mdd=mean(dd(:));
    meup=mean(eup(:));
    msup=mean(sup(:));
    mn=mean([mdd meup msup]);
    dd=dd-mdd+mn;
    eup=eup-meup+mn;
    sup=sup-msup+mn;
end

%Calculate Tindex
tin=(eup<dd&azi<45)|(eup>dd&azi>135)|(azi>45&azi<135&sup>dd);

%Correct azi and incp
inca2=inca;
inca2(~tin)=180-inca2(~tin);
%incp(tin)=180-incp(tin); %Check it
inca2 = inca2-90;
azi2=azi;
azi2(inca2<0) = azi2(inca2<0)+180;
inca2 = abs(inca2);
%Create cipdata
c=cipdata(azi2,inca2,mask,fnm);

function c=smoothlut(y)
% Moving average filter
width=5;
n=length(y);
c = filter(ones(width,1)/width,1,y);
cb = cumsum(y(1:width-2));
cb = cb(1:2:end)./(1:2:(width-2))';
ce = cumsum(y(n:-1:n-width+3));
ce = ce(end:-2:1)./(width-2:-2:1)';
c = [cb;c(width:end);ce];

% c1=smoothlut(aa);
% c2=smoothlut(tt);
% lb=61;
% ub=242;
% cp0=cp;
% cp0(~mask)=NaN;
% ix=cp0<lb;
% cp0(ix)=2*lb-cp0(ix);
% ix=cp0>ub;
% cp0(ix)=2*ub-cp0(ix);
% cp0=(cp0-lb)*255/(ub-lb);
% cp1=interp1(255-x,c1,cp0);
% cp2=interp1(x,90-c2,cp1);
% subplot(2,1,1)
% hist(ci(:),128)
% a=axis;
% subplot(2,1,2)
% hist(cp2(:),128)
% axis(a)