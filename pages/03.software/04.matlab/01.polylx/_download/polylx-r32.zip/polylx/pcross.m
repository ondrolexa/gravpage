function h=pcross(ra,rb,ang,co0,C,s)
%PCROSS Adds axes of ellipses to the current plot.
%
% PCROSS(ra,rb,ang,co0) or PCROSS(g) adds an axes of ellipse with semimajor axis of ra,
% a semimajor axis of radius rb, a semimajor axis of ang, centered at
% the point co0=[x0,y0].
%
% PCROSS(ra,rb,ang,co0,C) or PCROSS(g,C)
% adds axes of ellipses of color C. C may be a string ('r','b',...) or the RGB value.
% If no color is specified, it makes automatic use of the colors specified by
% the axes ColorOrder property. For several circles C may be a vector.
%
% PCROSS(ra,rb,ang,co0,C,s) or PCROSS(g,C,s)
% s specifies the scale of drawn cross. The default value is 0.5. s may be used
% for each axes of ellipse individually.

% This file is part of polyLX.
% 
% polyLX is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% polyLX is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with polyLX.  If not, see <http://www.gnu.org/licenses/>.

% polyLX - MATLAB toolbox for microstructure analyses
% Copyright (C) 2010 Ondrej Lexa

% Check the number of input arguments
if nargin<1
    ra=[];
end;
if nargin<2
    rb=[];
end;
if nargin<3
    ang=[];
end;

if nargin<4
    co0=[];
end;

if nargin<5
    C=[];
end

if nargin<6
    s=[];
end

% when grain object is passed
if isa(ra,'polylxgrain')||isa(ra,'polylxboundary')
    g=ra;
    C=rb;
    s=ang;
    ra=get(g,'Length')/2;
    rb=get(g,'Width')/2;
    ang=get(g,'Orientation');
    co0=[get(g,'xcentre') get(g,'ycentre')];
elseif isa(ra,'struct')
    g=ra;
    C=rb;
    s=ang;
    ra=[g.la]'/2;
    rb=[g.sa]'/2;
    ang=[g.lao];
    co0=[g.xcentre;g.ycentre]';
end

% set up the default values
if isempty(ra),ra=1;end;
if isempty(rb),rb=1;end;
if isempty(ang),ang=0;end;
if isempty(co0),co0=[0 0];end;
if isempty(s),s=0.5;end;
if isempty(C),C=get(gca,'colororder');end;

% work on the variable sizes
x0=co0(:,1);
y0=co0(:,2);
ra=ra(:);
rb=rb(:);
ang=ang(:);
s=s(:);

if ischar(C)
    C=C(:);
end;

if length(ra)~=length(rb),
  error('length(ra)~=length(rb)');
end;
if length(x0)~=length(y0),
  error('length(x0)~=length(y0)');
end;

% how many inscribed elllipses are plotted
if length(ra)~=length(x0)
  maxk=length(ra)*length(x0);
else
  maxk=length(ra);
end;

% drawing loop
for k=1:maxk
  if length(x0)==1
    xpos=x0;
    ypos=y0;
    radm=ra(k);
    radn=rb(k);
    if length(ang)==1
      an=ang;
    else
      an=ang(k);
    end;
  elseif length(ra)==1
    xpos=x0(k);
    ypos=y0(k);
    radm=ra;
    radn=rb;
    an=ang;
  elseif length(x0)==length(ra)
    xpos=x0(k);
    ypos=y0(k);
    radm=ra(k);
    radn=rb(k);
    an=ang(k);
  else
    radm=ra(fix((k-1)/size(x0,1))+1);
    radn=rb(fix((k-1)/size(x0,1))+1);
    an=ang(fix((k-1)/size(x0,1))+1);
    xpos=x0(rem(k-1,size(x0,1))+1);
    ypos=y0(rem(k-1,size(y0,1))+1);
  end;

  hh(k,1)=line([xpos+s*radm*sind(an);xpos+s*radm*sind(an+180)],[ypos+s*radm*cosd(an);ypos+s*radm*cosd(an+180)],'color',C(rem(k-1,size(C,1))+1,:));
  hh(k,2)=line([xpos+s*radn*sind(an+90);xpos+s*radn*sind(an-90)],[ypos+s*radn*cosd(an+90);ypos+s*radn*cosd(an-90)],'color',C(rem(k-1,size(C,1))+1,:));

end;

axis equal

if nargout>0
    h=hh;
end