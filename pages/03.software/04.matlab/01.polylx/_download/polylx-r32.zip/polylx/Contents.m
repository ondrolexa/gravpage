% PolyLX Toolbox Release 3.2
% Version 3.2.2 09-May-2017
%
% Grain/boundary manipulation commands
%   polylxgrain/polylxgrain        - Create grain object.
%   polylxgrain/plot               - Plot grains.
%   polylxgrain/gplist             - Return unique list (cell array) of phases of objects g.
%   polylxgrain/gpsel              - Grain phase select. Return indexes into objects array with phase(s) ph.
%   polylxgrain/get                - Get properties of grain objects.
%   polylxgrain/set                - Set properties of grain objects.
%   polylxboundary/polylxboundary  - Create boundary object.
%   polylxboundary/plot            - Plot boundaries.
%   polylxboundary/btlist          - Return unique list (cell array) of types of boundary objects.
%   polylxboundary/btsel           - Boundary type select. Return object index vector.
%   polylxboundary/get             - Get properties of boundary objects.
%   bmake           - Routine to construct boundaries (boundary objects) from grain objects.
%   bsmake          - Routine to construct boundaries segments objects from grain or boundary objects.
%   gconvhull       - Transform each grain into grain defined by convex hull of original grain.
%   gcrop           - Crop subset of grain objects
%   gdissolve       - Dissolve shared boundaries between same phase grains.
%   genellipses     - Generate elliptical grains of given properties.
%   genssi          - Routine to generate anti-clustered circular grains.
%   gequal          - Transform grain objects to equivalent shapes.
%   getcm           - Return connectivity matrix
%   getsel          - Return indexes of actual selection or modify selection.
%   getincl         - Get index to grains inclusions.
%   getneigh        - Return indexes or cell array of indexes to adjacent grains.
%   getpclust       - Return index vector/cell array to interconnected phase cluster.
%   gnsearch        - Return grains of phase ph1 which share boundary with phase ph2.
%   gsmooth         - Smooth outlines of grain objects.
%   gtrans2d        - Transform grain objects using transformation matrix tm.
%   gtsmooth        - Topological smoothing of the grain objects.
%
% Analysis commands
%   acharea         - Calculate area, perimeter, centroid of convex hull and bounding box of grains or boundaries.
%   adiangle        - Return cell array of measurement of dihedral angles.
%   adtnnm          - The Delaunay triangulation nearest neighbor method to detemine the strain.
%   afract          - Return summary for proportions of grain phases/boundary types
%   anna            - Return index of nearest-neighbour statistics.
%   annm            - The nearest neighbour method to determine the orientation of strain ellipse and it's ellipticity.
%   aortentot       - Return results of covariance matrix eigenanalysis.
%   aparis          - Return PARIS function and factor after Panozzo&Hurlimann, 1983.
%   aparis2         - Return paris and area factors after Heilbronner&Keulen, 2006.
%   aquadrat        - Return results of quadrat analysis.
%   arfphi          - Estimation of strain ratio from rf/phi modelling.
%   arfphiw         - Estimation of weighted strain ratio from rf/phi modelling.
%   astrip          - Determine a 3D sphere diameter distribution from 2d grainsize.
%   cameth          - Direct Contact area method (Kretz 1969).
%   cfmeth          - Direct Contact frequency method (Kretz 1969).
%   clmeth          - Direct Contact length method (Kretz 1969).
%   describe        - Return descriptive statistics of chosen measurement.
%   getoutliers     - Rosner's many-outlier test for detection of outliers in data.
%   getpconn        - Return connectivity index for individual phases.
%   gferet          - Return length and orientation of maximum and maximum perpendicular Feret diameters
%   gfitel          - Stable Direct Least Squares Ellipse Fit to grains geometry.
%   gharfer         - Return ellipse fitting based on Harvey & Ferguson method
%   gminel          - Finds the minimum volume enclosing ellipse (MVEE) for grain or boundary
%   gorten          - Return results of Ellipse fitting using covariance matrix.
%   gorten2         - Return parameters of covariance matrix of decomposed grain/boundary.
%   gparor          - Return results of PAROR analysis after R.Panozzo.
%   gsurfor         - Return results of SURFOR analysis after R.Panozzo.
%
% Plotting commands
%   genct           - Generate color table for grain/boundary objects based on phase/type.
%   makepal         - Routine to generate universal color palette for plot.
%   paniso          - Plot phase spatial distribution anisotropy plot
%   paxdev          - Plot histogram of projection axes deviation from orthogonality.
%   peigen          - Plot bulk eigenvalues ratio vs. choosen property of grains/boundaries.
%   pellipse        - Plot ellipses to the current plot.
%   pboxplot        - Routine to plot boxplot of measuremnts of individual phases/types.
%   pcross          - Adds axes of ellipses to the current plot.
%   pcsd            - Routine to plot CSD diagram after Peterson,1996.
%   pcum            - Plot cumulative plot of histogram.
%   pdianglehist    - Plot histogram of chosen dihedral angles.
%   pdistplot       - Plot normal or lognormal probability plot.
%   pfry            - Make Fry's plot to detemine the strain ellipse.
%   pgsize          - Routine to plot grain size (EAD/feret) histogram with area fraction histogram.
%   phist           - Plot histogram and calculate statistics.
%   phistlog        - Plot histogram, lognormal distibution fit and calculate statistics.
%   phistnorm       - Plot histogram, normal distibution fit and calculate statistics.
%   phistw          - Plot weighted histogram.
%   poneboxplot     - Routine to plot box-and-whisker plot of data on given x position.
%   pproj           - Plot projection function of PAROR, SURFOR and PARIS analyses.
%   prfphi          - Make Rf/phi plot.
%   prose           - Draw a rose diagram and calculate circular statistics.
%   prosew          - Draw a weighted rose diagram and calculate circular statistics.
%   xyplot          - Scatter plot with fitted linear regression.
%
% Import/Export and file management commands
%   csdwrite        - Write CSD file for analysis with CSDCorrection of M. Higgins.
%   digread         - Read DIG file into PolyLX
%   dump            - Dump grain/boundary properties to cell array.
%   dxfread         - Read grain geometry from ASCII Drawing Interchange (DXF) Files R12.
%   elleread        - Read grain geometry and attributes from ELLE inputfile.
%   jmlread         - Read grain geometry from JUMP GML file.
%   jmlwrite        - Write geometry to JUMP GML file.
%   mkflist         - Make list (cell array) of chosen files for batch processing.
%   mtexread        - Read grains from M-TEX grains object.
%   roiread         - Read grain geometry from ImageJ ROI files.
%   shp2db          - Routine to export several shapefiles into database.
%   shp2mat         - Routine to convert several shapefiles into MAT-files for fast loading.
%   shpread         - Read grain/boundary geometry from ArcView shapefile.
%   svgwrite        - Write SVG (Scalable Vector Graphics) file suitable for web.
%   sxmread         - Read grain geometry from Image SXM XY coordinates file.
%   txtwrite        - Write ASCII delimited file with column headers.
%
% CIP data manipulation
%   cipdata/cipdata     - Create cipdata object.
%   cipdata/contour     - Plot contour plot of cipdata.
%   cipdata/filter      - Apply filter on cipdata.
%   cipdata/get         - Get cipdata properties.
%   cipdata/graindata   - Return grain integrated azimuth and inclination data.
%   cipdata/grainfilter - Return grains with well developed CIP maxima.
%   cipgrainmap         - Plot grain orientation map
%   cipdata/grainmask   - Return mask of selected grains.
%   cipdata/length      - Return number of valid data.
%   cipdata/plot        - Plot cip data maps.
%   cipdata/rotate      - Rotate cipdata.
%   cipread             - Read cipdata.
%   cipread2            - Read cipdata in TIFF format.
%   cipmake             - Create CIP data from input.
%   cipmerge            - Merge cipdata object.
%   azidip2color        - Return RGB grid from azimuth and dip grid
%   schmidtgrid         - Return arrays and rgp to plot schmidtnet lookup table
%
% Database manipulation commands
%   dbcreate        - Create empty PolyLX database.
%   dbdelete        - Delete sample(s) in database.
%   dblist          - Show informations about stored data in database.
%   dbread          - Read a grain geometry from database.
%   dbreadphase     - Read all grains of choosen phase from database.
%   dbreadtype      - Read all boundaries of choosen type from MySQL database.
%   dbselect        - Select samples and their attributes from database.
%   dbwrite         - Write grain object into database.
%
% Other commands
%   polylxcheck     - Check and report polyLX settings
%   polylxdemodata  - Load sample grain and boundary data
%   polylxgui       - Simple GUI to explore basic characteristics and produce simple graphics.
%   polylxupdate    - Update PolyLX from web to the latest version
%
% Copyright (c) 2000-2013 Ondrej Lexa (lexa@natur.cuni.cz)
% Institute of Petrology and Structural Geology, Charles University,
% Prague, Czech Republic
