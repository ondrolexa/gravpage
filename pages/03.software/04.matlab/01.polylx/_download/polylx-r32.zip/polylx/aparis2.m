function [pf,deltA]=aparis2(g,opt)
%APARIS2 Return paris and area factors after Heilbronner&Keulen, 2006.
% Syntax: [pf,deltA]=aparis2(g,opt);
% g can be grain object(s).
%    opt - 0 (default) do not include holes into calculations
%          1 include holes into calculations
%     pf - paris factor
% deltaA - area factor

% This file is part of polyLX.
% 
% polyLX is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% polyLX is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with polyLX.  If not, see <http://www.gnu.org/licenses/>.

% polyLX - MATLAB toolbox for microstructure analyses
% Copyright (C) 2010 Ondrej Lexa

if nargin<1
    help aparis2
    pf=[];
    deltA=[];
    return
end
if ~isa(g,'polylxgrain')
    help aparis2
    pf=[];
    deltA=[];
    return
end

if nargin<2
 opt=0;
end

gc=gconvhull(g);

if bitget(opt,1)==1
    p=get(g,'perimeter');
    a=get(g,'area');
else
    p=get(g,'outperimeter');
    a=get(g,'outarea');    
end

pf=200*(p-get(gc,'perimeter'))./get(gc,'perimeter');
deltA=100*(get(gc,'area')-a)./a;

