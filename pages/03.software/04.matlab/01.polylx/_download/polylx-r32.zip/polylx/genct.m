function ct=genct(gb,mn)
%GENCT Generate color table for grain/boundary objects based on phase/type.
% Syntax: ct=genct(g,[opt])
%    g   - grain/boundary objects or cell array of legend entries
%    opt   - 0 automatically define colors (default). 1 manually define colors

% This file is part of polyLX.
% 
% polyLX is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% polyLX is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with polyLX.  If not, see <http://www.gnu.org/licenses/>.

% polyLX - MATLAB toolbox for microstructure analyses
% Copyright (C) 2010 Ondrej Lexa

if nargin<2
    mn=0;
end

switch class(gb)
    case 'polylxgrain'
        %Color table for grains
        ph=gplist(gb);
    case 'polylxboundary'
        %Color table for boundaries
        ph=btlist(gb);
    case 'cell'
        %Color table with defined entries
        ph=gb;
    otherwise
        help genct
        return
end

pf=length(ph);
% set colours
cmap=jet(pf);
if mn==1
    for ii=1:pf
        ac=uisetcolor(cmap(ii,:),['Define color for ' ph{ii}]);
        if length(ac)==3
            cmap(ii,:)=ac;
        end
    end
end
for ii=1:pf
    ct(ii,1)=ph(ii);
    ct(ii,2)={cmap(ii,:)};
end
