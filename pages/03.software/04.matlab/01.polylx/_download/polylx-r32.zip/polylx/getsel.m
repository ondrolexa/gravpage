function ix=getsel(obj)
%GETSEL Return indexes of actual selection or modify selection.
% GETSEL CLEAR clear selection.
% GETSEL INVERT invert selection.

% Internal callback from ButtonDownFcn event to select or unselect grain

% This file is part of polyLX.
% 
% polyLX is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% polyLX is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with polyLX.  If not, see <http://www.gnu.org/licenses/>.

% polyLX - MATLAB toolbox for microstructure analyses
% Copyright (C) 2010 Ondrej Lexa

if nargin < 1, obj = gcbo; end
if nargout > 0, ix=[]; end

% Clear selection
if strcmpi(obj,'clear')
    if ~isempty(get(0,'CurrentFigure'))
        h=findobj(gca,'Type','patch','Selected','on','Tag','grain');
        if ~isempty(h)
            c=get(h,'UserData');
            if size(c,1)>1
                cc=cat(1,c{:});
            else
                cc=c;
            end
            set(h,'Selected','off')
            set(h,{'FaceColor'},num2cell(cc(:,4:6),2));
        end
    end
    return
end

% invert selection
if strcmpi(obj,'invert')
    if ~isempty(get(0,'CurrentFigure'))
        h=findobj(gca,'Type','patch','Tag','grain');
        for i=1:length(h)
            switch get(h(i), 'Selected')
                case 'on'
                    set(h(i),'Selected','off')
                    c=get(h(i),'UserData');
                    set(h(i),'FaceColor',c(4:6))
                otherwise
                    set(h(i),'Selected','on')
                    c=get(h(i),'UserData');
                    cc=get(h(i),'FaceColor');
                    c(4:6)=cc;
                    set(h(i),'UserData',c)
                    set(h(i),'FaceColor',[0.5 0.5 0.5])
            end
        end
    end
    return
end

% return ID's
if ~strcmp(get(obj,'Type'),'patch')
    if ~isempty(get(0,'CurrentFigure'))
        h=findobj(gca,'Type','patch','Selected','on','Tag','grain');
        if ~isempty(h)
            c=get(h,'UserData');
            if size(c,1)>1
                cc=cat(1,c{:});
                ix=sort(cc(:,1));
            else
                ix=c(1);
            end
        end
    end
    return
end

% do callback
switch get(obj, 'Type')
    case 'patch'
        switch get(obj, 'Selected')
            case 'on'
                set(obj,'Selected','off')
                c=get(obj,'UserData');
                set(obj,'FaceColor',c(4:6))
            otherwise
                set(obj,'Selected','on')
                c=get(obj,'UserData');
                cc=get(obj,'FaceColor');
                c(4:6)=cc;
                set(obj,'UserData',c)
                set(obj,'FaceColor',[0.5 0.5 0.5])
        end
    otherwise
        return
end
