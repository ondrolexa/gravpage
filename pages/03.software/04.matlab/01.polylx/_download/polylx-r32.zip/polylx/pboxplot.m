function pboxplot(g,varargin)
%PBOXPLOT Routine to plot boxplot of measuremnts of individual phases/types.
% The bottom and top of the box are the 25th and 75th  percentile
% (the lower Q1 and upper Q3 quartiles, respectively), and the band near
% the middle of the box is the 50th percentile (the median).
% The ends of the whiskers represent the 2nd and the 98th percentile.
% Datarange and outliers are also plotted.
% Syntax: pboxplot(g,[prop]);
%         pboxplot(data,labels);
% g is grain/boundary objects
% data and labels are cell objects

% This file is part of polyLX.
% 
% polyLX is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% polyLX is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with polyLX.  If not, see <http://www.gnu.org/licenses/>.

% polyLX - MATLAB toolbox for microstructure analyses
% Copyright (C) 2010 Ondrej Lexa

if nargin<1
   help pboxplot
   return
end

valid=1;
xlbl='Data position';
ylbl='Value';

if isa(g,'polylxgrain') || isa(g,'polylxboundary')
    if nargin<2
        tlist=get(g);
        [typa,valid]=listdlg('PromptString','Select measurement:','SelectionMode','Single','ListString',tlist);
    else
        typa=1;
        tlist=varargin;
    end
    if isa(g,'polylxgrain')
        ph=gplist(g);
    else
        ph=btlist(g);
    end
    % padding data and prepare labels
    x={};
    labl=ph;
    for i=1:length(ph)
        x{i}=get(g(ph{i}),tlist{typa});
        labl{i}=[labl{i} ' (' num2str(length(x{i})) ')'];
    end
    if isa(g,'polylxgrain')
        xlbl='Phases';
    else
        xlbl='Types';
    end
    ylbl=tlist{typa};
elseif isa(g,'double')
    x={g(:)};
    labl=varargin{1};
elseif isa(g,'cell')
    x=g;
    labl=varargin{1};
else
    error('Wrong argument')
end
if valid~=1
   disp ('Aborted.')
   return
end

if isempty(labl)
    for i=1:length(g)
        labl{i}=num2str(i);
    end
end

newplot;
boxplt(x,labl);
ylabel(ylbl);
xlabel(xlbl)
if length(x)>10
    xticklabel_rotate;
end

function boxplt(data,labl)
%BOXPLOT Routine to plot boxplot of data.

% Ondrej Lexa 2001

ndata = length(data);

if ndata == 1
   [t,b] = poneboxplot(data{1}, 1, 'halfwidth', 0.4);
   axis([0 2 b-.05*(t-b) t+.05*(t-b)])
else
   tt = -1e100;
   bb =  1e100;
   for k=1:ndata
      [t,b] = poneboxplot(data{k}, k, 'halfwidth', 0.3);
      tt = max(t,tt);
      bb = min(b,bb);
      hold on;
   end
   axis([0 (ndata+1) bb-.05*(tt-bb) tt+.05*(tt-bb)]);
   hold off;
end 
set(gca,'XTick', 1:ndata);
set(gca,'XTickLabel',labl)

