function b=bmake(g)
%BMAKE Routine to construct boundaries (boundary objects) from grain objects.
% Syntax:  b=bmake(g);
%    g   - grain objects

% This file is part of polyLX.
% 
% polyLX is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% polyLX is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with polyLX.  If not, see <http://www.gnu.org/licenses/>.

% polyLX - MATLAB toolbox for microstructure analyses
% Copyright (C) 2010 Ondrej Lexa

% Initialize
co=zeros(0,2);
cn=sparse([],[],[],1,1,0);

h=waitbar(0,'Please wait...','Name','Decomposing grain objects...');

%Decompose grains
poc=length(g);
for i=1:poc
    waitbar(i/poc,h);
    [x,y]=get(g(i),'x','y');
    for j=1:length(x)-1
        nfrom=find((co(:,1)==x(j))&(co(:,2)==y(j)));
        if isempty(nfrom)
            co=[co;x(j) y(j)];
            nfrom=size(co,1);
        end
        nto=find((co(:,1)==x(j+1))&(co(:,2)==y(j+1)));
        if isempty(nto)
            co=[co;x(j+1) y(j+1)];
            nto=size(co,1);
        end
        cn(nfrom,nto)=i;
    end
    nholes=get(g(i),'nholes');
    if nholes>0
        hol=get(g(i),'holes');
        for k=1:nholes
            x=hol(k).x;
            y=hol(k).y;
            for j=1:length(x)-1
                nfrom=find((co(:,1)==x(j))&(co(:,2)==y(j)));
                if isempty(nfrom)
                    co=[co;x(j) y(j)];
                    nfrom=size(co,1);
                end
                nto=find((co(:,1)==x(j+1))&(co(:,2)==y(j+1)));
                if isempty(nto)
                    co=[co;x(j+1) y(j+1)];
                    nto=size(co,1);
                end
                cn(nfrom,nto)=i;
            end
        end
    end
end
close(h);

h=waitbar(0,'Please wait...','Name','Searching shared boundaries...');

idx=1;
bb=cn&cn';      % Mark inner boundaries
bn=bb.*cn;      % Remove edges
st=sum(bb);     %Calculate power of nodes
st(st==2)=0;    %Remove inner nodes
tot=sum(st);

while any(st)
    zac=find(st);           %Find starting nodes
    zac=zac(1);             %Choose first one
    st(zac)=st(zac)-1;      %Decrase power of node
    bco=co(zac,:);
    go=true;
    while go
        next=find(bn(zac,:));     %Follow direction
        next=next(1);               %Choose first one
        m1=bn(zac,next);
        m2=bn(next,zac);
        bn(zac,next)=0;
        bn(next,zac)=0;
        bco=[bco;co(next,:)];
        go=~any(find(st)==next);
        zac=next;
    end
    st(zac)=st(zac)-1;
    b(idx)=polylxboundary(idx,full(m1),full(m2),char(get(g(m1),'phase')),char(get(g(m2),'phase')),bco(:,1),bco(:,2));
    idx=idx+1;
    waitbar((tot-sum(st))/tot,h);
end
close(h)

% Check islands
if nnz(bn)>0
    h=waitbar(0,'Please wait...','Name','Checking islands...');

    bb=bn&bn';      % Mark boundaries
    st=sum(bb);     %Calculate power of nodes
    tot=sum(st);
    
    while any(st)
        zac=find(st);           %Find starting nodes
        zac=zac(1);             %Choose first one
        zzac=zac;               %Remember startposition
        st(zac)=0;              %Decrase power of node
        bco=co(zac,:);
        go=true;
        while go
            next=find(bn(zac,:));       %Follow direction
            next=next(1);               %Choose first one
            m1=bn(zac,next);
            m2=bn(next,zac);
            bn(zac,next)=0;
            bn(next,zac)=0;
            bco=[bco;co(next,:)];
            st(next)=0;
            go=~(zzac==next);
            zac=next;
        end
        b(idx)=polylxboundary(idx,full(m1),full(m2),char(get(g(m1),'phase')),char(get(g(m2),'phase')),bco(:,1),bco(:,2));
        idx=idx+1;
        waitbar((tot-sum(st))/tot,h);
    end
    close(h)
end
%Check for no boundary
if ~exist('b','var')
    b=[];
end
