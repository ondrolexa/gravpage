function gc=gconvhull(g)
%GCONVHULL Transform each grain into grain defined by convex hull of original grain.
% Syntax: gc=gconvhull(g);

% This file is part of polyLX.
% 
% polyLX is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% polyLX is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with polyLX.  If not, see <http://www.gnu.org/licenses/>.

% polyLX - MATLAB toolbox for microstructure analyses
% Copyright (C) 2010 Ondrej Lexa

if nargin<1
    gc=[];
    return
end

if ~isa(g,'polylxgrain');
    gc=[];
    return
end

h=waitbar(0,'Please wait...','Name','Calculating...');
poc=length(g);
for i=1:poc
    [x,y]=get(g(i),'x','y');
    k=convhull(x,y);
    tt=plgeo(x(k),y(k));
    if sign(tt(1))>0
        gc(i)=polylxgrain(get(g(i),'id'),[char(get(g(i),'phase')) '-ch'],x(k),y(k),get(g(i),'UserData'));
    else
        gc(i)=polylxgrain(get(g(i),'id'),[char(get(g(i),'phase')) '-ch'],flipud(x(k)),flipud(y(k)),get(g(i),'UserData'));
    end
    waitbar(i/poc,h);
end
close(h)