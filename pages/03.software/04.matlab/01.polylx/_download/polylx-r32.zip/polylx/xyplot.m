function [p,corr]=xyplot(g,varargin)
%XYPLOT Scatter plot with fitted linear regression.
%Syntax: [p,corr] = xyplot(x,y,[style])
%         [p,corr] = xyplot(g,p1,p2,[style])
%Inputs:
%   x vector of independent variable
%   y vector of dependent variable
%   g grain or boundary object
%   p1 property for independent variable
%   p2 property for dependent variable
%Outputs:
%   p - vector of fit coefficients: 
%   corr - correlation coefficient

% This file is part of polyLX.
% 
% polyLX is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% polyLX is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with polyLX.  If not, see <http://www.gnu.org/licenses/>.

% polyLX - MATLAB toolbox for microstructure analyses
% Copyright (C) 2010 Ondrej Lexa

%Default plot style
pstyle='k.';

% Parse inputs
msg='Bad arguments';
try
    switch class(g)
        case {'polylxgrain','polylxboundary'}
            if nargin<3
                error('You must provide two properties for XY plot.')
            else
                xlbl=varargin{1};
                x=get(g,xlbl);
                ylbl=varargin{2};
                y=get(g,ylbl);
            end
            if nargin>3
                pstyle=varargin{3};
            end
        case 'double'
            if nargin<2
                error('You must provide at least two arguments for XY plot.');
            else
                xlbl='x';
                x=g;
                ylbl='y';
                y=varargin{1};
            end
            if nargin>2
                pstyle=varargin{2};
            end
        otherwise
            error('Wrong arguments')
    end
catch ME
    fprintf([ME.message '\n\n'])
    help xyplot
    return
end

%Plot
h=plot(x,y,pstyle);

%get the axes ranges to position the text and for polyval
xlim=get(gca,'XLim');
ylim=get(gca,'YLim');
%define the text position
xtext=xlim(1)+0.07*(xlim(2)-xlim(1));
ytext=ylim(2)-0.1*(ylim(2)-ylim(1));
%get data and line color
x=get(h,'XData');
y=get(h,'YData');
cc=get(h,'Color');
%remove NaNs from the data
bad=isnan(x) | isnan(y);
x=x(~bad);
y=y(~bad);
%fit and evaluate
p=polyfit(x,y,1);
yfit=polyval(p,xlim);
hold on
plot(xlim,yfit,'-','Color',cc)
hold off
corr=corrcoef(x,y);
corr=corr(3);
if p(2)>0
    text(xtext,ytext,sprintf('%s = %.4g*%s+%.4g  (corr = %.3g)',ylbl,p(1),xlbl,p(2),corr),'Color',cc);
else
    text(xtext,ytext,sprintf('%s = %.4g*%s-%.4g  (corr = %.3g)',ylbl,p(1),xlbl,-p(2),corr),'Color',cc);
end
set(gca,'YLim',ylim)


xlabel(xlbl);
ylabel(ylbl);
title('Linear Regression');

