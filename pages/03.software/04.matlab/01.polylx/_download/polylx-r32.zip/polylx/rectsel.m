function rectsel
% callback function to select grains in rectangle

% This file is part of polyLX.
% 
% polyLX is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% polyLX is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with polyLX.  If not, see <http://www.gnu.org/licenses/>.

% polyLX - MATLAB toolbox for microstructure analyses
% Copyright (C) 2010 Ondrej Lexa

if strcmp(get(gcf,'selectiontype'),'alt')
    getsel('clear')
    return
end
if strcmp(get(gcf,'selectiontype'),'extend')
    getsel('invert')
    return
end
point1 = get(gca,'CurrentPoint');    % button down detected
finalRect = rbbox;                   % return figure units
if ~any(finalRect)
    return
end
point2 = get(gca,'CurrentPoint');    % button up detected
point1 = point1(1,1:2);              % extract x and y
point2 = point2(1,1:2);
p1 = min(point1,point2);             % calculate locations
offset = abs(point1-point2);         % and dimensions

% define polygon
x = [p1(1) p1(1)+offset(1) p1(1)+offset(1) p1(1) p1(1)];
y = [p1(2) p1(2) p1(2)+offset(2) p1(2)+offset(2) p1(2)];

if all(offset)
    h=findobj(gca,'Type','patch','Tag','grain');
    c=get(h,'UserData');
    if size(c,1)>1
        cc=cat(1,c{:});
    else
        cc=c;
    end
    xp=cc(:,2);
    yp=cc(:,3);
    inp=find(inpolygon(xp,yp,x,y));
    if any(inp)
        ixc=find(~isnan(cc(inp,4)));
        set(h(inp),'Selected','on')
        set(h(inp),'FaceColor',[0.5 0.5 0.5])
        set(h(inp(ixc)),{'UserData'},num2cell(cc(inp(ixc),:),2));
    end
end

