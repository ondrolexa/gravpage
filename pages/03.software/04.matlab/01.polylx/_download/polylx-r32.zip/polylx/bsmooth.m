function gn=bsmooth(g,varargin)
%BSMOOTH Smooth boundary objects.
% Syntax: bn=bsmooth(b,options);
% Options are:
%  'method'  ... 'dp' Douglas-Peucker simplification. Default.
%            ... 'bezier' quadratic bezier curves approximation.
%            ... 'average' averaging of neighborough coordinates.
%                          Works well for staircase boundaries.
%            ... 'renee' Regularize outlines with pchip (similar to SCASMO)
%  'tol'     ... Distance tolerance for Douglas-Peucker and bezier.
%                Default 1/100 of mode of CumLength.
%  'step'    ... Approximate length of segments for renee method.
%  'clean '  ... simplification method after bezier.
%            ... 'dp' Douglas-Peucker simplification. Default.
%            ... 'bezier' quadratic bezier curves approximation.

% This file is part of polyLX.
% 
% polyLX is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% polyLX is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with polyLX.  If not, see <http://www.gnu.org/licenses/>.

% polyLX - MATLAB toolbox for microstructure analyses
% Copyright (C) 2010 Ondrej Lexa

if nargin<1
    help bsmooth
    return
end

% initialize defaults and parse arguments
opts.method='renee';
lnb=get(g,'CumLength');
opts.tol=exp(mean(log(lnb))-std(log(lnb))^2)/100;
opts.step=exp(mean(log(lnb))-std(log(lnb))^2)/5;
opts.clean='dp';
opts=parseargs(varargin,opts);

pocet=size(g,2);
h=waitbar(0,'Please wait...','Name',['Smoothing... [' opts.method ']']);
switch opts.method
    case 'average'
        cix=1;
        for ii=1:pocet
            [x,y]=get(g(ii),'x','y');
            if length(x)>2
                xm=mean([x(1:end-1) x(2:end)],2);
                ym=mean([y(1:end-1) y(2:end)],2);
                gn(cix)=polylxboundary(get(g(ii),'id'),get(g(ii),'ixa'),get(g(ii),'ixb'),char(get(g(ii),'phasea')),char(get(g(ii),'phaseb')),xm,ym,get(g(ii),'UserData'));
                cix=cix+1;
            else
                gn(cix)=g(ii);
                cix=cix+1;
            end
            waitbar(ii/pocet,h);
        end
        close(h)
    case 'dp'
        disp(['Using tolerance ' num2str(opts.tol)])
        cix=1;
        for ii=1:pocet
            [x,y]=get(g(ii),'x','y');
            [nx,ny]=dpsimply(x,y,opts.tol);
            gn(cix)=polylxboundary(get(g(ii),'id'),get(g(ii),'ixa'),get(g(ii),'ixb'),char(get(g(ii),'phasea')),char(get(g(ii),'phaseb')),nx,ny,get(g(ii),'UserData'));
            cix=cix+1;
            waitbar(ii/pocet,h);
        end
        close(h)
    case 'bezier'
        if strcmp(opts.clean,'renee')
            disp(['Using step ' num2str(opts.step)])
        else
            disp(['Using tolerance ' num2str(opts.tol)])
        end
        cix=1;
        for ii=1:pocet
            [x,y]=get(g(ii),'x','y');
            if length(x)>2
                [x,y]=bezcurve(x,y);
            end
            if strcmp(opts.clean,'renee')
                [nx,ny]=renee(x,y,opts.step);
                if length(nx)>1
                    gnn = polylxboundary(get(g(ii),'id'),get(g(ii),'ixa'),get(g(ii),'ixb'),char(get(g(ii),'phasea')),char(get(g(ii),'phaseb')),nx,ny,get(g(ii),'UserData'));
                    l0=get(g(ii),'cumlength');
                    l1=get(gnn,'cumlength');
                    if abs(l1-l0)/l0<1
                        gn(cix)= gnn;
                        cix=cix+1;
                    else
                        disp(['Boundary ' num2str(ii) ' smooth was not successfull.'])
                    end
                else
                   disp(['Too short boundary ' num2str(ii) ' was discarded.'])
                end
            else
                [nx,ny]=dpsimply(nx,ny,opts.tol);
                gn(cix)=polylxboundary(get(g(ii),'id'),get(g(ii),'ixa'),get(g(ii),'ixb'),char(get(g(ii),'phasea')),char(get(g(ii),'phaseb')),nx,ny,get(g(ii),'UserData'));
                cix=cix+1;
            end
            waitbar(ii/pocet,h);
        end
        close(h)
    case 'renee'
        disp(['Using step ' num2str(opts.step)])
        cix=1;
        for ii=1:pocet
            [x,y]=get(g(ii),'x','y');
            [nx,ny]=renee(x,y,opts.step);
            if length(nx)>1
                gnn = polylxboundary(get(g(ii),'id'),get(g(ii),'ixa'),get(g(ii),'ixb'),char(get(g(ii),'phasea')),char(get(g(ii),'phaseb')),nx,ny,get(g(ii),'UserData'));
                l0=get(g(ii),'cumlength');
                l1=get(gnn,'cumlength');
                if abs(l1-l0)/l0<1
                    gn(cix)= gnn;
                    cix=cix+1;
                else
                    disp(['Boundary ' num2str(ii) ' smooth was not successfull.'])
                end
            else
               disp(['Boundary ' num2str(ii) ' degenerate and was discarded.'])
            end 
            waitbar(ii/pocet,h);
        end
        close(h)
    otherwise
        gn=g;
end

function [nx,ny]=dpsimply(x,y,tol,sx,sy)
    if nargin<5
        sx=x(1);
        sy=y(1);
    end
    x0=x(1);
    dx=x(end)-x0;
    y0=y(1);
    dy=y(end)-y0;
    tria=abs((x-x0)*dy-(y-y0)*dx)/sqrt(dx*dx+dy*dy);
    [mx,ix]=max(tria);
    if mx>tol
        sx=[sx;x(ix)];
        sy=[sy;y(ix)];
        [sx,sy]=dpsimply(x(1:ix),y(1:ix),tol,sx,sy);
        if nargin<5
            [sx,sy]=dpsimply([x(ix:end);x(1)],[y(ix:end);y(1)],tol,sx,sy);
        else
            [sx,sy]=dpsimply(x(ix:end),y(ix:end),tol,sx,sy);
        end
    end
    nx=sx;
    ny=sy;
    if nargin<5
        nx=[nx;x(end)];
        ny=[ny;y(end)];
        [dummy,ia,dummy]=intersect([x y],[nx ny],'rows');
        ia=sort(ia);
        nx=x(ia);
        ny=y(ia);
    end

function [xs,ys]=bezcurve(x,y)
    t=linspace(0,1,20)';
    xs=[];
    ys=[];
    for i=2:length(x)-1
        xs=[xs(1:end-1);(x(i-1)+x(i))*(1 - t).^2/2 + 2*x(i)*(1-t).*t + (x(i)+x(i+1))*t.^2/2];
        ys=[ys(1:end-1);(y(i-1)+y(i))*(1 - t).^2/2 + 2*y(i)*(1-t).*t + (y(i)+y(i+1))*t.^2/2];
    end

function [x1,y1]=renee(x,y,step)
    ds=sqrt(diff(x).^2+diff(y).^2);
    s=[0;cumsum(ds)];
    ns=[mod(s(end),step)/2:step:s(end)]';
    st=0;
    x1=x;
    y1=y;
    while abs(mean(ds)-1)>1e-10&&st<20
        st=st+1;
        x1=pchip(s,x,ns);
        y1=pchip(s,y,ns);
        ds=sqrt(diff(x1).^2+diff(y1).^2)/step;
        nds=diff(ns)./ds;
        ns=[ns(1);cumsum(nds)];
    end
        