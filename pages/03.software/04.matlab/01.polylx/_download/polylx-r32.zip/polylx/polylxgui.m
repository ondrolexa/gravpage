function polylxgui
%POLYLXGUI Simple GUI to explore basic characteristics and produce simple graphics.
% Syntax: polylxgui

% This file is part of polyLX.
% 
% polyLX is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% polyLX is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with polyLX.  If not, see <http://www.gnu.org/licenses/>.

% polyLX - MATLAB toolbox for microstructure analyses
% Copyright (C) 2010 Ondrej Lexa

clear all;
% Initialize global variables
width=675;
g=[];
b=[];

% SS= figure('CloseRequestFcn', @closefirstfigure, ...
%     'Name','PolyLX Toolbox GUI v1.1', ...
%     'Resize','off', ...
%     'ToolBar','none', ...
%     'MenuBar','none');
% 
% axis off;
% logo = imread('logo.jpg');
% imshow(logo);

H = figure('CloseRequestFcn', @closefirstfigure, ...
    'Name','PolyLX Toolbox GUI v1.1', ...
	'Tag','polyLXGUI', ...
    'Resize','off', ...
    'ToolBar','none', ...
    'MenuBar','none');
% resize main window
pos=get(H,'Position');
pos(3:4)=[width,100];
set(H,'Position',pos);

% Create panels
gpanel=uipanel('Parent',H,'Units','pixels','Title','Grains','Position',[55 53 width-58 43],'BackgroundColor',get(H,'color'));
bpanel=uipanel('Parent',H,'Units','pixels','Title','Boundaries','Position',[55 5 width-58 43],'BackgroundColor',get(H,'color'));

HF1 = uicontrol('Parent',H, ...
	'Callback',@polyreaddata, ...
	'Position',[5 53 45 37], ...
	'String','Read', ...
    'TooltipString','Read data...', ...
	'Tag','Read');
HF2 = uicontrol('Parent',H, ...
	'Callback',@closefirstfigure, ...
	'Position',[5 5 45 37], ...
	'String','Exit', ...
    'TooltipString','Exit', ...
	'Tag','Exit');

%-----------------------------------
% Grain commands
%-----------------------------------
HG1 = uicontrol('Parent',gpanel, ...
    'Style','pushbutton', ...
	'Callback',@polyplotg, ...
	'Position',[5 5 45 20], ...
	'String','Plot', ...
    'TooltipString','Show map of grain objects', ...
	'Tag','PlotG');
Gsel = uicontrol('Parent',gpanel, ...
    'Style','popupmenu', ...
	'Position',[55 5 65 20], ...
	'String',{'All'}, ...
    'TooltipString','Choose grain phase to work with', ...
	'Tag','GrainSel');
HG2 = uicontrol('Parent',gpanel, ...
    'Style','pushbutton', ...
	'Callback',@polyareag, ...
	'Position',[125 5 45 20], ...
	'String','Area', ...
    'TooltipString','Show planimetry of grain objects', ...
	'Tag','AreaG');
HG3 = uicontrol('Parent',gpanel, ...
    'Style','pushbutton', ...
	'Callback',@polysurforg, ...
	'Position',[175 5 45 20], ...
	'String','Surfor', ...
    'TooltipString','SURFOR analysis of grain objects', ...
	'Tag','SurforG');
HG4 = uicontrol('Parent',gpanel, ...
    'Style','pushbutton', ...
	'Callback',@polyparorg, ...
	'Position',[225 5 45 20], ...
	'String','Paror', ...
    'TooltipString','PAROR analysis of grain objects', ...
	'Tag','ParorG');
HG5 = uicontrol('Parent',gpanel, ...
    'Style','pushbutton', ...
	'Callback',@polyparisg, ...
	'Position',[275 5 45 20], ...
	'String','Paris', ...
    'TooltipString','PARIS analysis of grain objects', ...
	'Tag','ParisG');
HG6 = uicontrol('Parent',gpanel, ...
    'Style','pushbutton', ...
	'Callback',@polyorientg, ...
	'Position',[325 5 45 20], ...
	'String','Orient', ...
    'TooltipString','Orientation of grain objects', ...
	'Tag','OrientG');
HG7 = uicontrol('Parent',gpanel, ...
    'Style','pushbutton', ...
	'Callback',@polygrainsz, ...
	'Position',[375 5 45 20], ...
	'String','Size', ...
    'TooltipString','Grain size distribution', ...
	'Tag','GSize');
G1sel = uicontrol('Parent',gpanel, ...
    'Style','popupmenu', ...
	'Position',[425 5 65 20], ...
	'String',{'Area','OutArea','Perimeter','OutPerimeter','Length','Width','Orientation','AxialRatio','Elongation','OutElongation','EAD','OutEAD','Roundness','OutRoundness','Circularity','OutCircularity','Ellipticity','OutEllipticity','Compactness','OutCompactness','GSI','OutGSI','GSF','OutGSF'}, ...
    'TooltipString','Choose property to work with', ...
	'Tag','Prop1SelG');
G2sel = uicontrol('Parent',gpanel, ...
    'Style','popupmenu', ...
	'Position',[495 5 65 20], ...
	'String',{'Area','OutArea','Perimeter','OutPerimeter','Length','Width','Orientation','AxialRatio','Elongation','OutElongation','EAD','OutEAD','Roundness','OutRoundness','Circularity','OutCircularity','Ellipticity','OutEllipticity','Compactness','OutCompactness','GSI','OutGSI','GSF','OutGSF'}, ...
    'TooltipString','Choose property to work with', ...
	'Tag','Prop2SelG');
HG8 = uicontrol('Parent',gpanel, ...
    'Style','pushbutton', ...
	'Callback',@polyxyg, ...
	'Position',[565 5 45 20], ...
	'String','XYPlot', ...
    'TooltipString','Plot X-Y graph of choosen properties of grains', ...
	'Tag','GXYPlot');

%-----------------------------------
% Boundary commands
%-----------------------------------
HB1 = uicontrol('Parent',bpanel, ...
    'Style','pushbutton', ...
	'Callback',@polyplotb, ...
	'Position',[5 5 45 20], ...
	'String','Plot', ...
    'TooltipString','Show map of boundary objects', ...
	'Tag','PlotB');
Bsel = uicontrol('Parent',bpanel, ...
    'Style','popupmenu', ...
	'Position',[55 5 65 20], ...
	'String',{'All'}, ...
    'TooltipString','Choose boundary type to work with', ...
	'Tag','BoundarySel');
HB2 = uicontrol('Parent',bpanel, ...
    'Style','pushbutton', ...
	'Callback',@polylengthb, ...
	'Position',[125 5 45 20], ...
	'String','Length', ...
    'TooltipString','Show lengths of boundary objects', ...
	'Tag','LengthB');
HB3 = uicontrol('Parent',bpanel, ...
    'Style','pushbutton', ...
	'Callback',@polysurforb, ...
	'Position',[175 5 45 20], ...
	'String','Surfor', ...
    'TooltipString','SURFOR analysis of boundary objects', ...
	'Tag','SurforB');
HB4 = uicontrol('Parent',bpanel, ...
    'Style','pushbutton', ...
	'Callback',@polyparorb, ...
	'Position',[225 5 45 20], ...
	'String','Paror', ...
    'TooltipString','PAROR analysis of boundary objects', ...
	'Tag','ParorB');
HB5 = uicontrol('Parent',bpanel, ...
    'Style','pushbutton', ...
	'Callback',@polyparisb, ...
	'Position',[275 5 45 20], ...
	'String','Paris', ...
    'TooltipString','PARIS analysis of boundary objects', ...
	'Tag','ParisB');
HB6 = uicontrol('Parent',bpanel, ...
    'Style','pushbutton', ...
	'Callback',@polyorientb, ...
	'Position',[325 5 45 20], ...
	'String','Orient', ...
    'TooltipString','Orientation of boundary objects', ...
	'Tag','OrientB');
B1sel = uicontrol('Parent',bpanel, ...
    'Style','popupmenu', ...
	'Position',[425 5 65 20], ...
	'String',{'CumLength','Length','Width','Orientation','AxialRatio','Straightness'}, ...
    'TooltipString','Choose property to work with', ...
	'Tag','Prop1SelB');
B2sel = uicontrol('Parent',bpanel, ...
    'Style','popupmenu', ...
	'Position',[495 5 65 20], ...
	'String',{'CumLength','Length','Width','Orientation','AxialRatio','Straightness'}, ...
    'TooltipString','Choose property to work with', ...
	'Tag','Prop2SelB');
HB8 = uicontrol('Parent',bpanel, ...
    'Style','pushbutton', ...
	'Callback',@polyxyb, ...
	'Position',[565 5 45 20], ...
	'String','XYPlot', ...
    'TooltipString','Plot X-Y graph of choosen properties of boundaries', ...
	'Tag','BXYPlot');


% Disable all commands
set(get(gpanel,'Children'),'enable','off');
set(get(bpanel,'Children'),'enable','off');
% Close splash screen
% delete(SS);

%----------------------------------------------
%Nested functions
%----------------------------------------------
    function polyreaddata(varargin)  % needs varargin for callbacks
        %
        % Read data
        %
        res=listdlg('ListString',{'Shapefile','Database','JML file'},'ListSize',[160,100],'SelectionMode','single','PromptString','Read data from:','OKString','Next>','Name','Read data');
        if ~isempty(res)
            g=[];
            b=[];
            switch res
                case 1
                    res2=listdlg('ListString',{'Only grains','Read boundaries','Generate boundaries'},'ListSize',[160,100],'SelectionMode','single','PromptString','Use boundaries:','OKString','OK','Name','Boundaries');
                    if ~isempty(res2)
                        switch res2
                            case 1
                                g=shpread;
                            case 2
                                g=shpread;
                                b=shpread;
                            case 3
                                g=shpread;
                                b=bmake(g);
                        end
                    end
                case 2
                    res2=listdlg('ListString',{'Only grains','Read boundaries','Generate boundaries'},'ListSize',[160,100],'SelectionMode','single','PromptString','Use boundaries:','OKString','OK','Name','Boundaries');
                    if ~isempty(res2)
                        switch res2
                            case 1
                                g=dbread;
                            case 2
                                [g,b]=dbread;
                            case 3
                                g=dbread;
                                b=bmake(g);
                        end
                    end
                case 3
                    res2=listdlg('ListString',{'Only grains','Generate boundaries'},'ListSize',[160,100],'SelectionMode','single','PromptString','Use boundaries:','OKString','OK','Name','Boundaries');
                    if ~isempty(res2)
                        switch res2
                            case 1
                                g=jmlread;
                            case 2
                                g=jmlread;
                                b=bmake(g);
                        end
                    end
            end
        end
        if ~isempty(g)
            set(get(gpanel,'Children'),'enable','on');
            set(Gsel,'String',[{'All'};gplist(g)]);
        end
        if ~isempty(b)
            set(get(bpanel,'Children'),'enable','on');
            set(Bsel,'String',[{'All'};btlist(b)]);
        end 
    end
    function polyplotg(varargin)
        %
        % Plot grains
        %
        figure;
        ix=get(Gsel,'Value');
        if ix~=1
            ph=get(Gsel,'String');
            plot(g(ph{ix}));
            set(gcf,'Name',['Grain map of phase ' ph{ix}]);
        else
            plot(g);
            set(gcf,'Name','Grain map');
        end
    end
    function polyplotb(varargin)
        %
        % Plot boundaries
        %
        figure;
        ix=get(Bsel,'Value');
        if ix~=1
            ph=get(Bsel,'String');
            plot(b(ph{ix}));
            set(gcf,'Name',['Boundary map of type ' ph{ix}]);
        else
            plot(b);
            set(gcf,'Name','Boundary map');
        end
    end
    function polyareag(varargin)
        %
        % Plot areas
        %
        figure;
        afract(g,1);
        set(gcf,'Name','Grain phase area fractions');
    end
    function polylengthb(varargin)
        %
        % Plot lengths
        %
        figure;
        afract(b,1);
        set(gcf,'Name','Boundary type length fractions');
    end
    function polysurforg(varargin)
        figure;
        ix=get(Gsel,'Value');
        if ix~=1
            ph=get(Gsel,'String');
            [dummy,sd]=gsurfor(g(ph{ix}));
            set(gcf,'Name',['SURFOR graph of grain phase ' ph{ix}]);
        else
            [dummy,sd]=gsurfor(g);
            set(gcf,'Name','SURFOR graph of grains');
        end
        r=sum(sd)/max(sum(sd));
        pannoplot(r);
    end
    function polysurforb(varargin)
        figure;
        ix=get(Bsel,'Value');
        if ix~=1
            ph=get(Bsel,'String');
            [dummy,sd]=gsurfor(b(ph{ix}));
            set(gcf,'Name',['SURFOR graph of boundary type ' ph{ix}]);
        else
            [dummy,sd]=gsurfor(b);
            set(gcf,'Name','SURFOR graph of boundaries');
        end
        r=sum(sd)/max(sum(sd));
        pannoplot(r);
    end
    function polyparorg(varargin)
        figure;
        ix=get(Gsel,'Value');
        if ix~=1
            ph=get(Gsel,'String');
            [dummy,sd]=gparor(g(ph{ix}));
            set(gcf,'Name',['PAROR graph of grain phase ' ph{ix}]);
        else
            [dummy,sd]=gparor(g);
            set(gcf,'Name','PAROR graph of grains');
        end
        r=sum(sd)/max(sum(sd));
        pannoplot(r);
    end
    function polyparorb(varargin)
        figure;
        ix=get(Bsel,'Value');
        if ix~=1
            ph=get(Bsel,'String');
            [dummy,sd]=gparor(b(ph{ix}));
            set(gcf,'Name',['PAROR graph of boundary type ' ph{ix}]);
        else
            [dummy,sd]=gparor(b);
            set(gcf,'Name','PAROR graph of boundaries');
        end
        r=sum(sd)/max(sum(sd));
        pannoplot(r);
    end
    function polyparisg(varargin)
        figure;
        ix=get(Gsel,'Value');
        if ix~=1
            ph=get(Gsel,'String');
            sd=aparis(g(ph{ix}));
            set(gcf,'Name',['PARIS graph of grain phase ' ph{ix}]);
        else
            sd=aparis(g);
            set(gcf,'Name','PARIS graph of grains');
        end
        r=sum(sd)/max(sum(sd));
        pannoplot(r);
    end
    function polyparisb(varargin)
        figure;
        ix=get(Bsel,'Value');
        if ix~=1
            ph=get(Bsel,'String');
            sd=aparis(b(ph{ix}));
            set(gcf,'Name',['PARIS graph of boundary type ' ph{ix}]);
        else
            sd=aparis(b);
            set(gcf,'Name','PARIS graph of boundaries');
        end
        r=sum(sd)/max(sum(sd));
        pannoplot(r);
    end
    function polyorientg(varargin)
        figure;
        ix=get(Gsel,'Value');
        if ix~=1
            ph=get(Gsel,'String');
            prose(g(ph{ix}));
            set(gcf,'Name',['Orientation of grains of phase ' ph{ix}]);
        else
            prose(g);
            set(gcf,'Name','Orientation of grains');
        end
    end
    function polyorientb(varargin)
        figure;
        ix=get(Bsel,'Value');
        if ix~=1
            ph=get(Bsel,'String');
            prose(b(ph{ix}));
            set(gcf,'Name',['Orientation of boundaries of type ' ph{ix}]);
        else
            prose(g);
            set(gcf,'Name','Orientation of boundaries');
        end
    end
    function polygrainsz(varargin)
        figure;
        ix=get(Gsel,'Value');
        if ix~=1
            ph=get(Gsel,'String');
            pgsize(g(ph{ix}));
            set(gcf,'Name',['Grain size distribution of phase ' ph{ix}]);
        else
            pgsize(g);
            set(gcf,'Name','Grain size distribution');
        end
    end
    function polyxyg(varargin)
        figure;
        ix=get(Gsel,'Value');
        props=get(G1sel,'String');
        if ix~=1
            ph=get(Gsel,'String');
            x=get(g(ph{ix}),props{get(G1sel,'Value')});
            y=get(g(ph{ix}),props{get(G2sel,'Value')});
            set(gcf,'Name',['Plot of ' props{get(G1sel,'Value')} '/' props{get(G2sel,'Value')} ' of grains of phase ' ph{ix}]);
        else
            x=get(g,props{get(G1sel,'Value')});
            y=get(g,props{get(G2sel,'Value')});
            set(gcf,'Name',['Plot of ' props{get(G1sel,'Value')} '/' props{get(G2sel,'Value')} ' of grains']);
        end
        xyplot(x,y);
        xlabel(props{get(G1sel,'Value')});
        ylabel(props{get(G2sel,'Value')});
    end
    function polyxyb(varargin)
        figure;
        ix=get(Bsel,'Value');
        props=get(B1sel,'String');
        if ix~=1
            ph=get(Bsel,'String');
            x=get(b(ph{ix}),props{get(B1sel,'Value')});
            y=get(b(ph{ix}),props{get(B2sel,'Value')});
            set(gcf,'Name',['Plot of ' props{get(B1sel,'Value')} '/' props{get(B2sel,'Value')} ' of boundaries of type ' ph{ix}]);
        else
            x=get(b,props{get(B1sel,'Value')});
            y=get(b,props{get(B2sel,'Value')});
            set(gcf,'Name',['Plot of ' props{get(B1sel,'Value')} '/' props{get(B2sel,'Value')} ' of grains']);
        end
        xyplot(x,y);
        xlabel(props{get(B1sel,'Value')});
        ylabel(props{get(B2sel,'Value')});
    end

    function pannoplot(r)
        r=[r(end) r r];
        phi=[0:360]*pi/180;
        h=polar(phi,r,'b-');
        set(h,'LineWidth',2);
        view(90,-90);
        ylabel(['Ratio: ' num2str(max(r)/min(r))]);
    end
    function closefirstfigure(varargin)
        delete(H);
    end
end %polylxgui
