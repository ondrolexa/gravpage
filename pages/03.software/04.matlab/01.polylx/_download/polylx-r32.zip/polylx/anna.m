function [r,v,nnd]=anna(g,varargin)
%ANNA Return index of nearest-neighbour statistics.
% Syntax:  [R,z,dist]=anna(g,options);
%        R - nearest-neighbour statistics index
%            >1..regular 1..random <1..clustered
%       z  - standard z-value (if above 1.96, we are 95% confident that the
%            distribution is not randomly distributed
%     dist - vector of euclidan distances to nearest neighbour
% options are string evaluated by function (these are default values):
% 'plot'        ... 0 ... no plot, 1 ... plot distance histogram. Default 0
% 'mean'        ... Mean distance for random distribution.  Default 0
%                   0 ... from point density 1 ... from random points
% 'steps'       ... Number of simulation steps for random points. Defaut 100
%                   Greater value gives more stable results, but it is slow

% This file is part of polyLX.
% 
% polyLX is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% polyLX is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with polyLX.  If not, see <http://www.gnu.org/licenses/>.

% polyLX - MATLAB toolbox for microstructure analyses
% Copyright (C) 2010 Ondrej Lexa

if nargin<1
    help anna
    r=[];
    v=[];
    nnd=[];
    return
end
if ~isa(g,'polylxgrain')
    help anna
    r=[];
    v=[];
    nnd=[];
    return
end


% Process input arguments
opts.plot=0;
opts.mean=0;
opts.steps=100;
opts=parseargs(varargin,opts);

poc=length(g);
[gx,gy]=get(g,'xcentre','ycentre');

% determine area of convexhull
area=acharea(g,1);

if opts.mean == 0
    % Calculate mean distance of random distribution from point density
    nnrd=0.5*sqrt(area/poc);
else
    nnrd=[];
    for k=1:opts.steps
        % Calculate mean distance of random distribution from random points
        xr=min(gx)+(max(gx)-min(gx))*rand(size(gx));
        yr=min(gy)+(max(gy)-min(gy))*rand(size(gy));
        ce=[xr yr];
        tri=delaunay(ce(:,1),ce(:,2));
        nnd=[];
        for j=1:length(xr)
            [xi,yi]=find(tri==j);
            w=tri(xi,:);
            w=setdiff(w(:),j);
            dt=sqrt(sum((ce(w,:)-repmat(ce(j,:),length(w),1)).^2'));
            nn=min(dt);
            nnd=[nnd;nn];
        end
        nnrd=[nnrd;mean(nnd)];
    end
    nnrd=mean(nnrd);
end

% Calculate actual distances
nnd=[];
tri=delaunay(gx,gy); 
pts=[gx gy];

for j=1:poc
    [xi,yi]=find(tri==j);
    w=tri(xi,:);
    w=setdiff(w(:),j);
    dt=sqrt(sum((pts(w,:)-repmat(pts(j,:),length(w),1)).^2'));
    nn=min(dt);
    nnd=[nnd;nn];
end
mu=mean(nnd);
r=mu/nnrd;
v=abs(poc*(mu-nnrd))/(0.26136*sqrt(area));

disp(['R index: ' num2str(r)]);
if r>1
    disp(['Regularly spaced with Z-value (RCV 1.96): ' num2str(v)]);
else
    disp(['Clustered with Z-value (RCV 1.96): ' num2str(v)]);
end
if opts.plot~=0
    phist(nnd);
end

