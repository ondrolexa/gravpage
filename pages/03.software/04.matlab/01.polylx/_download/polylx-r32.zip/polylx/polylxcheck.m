function res=polylxcheck
%POLYLXCHECK Check and report polyLX settings

% This file is part of polyLX.
% 
% polyLX is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% polyLX is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with polyLX.  If not, see <http://www.gnu.org/licenses/>.

% polyLX - MATLAB toolbox for microstructure analyses
% Copyright (C) 2012 Ondrej Lexa

res=0;
plx=fileparts(mfilename('fullpath'));
disp('PolyLX - toolbox for quantitative microstructural analysis')

fid=fopen(fullfile(plx,'Contents.m'));
fgetl(fid);
ln=fgetl(fid);
fclose(fid);
disp(ln(3:end))
disp('Copyright (c) 2000-2012 Ondrej Lexa (lexa@natur.cuni.cz)')

p=path;
if strncmp(computer,'PC',2)
    sep=';';
else
    sep=':';
end
if strfind(p,[plx sep])
    disp('  PolyLX path............. OK')
else
    disp('  PolyLX path............. PolyLX not set in path')
    res=bitset(res,1);
end

if exist('mksqlite')>1
    disp('  SQlite3 support......... OK')
else
    disp('  SQlite3 support......... mksqlite not found')
    res=bitset(res,2);
end

if exist('database')>1
    disp('  Database toolbox........ OK')
else
    disp('  Database toolbox........ Not installed')
    res=bitset(res,3);
end

if any(~cellfun(@isempty,regexp(javaclasspath('-all'),'mysql(.*).jar')))
    disp('  MySQL Java connector.... OK')
else
    disp('  MySQL Java connector.... Not found')
    res=bitset(res,4);
end

if nargout==0
    clear res
end