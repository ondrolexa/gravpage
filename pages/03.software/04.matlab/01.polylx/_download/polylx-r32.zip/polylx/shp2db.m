function shp2db(flist)
%SHP2DB Routine to export several shapefiles into database.
% Sample name is derived from base filename of shapefiles.
% Syntax: shp2db(flist);
% flist is a filelist prepared by mkflist

% This file is part of polyLX.
% 
% polyLX is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% polyLX is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with polyLX.  If not, see <http://www.gnu.org/licenses/>.

% polyLX - MATLAB toolbox for microstructure analyses
% Copyright (C) 2010 Ondrej Lexa

if nargin<1
   flist=mkflist;
   if isempty(flist)
       return
   end
end

if isa(flist,'char')
    flist={flist};
end
   
poc=length(flist);
for i=1:poc
    [dummy,sample,dummy]=fileparts(flist{i});
    disp(['Converting file ' sample ' (' num2str(i) '/' num2str(poc) ')...']);
    g=shpread(flist{i});
    if isa(g,'polylxgrain')
        dbwrite(g,sample);
    end
    clear g
end
