function [gc,dt,pal]=cipgrainmap(g,c,type)
%CIPGRAINMAP Plot grain orientation map
% Syntax:
%      cipgrainmap(g,cipdata,[lut]);
%      cipgrainmap(g,dt,[lut]);
% where dt is output of graindata

% This file is part of polyLX.
% 
% polyLX is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% polyLX is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with polyLX.  If not, see <http://www.gnu.org/licenses/>.

% polyLX - MATLAB toolbox for microstructure analyses
% Copyright (C) 2010 Ondrej Lexa

if nargin<2
    help cipgrainmap
end
if nargin<3
    type='cip';
end
if isa(c,'cipdata')
    [dt,gc]=graindata(c,g);
else
    dt=c;
    gc=g;
end
if length(gc)~=size(dt,1)
    error('Grains and graindata must have same size.')
end
pal={};
for i=1:length(gc)
    pal{i,1}=i;
    pal{i,2}=num2str(i);
    [r,g,b]=azidip2color(dt(i,1),dt(i,2),'lut',type);
    pal{i,3}=[r g b];
end
plot(gc,'pal',pal,'leg',0)

