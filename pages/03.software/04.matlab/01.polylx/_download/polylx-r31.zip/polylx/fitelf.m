function [err,yt]=fitelf(lam,xx)
% function to fit data on ellipse
% lam is [a b phi]

% This file is part of polyLX.
% 
% polyLX is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% polyLX is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with polyLX.  If not, see <http://www.gnu.org/licenses/>.

% polyLX - MATLAB toolbox for microstructure analyses
% Copyright (C) 2010 Ondrej Lexa

global xdat ydat

a=lam(1);
b=lam(2);
phi=lam(3);

if nargout<2
   yt=2*sqrt(a*a.*cos((xdat-phi)*pi/180).^2+b*b.*sin((xdat-phi)*pi/180).^2);
   err=sum((ydat-yt).^2);
else
   yt=2*sqrt(a*a.*cos((xx-phi)*pi/180).^2+b*b.*sin((xx-phi)*pi/180).^2)';
   err=0;
end
