function stat=paxdev(g,varargin)
%PAXDEV Plot histogram of projection axes deviation from orthogonality.
% Syntax: stat=paxdev(pd,options);
%         stat=paxdev(g,options);
% pd is Nx180 matrix with individual projection values 
% when grain object is passed gparor is used to obtain projection
% options are passed to phist, see help phist
% stat are statistics from phist output, see help phist.

% This file is part of polyLX.
% 
% polyLX is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% polyLX is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with polyLX.  If not, see <http://www.gnu.org/licenses/>.

% polyLX - MATLAB toolbox for microstructure analyses
% Copyright (C) 2010 Ondrej Lexa

if nargin<1
    help paxdev;
    return;
end

% when grain object is passed parr
if isa(g,'polylxgrain')||isa(g,'polylxboundary')
   [dummy,pd]=gparor(g);
else
    pd=g;
end

%Find lao and sao
[dummy,lao]=max(pd,[],2);
[dummy,sao]=min(pd,[],2);

% calculate deviations
ix1=find(lao>sao);
ix2=find(lao<sao);
d=[sao(ix1)-lao(ix1)+90;sao(ix2)-lao(ix2)-90];
stat=phist(d,varargin{:});
xlabel('Deviation of projection axes from right angle');
