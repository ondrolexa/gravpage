function g=digread(fnm)
%DIGREAD Read DIG file into PolyLX
% Syntax:  g=digread;
%          g=digread(filename);

% This file is part of polyLX.
% 
% polyLX is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% polyLX is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with polyLX.  If not, see <http://www.gnu.org/licenses/>.

% polyLX - MATLAB toolbox for microstructure analyses
% Copyright (C) 2010 Ondrej Lexa

if nargin<1
    [filename, path]=uigetfile('*.dig', 'DIG files');
    if filename==0
        return
    end
    fnm=[path filename];
end

ix=0;
try
    fid=fopen(fnm,'r');
    h=fscanf(fid,'%d,%s',2);
    while ~feof(fid)
        n=h(1);
        lbl=char(h(2:end));
        co=fscanf(fid,'%f,%f',2*n);
        co=reshape(co,2,n);
        ix=ix+1;
        g(ix)=polylxgrain(ix,lbl,co(1,:)',co(2,:)');
        h=fscanf(fid,'%d,%s',2);
    end
catch
    disp(sprintf('The file %s is not valid DIG file.',fnm))
end