function [pa,pf]=aparis(g,opt)
%APARIS Return PARIS function and factor after Panozzo&Hurlimann, 1983.
% PARIS is function is calculated as (SURFOR-PAROR)/PAROR
% Syntax: [pa,pf]=aparis(g,[opt]);
% g can be grain object(s)
%    opt - 0 (default) do not include holes into calculations
%          1 include holes into calculations
%     pa - PARIS function
%     pf - PARIS factor

% This file is part of polyLX.
% 
% polyLX is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% polyLX is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with polyLX.  If not, see <http://www.gnu.org/licenses/>.

% polyLX - MATLAB toolbox for microstructure analyses
% Copyright (C) 2010 Ondrej Lexa

if nargin<1
    help aparis
    pa=[];
    pf=[];
    return
end
if ~isa(g,'polylxgrain')
    help aparis
    pa=[];
    pf=[];
    return
end

if nargin<2
 opt=0;
end

%Initialize
n=size(g,2);
pa=zeros(n,180);
h=fwaitbar(0,'Calculating...');
nn=[sin(rad(1:180));cos(rad(1:180))];
for ii=1:n
    [x,y]=get(g(ii),'x','y');
    xd=diff(x);
    yd=diff(y);
    if bitget(opt,1)==1
        q=get(g(ii),'holes');
        for jj=1:get(g(ii),'nholes');
            xd=[xd;diff(q(jj).x)];
            yd=[yd;diff(q(jj).y)];
        end
    end

    %paror
    ff=[x y]*nn; 
    fp=(max(ff)-min(ff))';

    %surfor
    ff=[xd yd]*nn;
    if size(ff,1)>1
        fs=(sum(abs(ff)))';
    else
        fs=abs(ff)';
    end 

    if isa(g,'polylxgrain')
        fs=fs/2;
    end
    pa(ii,:)=100*(fs-fp)./fp;
    fwaitbar(ii/n,h);
end
%Calculate bulk PARIS factor
pf=mean(pa,2);
pf(pf<0)=0;
close(h)
