function shp2mat(flist,opt)
%SHP2MAT Routine to convert several shapefiles into MAT-files for fast loading.
%MAT-files are saved in current directory and have a same base
%filename as shapefiles. Grains are stored in variable g and boundaries in
%variable b.
% Syntax: shp2mat(flist,[opt]);
% flist is a filelist prepared by mkflist
%    opt - 0 (default) convert only grains or boundaries.
%          1 assume that shapefiles are grains and automatically generate
%            a boundary using bmake.

% This file is part of polyLX.
% 
% polyLX is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% polyLX is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with polyLX.  If not, see <http://www.gnu.org/licenses/>.

% polyLX - MATLAB toolbox for microstructure analyses
% Copyright (C) 2010 Ondrej Lexa

if nargin<2
    opt=0;
end

if nargin<1
   flist=mkflist;
   if isempty(flist)
       return
   end
end

for i=1:length(flist);
   [g,dummy,fnm]=shpread(flist{i});
   mm=strrep(fnm,'.shp','');
   if isa(g,'polylxgrain')
       if opt==1
           b=bmake(g);
           eval(['save ' mm ' g b']);
           clear g b
       else
           eval(['save ' mm ' g']);
           clear g
       end
   else
       b=g;
       eval(['save ' mm ' b']);
       clear g b
   end
end
