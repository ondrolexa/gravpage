function [rstat,tt]=phist(a,varargin)
%PHIST Plot histogram and calculate statistics.
% Syntax: stat=phist(a,options);
% a could be grain/boundary object, column vector or cell array of column vectors
% for grouped plot. EAD for grain and CumLength for boundary is used by default.
% options are passed as pairs of option name and option value:
% 'scale'      ... 0...counts, 1...percents, 2...probability density. Default 1
% 'nbins'      ... number of bins.
% 'barwidth'   ... bar width. Default 1
% 'axislimits' ... [xmin xmax]. Default limits are minimum and maximum from data
% 'color'      ... its Matlab color style for single plot ot pallete for grouped.
%                  Default is 'b' or selection from jet palette.
% 'xlabel'     ... Label of x axis. Default based on input.
% Output is stat vector or matrix if cell is passed as input with colums
% contain mean, standard deviation, normalized skewness and kurtosis

% This file is part of polyLX.
% 
% polyLX is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% polyLX is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with polyLX.  If not, see <http://www.gnu.org/licenses/>.

% polyLX - MATLAB toolbox for microstructure analyses
% Copyright (C) 2010 Ondrej Lexa

if nargin<1
    help phist;
    return;
end

% when grain object is passed
if isa(a,'polylxgrain')
   a=get(a,'ead');
end 
if isa(a,'polylxboundary')
    a=get(a,'CumLength');
end
% check cell array for grouped plot
if isa(a,'cell')
    ngrp=length(a);
    grp=a;
else
    ngrp=1;
    grp={a};
end

for i=1:ngrp
    %linearize and filter NaN's anf Inf's
    a=grp{i}(:);
    a=a(~isnan(a));
    a=a(~isinf(a));
    poc(i)=size(a,1);
    mini(i)=min(a);
    maxi(i)=max(a);
    % calculate stats
    stat(i,1)=mean(a);
    stat(i,2)=std(a);
    stat(i,3)=mean((a-stat(i,1)).^3)/stat(i,2)^3;
    stat(i,4)=mean((a-stat(i,1)).^4)/stat(i,2)^4;
    wb(i)=3.49*stat(i,2)*poc(i)^(-1/3); %Scott's rule
end

% Process input arguments
opts.axislimits=[min(mini)-0.05*(max(maxi)-min(mini)) max(maxi)+0.05*(max(maxi)-min(mini))];
opts.scale=1;
opts.nbins=ceil((max(maxi)-min(mini))/mean(wb)); %ceil(1+7*log10(mean(poc)));
opts.barwidth=1;
opts.xlabel=inputname(1);
if isempty(opts.xlabel)
    opts.xlabel='x';
end
if ngrp>1
    opts.color=jet(ngrp);
else
    opts.color='b';
end
opts=parseargs(varargin,opts);
% Recalculate nbins, mini and maxi when axislimits specified
for i=1:ngrp
    a=grp{i}(:);
    a=a(~isnan(a));
    a=a(~isinf(a));
    a=a(a>=opts.axislimits(1)&a<=opts.axislimits(2));
    mini(i)=min(a);
    maxi(i)=max(a);
    wb(i)=3.49*std(a)*length(a)^(-1/3); %Scott's rule
end
opts.nbins=ceil((max(maxi)-min(mini))/mean(wb));
opts=parseargs(varargin,opts);

% define bins
h=linspace(opts.axislimits(1),opts.axislimits(2)+10*eps,opts.nbins+1);
binw=(max(maxi)-min(mini))/opts.nbins;

% calculate frequancies
n=[];
for i=1:ngrp
    a=grp{i}(:);
    a=a(~isnan(a));
    a=a(~isinf(a));

    tn=histc(a,h);
    
    switch opts.scale
        case 1
            % recalculate on percents
            tn=100*(tn/poc(i));
        case 2
            tn=tn/poc(i)/binw;
    end
    n=[n tn];
end
hh=bar(h+(h(2)-h(1))/2,n,opts.barwidth,'grouped');
for i=1:ngrp
    set(get(hh(i),'children'),'facecolor',opts.color(i,:));
end

% Correct x limits
ax=axis;
ax(1)=opts.axislimits(1);
ax(2)=opts.axislimits(2);
axis(ax);

switch opts.scale
    case 1
        ylab='Percents';
    case 2
        ylab='Probability density';
    otherwise
        ylab='Counts';
end

for i=1:ngrp
    tt{i}=['No.:' num2str(poc(i)) ' Mean:' num2str(stat(i,1)) ' Std. dev.:' num2str(stat(i,2)) ' Skewness:' num2str(stat(i,3)) ' Kurtosis:' num2str(stat(i,4))];
end 

if nargout>0
    rstat=stat;
end

if nargout<2
    title(tt);
end
    
ylabel(ylab);
xlabel(opts.xlabel);
