function [gsub,bsub]=gcrop(g,opt)
%GCROP Crop subset of grain objects
% Syntax: gsub=gcrop(g);
%         gsub=gcrop(g,opt);
%         [gsub,bsub]=gcrop(g);
%         [gsub,bsub]=gcrop(g,opt);
% opt ... for scalar value manual cropping is used 0...plot
%                                                  1...polygon select
%         for 1x3 vector [m,n,p] grains are cropped by rectangle defined
%                                in same way as subplot
%         for 1x4 vector cropped by rectangle [xmin,xmax,ymin,ymax].

% This file is part of polyLX.
% 
% polyLX is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% polyLX is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with polyLX.  If not, see <http://www.gnu.org/licenses/>.

% polyLX - MATLAB toolbox for microstructure analyses
% Copyright (C) 2010 Ondrej Lexa

if nargin<1
    help gbcrop
    gsub=[];
    bsub=[];
    return
end
if ~isa(g,'polylxgrain')
    help gbcrop
    gsub=[];
    bsub=[];
    return
end


if nargin<2
    opt=1;
end

switch length(opt)
    case 1
        if opt==0
            clf;
            plot(g,'leg',0);
            title('Select grain by mouse and hit any key');
            pause
            ix=getsel;
            gsub=g(ix);
        else
            clf;
            plot(g,'leg',0)
            title('Select grains by polygon');
            [xx,yy] = getline;
            [x,y]=get(g,'xcentre','ycentre');
            gsub=g(inpolygon(x,y,xx,yy));
        end
    case 3
        %geo = acharea(g,[5 6 7 8]);
        [c,r]=ind2sub(opt(2:-1:1),opt(3));
        [x,y]=get(g,'xcentre','ycentre');
        geo = [min(x) max(x) min(y) max(y)];
        gsub=g(x>=geo(1)+(c-1)*(geo(2)-geo(1))/opt(2) & x<=geo(1)+c*(geo(2)-geo(1))/opt(2) & y>=geo(4)-r*(geo(4)-geo(3))/opt(1) & y<=geo(4)-(r-1)*(geo(4)-geo(3))/opt(1));
    case 4
        [x,y]=get(g,'xcentre','ycentre');
        gsub=g(x>=opt(1) & x<=opt(2) & y>=opt(3) & y<=opt(4));
    otherwise
        help gcrop
        error('Wrong cropping option.');
end
if nargout>1
    bsub=bmake(gsub);
end
