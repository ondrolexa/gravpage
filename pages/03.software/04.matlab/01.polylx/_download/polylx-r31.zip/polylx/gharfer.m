function [gn,mm,rf]=gharfer(g,varargin)
%GHARFER Return ellipse fitting based on Harvey & Ferguson method
% Based on grain directional properties after Harvey & Ferguson (1981, Tectonophysics 74:T33-T42)
% and Harvey (1981, Computers & Geosciences 7:387-392)
% Syntax: gn=gharfer(g,options);
%         [gn,mm,rf]=gharfer(g,options);
% g must be grain object(s)
% gn are grains objects with calculated properties la,sa,lao,sao
% mm is bulk mean matrix of inertia
% rf is square root of eigenvalues ratio for each grain
% options are passed as pairs of option name and option value:
% 'res'      ... resolution i.e. number of vertexes Default 91.
%                res 5 is enough to get la,sa,lao,sao

% This file is part of polyLX.
% 
% polyLX is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% polyLX is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with polyLX.  If not, see <http://www.gnu.org/licenses/>.

% polyLX - MATLAB toolbox for microstructure analyses
% Copyright (C) 2010 Ondrej Lexa

if nargin<1
    help gharfer
    gn=[];
    mm=[];
    rf=[];
    return
end
if ~isa(g,'polylxgrain')
    help gharfer
    gn=[];
    mm=[];
    rf=[];
    return
end

% Process input arguments
opts.res=91;
opts=parseargs(varargin,opts);
if opts.res<5
    opts.res=5;
end

%Initialize
n=length(g);
mm=[0 0;0 0];
rf=[];
gn=repmat(polylxgrain,1,n);
the=linspace(0,360,opts.res)';

% Create convex hull (technique need convex polygon)
g=gconvhull(g);

h=fwaitbar(0,'Calculating...');

for ii=1:n
    [x,y]=get(g(ii),'x','y');
    x=x(1:end-1);
    y=y(1:end-1);
    poc=length(x);

    % shift to centre
    xc=get(g(ii),'xcentre');
    yc=get(g(ii),'ycentre');
    x=x-xc;
    y=y-yc; 

    % Calculate point and area functions
    ix=1:poc; ixp=[2:poc 1]; z=zeros(1,poc);
    ftn=polyarea([x([ix;ixp]);z],[y([ix;ixp]);z])/3;
    xptn=sum(x([ix;ixp]))/2;
    yptn=sum(y([ix;ixp]))/2;
    ftp=sum(ftn([ix;ixp]));
    xptp=x(ixp)/2;
    yptp=y(ixp)/2;
    f=[ftn;ftp]; f=f(:);
    xp=[xptn;xptp']; xp=xp(:);
    yp=[yptn;yptp']; yp=yp(:);

    % Calculate inertia matrix
    j=1:2*poc;
    totarea = sum(f);
    uxx=sum(f(j).*xp(j).^2);
    uyy=sum(f(j).*yp(j).^2);
    uxy = sum(f(j).*xp(j).*yp(j));

    m = [uxx uxy;...
         uxy uyy]./(2*poc);

    mm = mm + m; % add to mean matrix

    % Calculate eigenvalues and eigenvectors
    [v,c]=eig(m);
    if c(1,1)<c(2,2)  % Sort eigenvalues and eigenvectors
        c=rot90(c,2);
        v=fliplr(v);
    end

    r = sqrt(c(1,1)/c(2,2)); % square root of eigenvalues ratio
    ra = sqrt(totarea*r/pi); rb = ra / r; % Long axis and Short axis scaled on totalarea
    oa = atan2(v(1,1),v(2,1));  ob = atan2(v(1,2),v(2,2)); % orientation

    rf=[rf;r];
    co=cos(oa);
    si=sin(oa);
    x=si*cosd(the)*ra+co*sind(the)*rb+xc;
    y=co*cosd(the)*ra-si*sind(the)*rb+yc;
    gn(ii)=polylxgrain(get(g(ii),'id'),...
                       get(g(ii),'phase'),...
                       x,...
                       y,...
                       get(g(ii),'userdata'));
    fwaitbar(ii/n,h);
end

close(h)
mm=mm/poc; % weighted mean matrix
