function [azi,dip,r,g,b]=schmidtgrid(poc,varargin)
%SCHMIDTGRID Return arrays and rgp to plot schmidtnet lookup table
% Syntax [azi,dip,r,g,b]=schmidtgrid(resolution, [options]);
%    res ... resolution. Default 100
% See help azidip2color for options

% This file is part of polyLX.
% 
% polyLX is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% polyLX is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with polyLX.  If not, see <http://www.gnu.org/licenses/>.

% polyLX - MATLAB toolbox for microstructure analyses
% Copyright (C) 2010 Ondrej Lexa

opts.axial=0;
opts.lut='cip';
opts=parseargs(varargin,opts);

if nargin<1
    poc = 100;
end
[x,y] = meshgrid(linspace(-1,1,poc),linspace(-1,1,poc));
azi = nan(size(x));
dip = nan(size(x));
x2 = x.^2;
y2 = y.^2;
dr = atan2(x,y);
dr(dr<0) = dr(dr<0)+2*pi;
d = sqrt(x2+y2);
dp = asin(d/sqrt(2));
azi(d<=1) = dr(d<=1)*180/pi;
dip(d<=1) = 90-2*dp(d<=1)*180/pi;
azi = flipud(azi);
if nargout>4
    [r,g,b] = azidip2color(azi,dip,'axial',opts.axial,'lut',opts.lut);
end

