function stat=prosew(a,w,varargin)
%PROSEW Draw a weighted rose diagram and calculate circular statistics.
% Syntax: stat=prosew(a,w,options) or prosew(g,w,options);
% return mean direction and circular standartd deviation
%  a    - vector of orientations or grain/boundary object
%  w    - vector of weights for data. Must have same size as data.
% options are passed as pairs of option name and option value:
% 'axial'  ... 1 - axial data, 0 - circular. Default 1
% 'apex'   ... acuteness of bar tip 0-1. Default 0.95
% 'nbins'  ... number of bins. Default 36
% 'color'  ... Matlab plot style
% 'align'  ... 0...zero aligned, 0...bin centre aligned. Default 0
% 'prop'   ... 0...length proportional 1...area proportional. Default 1
% 'view'   ... 0...zero vertical, 1...zero horizontal. Default 0
% 'stat'   ... 1...plot meen direction and deviation 0...no plot. Default 1
% Output is stat vector of mean direction, circular standard deviation and
% circular variance, Rayleigh's uniformity test p-value a critical value

% This file is part of polyLX.
% 
% polyLX is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% polyLX is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with polyLX.  If not, see <http://www.gnu.org/licenses/>.

% polyLX - MATLAB toolbox for microstructure analyses
% Copyright (C) 2010 Ondrej Lexa

if nargin<1
    help prosew
    return
end

if nargin<2
    if isa(a,'polylxgrain');
        w=get(a,'ead');
    elseif isa(a,'polylxboundary')
        w=get(a,'cumlength');
    else
        help prosew
        return
    end
end

if nargin>1&&isa(w,'char')
    varargin=[w varargin];
    if isa(a,'polylxgrain');
        w=get(a,'ead');
    elseif isa(a,'polylxboundary')
        w=get(a,'cumlength');
    else
        help prosew
        return
    end
end 

% when grain object is passed
if isa(a,'polylxgrain')||isa(a,'polylxboundary')
   a=get(a,'Orientation');
end

% initialize defaults and parse arguments
opts.axial=1;
opts.apex=0.95;
opts.nbins=36;
opts.color='b';
opts.align=0;
opts.prop=1;
opts.view=0;
opts.stat=1;
opts=parseargs(varargin,opts);

%linearize, filter NaN's and inf's and modulate
a=a(:);
w=w(:);
ix=~isnan(a);
a=a(ix);
w=w(ix);
ix=~isinf(a);
a=a(ix);
w=w(ix);
if opts.view==1
    a=mod(a+90,180);
end
if opts.axial==1
    a=mod(a,180);
    tit='Weighted axial data';
else
    a=mod(a,360);
    tit='Weighted circular data';
end

% take first column of data
poc=size(a,1);

if opts.axial==1
   ah=[a;a+180];
   aw=[w;w];
   a=2*a;
else
   ah=a;
   aw=w;
end

binw=360/opts.nbins;
if opts.align==1
    bns=0:binw:360;
    [t,ixb]=histc(ah,bns);
    t=t(1:end-1);
else
    bns=0-binw/2:binw:360+binw/2;
    [t,ixb]=histc(ah,bns);
    t(1)=t(1)+t(end-1);
    ixb(ixb==length(t)-1)=1;
    t=t(1:end-2);
end

% Apply weigths
for j=1:opts.nbins
    t(j)=sum(aw(ixb==j));
end

if opts.prop==1
    t=sqrt(t);
end

tn=[];
rn=[];

for i=1:opts.nbins
    tn=[tn 0 rad(bns(i)) rad((bns(i)+bns(i+1))/2) rad(bns(i+1)) 0];
    rn=[rn 0 opts.apex*t(i) t(i) opts.apex*t(i) 0];
end

polar(tn,rn);
[x,y]=pol2cart(tn,rn);
patch(x,y,opts.color);

% Calculate resultant and circular statistics
rr=(1-w/sum(w))'*exp(1i*rad(a));
md=mod(deg(atan2(imag(rr),real(rr))),360);
R=abs(rr)/length(a); % normalized resultant
s=deg(sqrt(log(1/R^2))); % circular deviation
cv=1-R; % circular variance
if opts.axial==1
    md=md/2;
    s=s/2;
end
Z=poc*R^2;
p=exp(-Z);
if poc<50
    p = p*(1+(2*Z-Z^2)/(4*poc)-(24*Z-132*Z^2+76*Z^3-9*Z^4)/(288*poc^2));
end
stat=[md s cv p Z];

if opts.view==1
    view(0,-90);
    xlabel([tit ' rose plot - MD:' num2str(md) ' CSD:' num2str(s) ' CV: ' num2str(cv) ' p: ' num2str(p) ' Z: ' num2str(Z)]);
    ylabel('Cumulative weight')
else
    view(90,-90);
    ylabel([tit ' rose plot - MD:' num2str(md) ' CSD:' num2str(s) ' CV: ' num2str(cv) ' p: ' num2str(p) ' Z: ' num2str(Z)]);
    xlabel('Cumulative weight')
end

% get radius of plot
ar=get(gca,'PlotBoxAspectRatio');
ar=ar(1)/ar(3);

if opts.stat==1
    % draw CSD part
    dd=linspace(md-s,md+s,18);
    xc=cos(rad(dd))*ar;
    yc=sin(rad(dd))*ar;
    h3=line(xc,yc);
    set(h3,'LineWidth',3,'Color','r');
    if opts.axial==1
        h4=line(-xc,-yc);
        set(h4,'LineWidth',3,'Color','r');
    end
    % draw mean direction
    x=cos(rad(md))*ar;
    y=sin(rad(md))*ar;
    if opts.axial==1
        h5=line([x;-x],[y;-y]);
        set(h5,'LineWidth',2,'Color','r');
    else
        h5=line([x;0],[y;0]);
        set(h5,'LineWidth',2,'Color','r');
    end
end
