function dbwrite(g,sample,label,x,y)
%DBWRITE Write grain object into database.
% Syntax:  dbwrite(g);
%          dbwrite(g,sample);

% This file is part of polyLX.
% 
% polyLX is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% polyLX is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with polyLX.  If not, see <http://www.gnu.org/licenses/>.

% polyLX - MATLAB toolbox for microstructure analyses
% Copyright (C) 2010 Ondrej Lexa

global polylx_prefs
% Check input
if nargin<4
    x=0;
    y=0;
end
if nargin<2
    sample=[];
end
if nargin<1
    help dbwrite
    return
end
if ~isa(g,'polylxgrain')
    error('The first argument of DBWRITE must be a grain object. Aborting.');
end

%Check connection
if dbconnect
    if isempty(sample)
        answer=inputdlg('Input name for sample:','Name');
        if isempty(answer)
            dbclose
            return
        end
        sample=answer{1};
        sample=strrep(sample,'-','');
    else
        sample=strrep(sample,'-','');
    end
    if nargin<3
        label=sample;
    end
    % check sample list
    res=dbcommand(['SELECT name FROM samples WHERE name=''' sample '''']);
    if ~isempty(res)
        disp('Sample already exists. To list all samples try command dblist. Aborting...')
        dbclose
        return
    end

    % get sample id
    dbcommand('BEGIN TRANSACTION');
    dbcommand(['INSERT INTO samples (name,label,X,Y) VALUES ("' sample '","' label '",' num2str(x) ',' num2str(y) ')']);
    dbcommand('COMMIT');
    res=dbcommand(['SELECT id FROM samples WHERE name="' sample '"']);
    id_sample=res.id;

    poc=length(g);
    if strcmpi(polylx_prefs.driver,'SQlite3')
        h=fwaitbar(0,'Writing grains into database...');
        dbcommand('BEGIN TRANSACTION');
        for i=1:poc
            dbcmd=['INSERT INTO grains (id_sample,id_grain,phase,X,Y) VALUES (' num2str(id_sample) ',' num2str(get(g(i),'id')) ',"' char(get(g(i),'phase')) '","' get(g(i),'xhex') '","' get(g(i),'yhex') '")'];
            dbcommand(dbcmd);
            fwaitbar(i/poc,h);
        end
        dbcommand('COMMIT');
        close(h)
    else
        h=fwaitbar(0,'Writing grains into database...');
        for i=1:poc
            dbcmd=['INSERT INTO grains (id_sample,id_grain,phase,geometry) VALUES (' num2str(id_sample) ',' num2str(get(g(i),'id')) ',"' char(get(g(i),'phase')) '",PolygonFromText(''' get(g(i),'wkt') '''))'];
            dbcommand(dbcmd);
            fwaitbar(i/poc,h);
        end
        close(h)
    end

    b=bmake(g);

    poc=length(b);
    if strcmpi(polylx_prefs.driver,'SQlite3')
        h=fwaitbar(0,'Writing boundaries into database...');
        dbcommand('BEGIN TRANSACTION');
        for i=1:poc
            dbcmd=['INSERT INTO boundaries (id_sample,id_boundary,id_graina,id_grainb,phasea,phaseb,X,Y) VALUES (' num2str(id_sample) ',' num2str(get(b(i),'id')) ',' num2str(get(b(i),'ixa')) ',' num2str(get(b(i),'ixb')) ',"' char(get(b(i),'phasea')) '","' char(get(b(i),'phaseb')) '","' get(b(i),'xhex') '","' get(b(i),'yhex') '")'];
            dbcommand(dbcmd);
            fwaitbar(i/poc,h);
        end
        dbcommand('COMMIT');
        close(h)
    else
        h=fwaitbar(0,'Writing boundaries into database...');
        for i=1:poc
            dbcmd=['INSERT INTO boundaries (id_sample,id_boundary,id_graina,id_grainb,phasea,phaseb,geometry) VALUES (' num2str(id_sample) ',' num2str(get(b(i),'id')) ',' num2str(get(b(i),'ixa')) ',' num2str(get(b(i),'ixb')) ',"' char(get(b(i),'phasea')) '","' char(get(b(i),'phaseb')) '",LineStringFromText(''' get(b(i),'wkt') '''))'];
            dbcommand(dbcmd);
            fwaitbar(i/poc,h);
        end
        close(h)
    end
    dbclose;
end
