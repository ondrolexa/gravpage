function pproj(pd,varargin)
%PPROJ Plot projection function of PAROR, SURFOR and PARIS analyses.
% Syntax: pproj(pd,options);
% pd if projection matrix. It is output of gparor, gsurfor or aparis
% options are passed as pairs of option name and option value:
% 'norm'      ... 0..not normalized 1..normalized. Default 0.
% 'separate'  ... 0..mean 1..separate individual projections. Default 0.

% This file is part of polyLX.
% 
% polyLX is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% polyLX is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with polyLX.  If not, see <http://www.gnu.org/licenses/>.

% polyLX - MATLAB toolbox for microstructure analyses
% Copyright (C) 2010 Ondrej Lexa

if nargin<1
    help pproj
    return;
end

if size(pd,2)~=180
    help pproj
    return;
end

% Process input arguments
opts.norm=0;
opts.separate=0;
opts=parseargs(varargin,opts);

pd=[pd(:,end) pd];
ang=0:180;

% Normalize
if opts.norm
    pd=pd./repmat(max(pd,[],2),1,181);
end

if opts.separate
    plot(ang,pd,'color','k')
else
    mpd=mean(pd);
    plot(ang,mpd,'color','k')
    title(sprintf('Max:%f Min:%f Diff:%f',max(mpd),min(mpd),max(mpd)-min(mpd)))
end
