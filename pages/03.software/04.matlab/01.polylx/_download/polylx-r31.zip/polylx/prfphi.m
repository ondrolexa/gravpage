function tt=prfphi(ar,ang,varargin)
%PRFPHI Make Rf/phi plot.
% Syntax: prfphi(ar,ang,options) or prfphi(g,options);
%  ar   - axial ratios Rf or grain/boundary object.
%  ang  - axes orientations phi
% options are passed as pairs of option name and option value:
% 'rs'         ... strain ratio for Ri and theta curves. Default 1 (no plot)
% 'mdang'      ... Angle of principal strain axis. Default auto
% 'rfmax'      ... where n is upper limit of plot. Default auto
% 'gauss'      ... 1...plot density estimate using Gaussian density kernel estimate
%                      and rfmax estimate. Default 0 (none)
% 'contour'    ... 1...plot density contours. Default 0 (none)
% 'ncont'      ... number of contours
% 'pointsize'  ... point size. Default 6
% 'pointcolor' ... point color and style. Default 'b.'
% 'linewidth'  ... width of density line. Default 2
% 'linecolor'  ... color of density line. Default 'r'
% 'colormap'   ... colormap for contours. Default bone

% This file is part of polyLX.
% 
% polyLX is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% polyLX is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with polyLX.  If not, see <http://www.gnu.org/licenses/>.

% polyLX - MATLAB toolbox for microstructure analyses
% Copyright (C) 2010 Ondrej Lexa

if nargin<1
    help prfphi
    return
end

% when grain object is passed
if isa(ar,'polylxgrain')||isa(ar,'polylxboundary')
    if nargin>1
        varargin=[{ang} varargin];
    end
    g=ar;
    ar=get(g,'AxialRatio');
    ix=~isnan(ar);
    ar=ar(ix);
    ang=get(g,'Orientation');
    ang=ang(ix);
end

if ~exist('ang')
    help prfphi
    return
end

% initialize defaults and parse arguments
opts.rs=0;
opts.mdang=[];
opts.rfmax=exp(mean(log(ar))+3*std(log(ar)));
opts.ncont=10;
opts.pointsize=6;
opts.pointcolor='b.';
opts.linewidth=2;
opts.linecolor='r';
opts.colormap=bone;
opts.gauss=0;
opts.contour=0;
opts=parseargs(varargin,opts);

%waste NaN's
ix=~isnan(ang);
ang=ang(ix);
ar=ar(ix);
ix=~isnan(ar);
ang=ang(ix);
ar=ar(ix);

ang=ang(:);
ar=ar(:);

%Calculate vector mean
xr=sum(sin(rad(2*ang)));
yr=sum(cos(rad(2*ang)));
if isempty(opts.mdang)
    mdang=deg(atan2(xr,yr))/2;    % mean direction
    if mdang<0
        mdang=mdang+180;
    end
else
    mdang=opts.mdang;
end
sang=deg(sqrt(log(1/(sqrt(xr^2+yr^2)/length(ang))^2)))/2; % circular standard deviation
rfmean=length(ar)/sum(1./ar);

ang=ang-mdang;
ixxx=find(ang>90);
ang(ixxx)=ang(ixxx)-180;
ixxx=find(ang<-90);
ang(ixxx)=ang(ixxx)+180;
na=length(find((ang<0)&ar>rfmean));
nb=length(find((ang>0)&ar>rfmean));
nc=length(find((ang<0)&ar<rfmean));
nd=length(find((ang>0)&ar<rfmean));
isym=1-(abs(na-nb)+abs(nc-nd))/length(ang);

ang=[ang-180;ang;ang+180];
ar=[ar;ar;ar];

cla

% Contours
if opts.contour~=0
    %Calculate density grid
    [xodp,yodp,dg]=dengrid(ang,log(ar),2,30,10,-180,360,0,log(1.1*opts.rfmax));
    contourf(xodp+mdang,exp(yodp),dg,opts.ncont);
    colormap(flipud(opts.colormap));
    colorbar;
    hold on;
end

% Gauss density
if opts.gauss~=0
    n=length(ang);
    h = 1.06 * std(ang) * n^(-1/5);
    mn1 = -180;
    mx1 = 360;
    mn = mn1 - (mx1-mn1)/3;
    mx = mx1 + (mx1-mn1)/3;
    gridsize = 256;
    xx = linspace(mn,mx,gridsize)';
    d = xx(2) - xx(1);
    xh = zeros(size(xx));
    xa = (ang-mn)/(mx-mn)*gridsize;
    for i=1:n
        il = floor(xa(i));
        a  = xa(i) - il;
        xh(il+[1 2]) = xh(il+[1 2])+[1-a, a]';
    end
    % --- Compute -------------------------------------------------
    xk = (-gridsize:gridsize-1)'*d;
    K = exp(-0.5*(xk/h).^2);
    K = K / (sum(K)*d*n);
    f = ifft(fft(fftshift(K)).*fft([xh ;zeros(size(xh))]));
    f = real(f(1:gridsize));
    % --- Plot it -------------------------------------------------
    mm=min(opts.rfmax,max(ar));
    d = (0.8*(mm-1))/max(f);
    h1=plot(xx+mdang,d*f+1,opts.linecolor);
    set(h1,'LineWidth',opts.linewidth);
    hold on;
    %plot(0:180,maxrf,'m.-');
end

% Ri and Theta curves
if opts.rs>1
    cc=hsv(8);
    hold on
    ri=round(logspace(0.001,log10(opts.rfmax/opts.rs),8)*100)/100;
    for ii=1:8
        rf=linspace(1.01,opts.rs*ri(ii),500);
        tt=0.5*acos((cosh(log(rf))*cosh(log(opts.rs))-cosh(log(ri(ii))))./(sinh(log(rf))*sinh(log(opts.rs))));
        tt=real(tt);
        hh=plot(mdang+tt*180/pi,rf,mdang-tt*180/pi,rf);
        set(hh,'color',cc(ii,:));
        h1(ii)=hh(1);
        leg(ii)={['Ri:' num2str(ri(ii))]};
    end

    theta=10:10:80;
    for ii=1:8;
        phi=linspace(0,theta(ii),500)*pi/180;
        tt=theta(ii)*pi/180;
        rf=((tan(2*tt)*(opts.rs^2-tan(phi).^2)-2*opts.rs*tan(phi))./(tan(2*tt)*(1-opts.rs^2*tan(phi).^2)-2*opts.rs*tan(phi))).^0.5;
        rf(rf<1)=exp(6);
        hh=plot(mdang+phi*180/pi,rf,mdang-phi*180/pi,rf);
        set(hh,'color',cc(ii,:));
        leg(ii)={[leg{ii} ' Theta:' num2str(theta(ii))]};
    end
    legend(h1,leg)
end

h1=plot(ang+mdang,ar,opts.pointcolor);
set(h1,'MarkerSize',opts.pointsize);
axis([mdang-90 mdang+90 1 opts.rfmax]);
xlabel('Orientation');
ylabel('Axial ratio');
if nargout<1
    title(['Theta:' num2str(mdang) ' F:' num2str(4*sang) ' Rfmean:' num2str(rfmean) ' Isym:' num2str(isym)]);
else
    tt=['Theta:' num2str(mdang) ' F:' num2str(4*sang) ' Rfmean:' num2str(rfmean) ' Isym:' num2str(isym)];
end
set(gca,'TickDir','out')
set(gca,'YScale','log');
%set(gca,'YTick',linspace(1,opts.rfmax,10))
set(gca,'YTick',round(100*logspace(0,log10(opts.rfmax),15))/100)
set(gca,'YMinorTick','off')
%set(gca,'YGrid','on')
hold off
