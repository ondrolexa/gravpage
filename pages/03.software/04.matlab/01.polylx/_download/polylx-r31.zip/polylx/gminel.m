function gn=gminel(g,varargin)
%GMINEL Finds the minimum volume enclosing ellipse (MVEE) for grain or boundary
% Syntax: gn=gminel(g,options);
% g can be grain object(s)
% gn are grains objects representing minimum volume ellipse.
% options are passed as pairs of option name and option value:
% 'tol'  ... tolerance Default mean(LENGTH)/10000.
% 'res'      ... resolution i.e. number of vertexes Default 91.
%                res 5 is enough to get la,sa,lao,sao

% The solver is based on Khachiyan Algorithm and modiefied after
% Nima Moshtagh (nima@seas.upenn.edu)
% University of Pennsylvania
% http://www.mathworks.com/matlabcentral/fileexchange/9542

% This file is part of polyLX.
% 
% polyLX is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% polyLX is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with polyLX.  If not, see <http://www.gnu.org/licenses/>.

% polyLX - MATLAB toolbox for microstructure analyses
% Copyright (C) 2010 Ondrej Lexa

if nargin<1
    help gminel
    gn=[];
    return
end
if ~isa(g,'polylxgrain')
    help gminel
    gn=[];
    return
end


% Process input arguments
opts.tol=mean(get(g,'length'))/50000;
opts.res=91;
opts=parseargs(varargin,opts);
if opts.res<5
    opts.res=5;
end

%Initialize
n=length(g);
gn=repmat(polylxgrain,1,n);
the=linspace(0,360,opts.res)';

h=fwaitbar(0,'Calculating...');

for ii=1:n
    [x,y]=get(g(ii),'x','y');
    ix=convhull(x,y);
    x=x(ix(1:end-1));
    y=y(ix(1:end-1));
    P=[x';y'];
    N=length(x);
    Q=[P;ones(1,N)];
    count=1;
    err=1;
    u=(1/N)*ones(N,1);          % 1st iteration
    tolerance=opts.tol;
    % Khachiyan Algorithm
    % -----------------------------------
    it=0;
    while (err>tolerance)&&(it<10000) % to be safe
        X=Q*diag(u)*Q';       % X = \sum_i ( u_i * q_i * q_i')  is a (d+1)x(d+1) matrix
        M=diag(Q'*inv(X)*Q);  % M the diagonal vector of an NxN matrix
        [maximum j]=max(M);
        step_size=(maximum-3)/(3*(maximum-1));
        new_u=(1-step_size)*u ;
        new_u(j)=new_u(j)+step_size;
        count=count+1;
        err=norm(new_u - u);
        u=new_u;
        it=it+1;
    end
    U=diag(u);
    A=0.5*inv(P*U*P'-(P*u)*(P*u)');
    c=u'*P';
    [e1,e2]=eig(A);
    lao=atan(e1(1,1)/e1(2,1));
    co=cos(lao);
    si=sin(lao);
    x=si*cosd(the)/sqrt(e2(1,1))+co*sind(the)/sqrt(e2(2,2))+c(1);
    y=co*cosd(the)/sqrt(e2(1,1))-si*sind(the)/sqrt(e2(2,2))+c(2);
    gn(ii)=polylxgrain(get(g(ii),'id'),...
                       get(g(ii),'phase'),...
                       x,...
                       y,...
                       get(g(ii),'userdata'));
    fwaitbar(ii/n,h);
end
close(h)
