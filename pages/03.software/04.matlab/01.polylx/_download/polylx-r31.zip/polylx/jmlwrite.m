function jmlwrite(g,varargin)
%JMLWRITE Write geometry to JUMP GML file.
% Syntax:  jmlwrite(g)
%          jmlwrite(g,filename);

% This file is part of polyLX.
% 
% polyLX is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% polyLX is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with polyLX.  If not, see <http://www.gnu.org/licenses/>.

% polyLX - MATLAB toolbox for microstructure analyses
% Copyright (C) 2010 Ondrej Lexa

% GUI open file
if isempty(varargin)
    [fnm, pth]=uiputfile({'*.jml','JUMP GML (*.jml)'},'Save JUMP GML file');
    if fnm==0
        g=[]; pth=[]; fnm=[];
        return
    end
    filename=[pth fnm];
else
    filename=varargin{1};
    ix=find(filename=='\');
    if isempty(ix);
        ix=0;
    end
    fnm=filename(ix(end)+1:end);
    pth=filename(1:ix(end));
end
% Write the JML file header
fid = fopen(filename,'w');
if (fid==-1) 
	error(sprintf('Cannot open %s for reading.',filename))
end
fprintf(fid,'<?xml version=''1.0'' encoding=''UTF-8''?>\n');
fprintf(fid,'<JCSDataFile xmlns:gml="http://www.opengis.net/gml" xmlns:xsi="http://www.w3.org/2000/10/XMLSchema-instance" >\n');
fprintf(fid,'<JCSGMLInputTemplate>\n');
fprintf(fid,'<CollectionElement>featureCollection</CollectionElement>\n');
fprintf(fid,'<FeatureElement>feature</FeatureElement>\n');
fprintf(fid,'<GeometryElement>geometry</GeometryElement>\n');
fprintf(fid,'<ColumnDefinitions>\n');
fprintf(fid,'     <column>\n');
fprintf(fid,'          <name>ID</name>\n');
fprintf(fid,'          <type>INTEGER</type>\n');
fprintf(fid,'          <valueElement elementName="property" attributeName="name" attributeValue="ID"/>\n');
fprintf(fid,'          <valueLocation position="body"/>\n');
fprintf(fid,'     </column>\n');
fprintf(fid,'     <column>\n');
fprintf(fid,'          <name>PHASE</name>\n');
fprintf(fid,'          <type>STRING</type>\n');
fprintf(fid,'          <valueElement elementName="property" attributeName="name" attributeValue="PHASE"/>\n');
fprintf(fid,'          <valueLocation position="body"/>\n');
fprintf(fid,'     </column>\n');
fprintf(fid,'</ColumnDefinitions>\n');
fprintf(fid,'</JCSGMLInputTemplate>\n');

fprintf(fid,'<featureCollection>\n');
for i=1:length(g)
    [x,y] = get(g(i),'x','y');
    coords = sprintf('%f,%f\n',[x y]');
    fprintf(fid,'     <feature>\n');
    fprintf(fid,'          <geometry>\n');
    fprintf(fid,'               <gml:Polygon>\n');
    fprintf(fid,'                    <gml:outerBoundaryIs>\n');
    fprintf(fid,'                    <gml:LinearRing>\n');
    fprintf(fid,'                         <gml:coordinates>');
    fprintf(fid,coords(1:end-1));
    fprintf(fid,'</gml:coordinates>\n');
    fprintf(fid,'                    </gml:LinearRing>\n');
    fprintf(fid,'                    </gml:outerBoundaryIs>\n');
    hh = get(g(i),'holes');
    for j = 1:get(g(i),'NHoles')
        fprintf(fid,'                    <gml:innerBoundaryIs>\n');
        fprintf(fid,'                    <gml:LinearRing>\n');
        fprintf(fid,'                         <gml:coordinates>\n');
        coords = sprintf('%f,%f\n',[hh(j).x hh(j).y]');
        fprintf(fid,coords(1:end-1));
        fprintf(fid,'</gml:coordinates>\n');
        fprintf(fid,'                    </gml:LinearRing>\n');
        fprintf(fid,'                    </gml:innerBoundaryIs>\n');
    end
    fprintf(fid,'               </gml:Polygon>\n');
    fprintf(fid,'          </geometry>\n');
    fprintf(fid,'          <property name="ID">%d</property>\n',get(g(i),'id'));
    fprintf(fid,'          <property name="PHASE">%s</property>\n',char(get(g(i),'phase')));
    fprintf(fid,'     </feature>\n');
end

fprintf(fid,'</featureCollection>\n');
fprintf(fid,'</JCSDataFile>\n');
fclose(fid);
