function [mu,sig]=pgsize(g,varargin)
%PGSIZE Routine to plot grain size (EAD/feret) histogram with area fraction histogram.
% Syntax: pgsize(g,options);
%   g   - grain objects
% options are string evaluated by function (these are default values):
% 'prop'       ... property of grains. Default 'EAD'
% 'confidence'  ... 1..plot confidence lines, 0...none Default 1
% 'xlabels'     ... 0...Log10 values, 1...normal values. Default 0

% This file is part of polyLX.
% 
% polyLX is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% polyLX is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with polyLX.  If not, see <http://www.gnu.org/licenses/>.

% polyLX - MATLAB toolbox for microstructure analyses
% Copyright (C) 2010 Ondrej Lexa

if ~isa(g,'polylxgrain')
    disp('This routine works only with grain objects');
    help pgsize
    return
end

%parse input
opts.prop='EAD';
opts.xlabels=0;
opts.confidence=1;
opts=parseargs(varargin,opts);

poc=length(g);

nb=ceil(1+7*log10(poc));
f=log10(get(g,opts.prop));
a=get(g,'area');
tota=sum(a)/100;

w=(max(f)-min(f))/(nb-1);
ed=linspace(min(f)-w/2,max(f)+w/2,nb+1);
ec=linspace(min(f),max(f),nb);

[n,ix]=histc(f,ed);
n=100*n(1:end-1)/poc;
ca=[];
for j=1:length(n)
    ca=[ca;sum(a(ix==j))/tota];
end
% estimate statistics for area fraction
mut=ec*ca/sum(ca);
sigt=sqrt((((ec-mut).^2)*ca)/sum(ca));
if nargout>1
    mu=mut;
    sig=sigt;
end
%plot
bar(ec,[n ca],1.5);
%xlabels
if opts.xlabels==1
    set(gca,'xticklabel',num2str(10.^get(gca,'xtick')','%.2f'))
    xlabel(['Grain size (' opts.prop ')']);
else
    xlabel(['Log10 grain size (' opts.prop ')']);
end
ylabel('%');
%confidence intervals
if opts.confidence==1
    ax=axis;
    hk=line([mut-sigt mut mut+sigt;mut-sigt mut mut+sigt],[0 0 0;ax(4) ax(4) ax(4)]);
    set(hk,'color','k');
end
title(sprintf('%d grains. %s %f +/-1 sigma range of AF: %f-%f',poc,opts.prop,10^mut,10^(mut-sigt),10^(mut+sigt)));
legend({[opts.prop ' frequency'] 'Area fraction'},'Location','NorthWest')
