function [exn,obn]=cameth(g,b,varargin)
%CAMETH Direct Contact area method (Kretz 1969).
% This is combination of contact frequency and contact length methods.
% Syntax:  [exn,obn]=cameth(g,b,options);
%   exn - cell array of expected values from random distribution
%   obn - cell array of observed values
% options are passed as pairs of option name and option value:
% 'plot'       ... 0...do not plot, 1...plot. Default 1
% 'select'     ... 0...all phases, 1... manually select phases. Default 0
% 'format'     ... 'cell'...return cell arrays ready for txtwrite. Other
%                  numeric arrays. Default 'cell'

% This file is part of polyLX.
% 
% polyLX is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% polyLX is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with polyLX.  If not, see <http://www.gnu.org/licenses/>.

% polyLX - MATLAB toolbox for microstructure analyses
% Copyright (C) 2010 Ondrej Lexa

if nargin<2
   help cameth
   return
end

% Process input arguments
opts.plot=1;
opts.select=0;
opts.format='cell';
opts=parseargs(varargin,opts);

% obtain phase list and number of phases
phlist=gplist(g);
pf=length(phlist);

% Calculate observed frequencies table
obt1=zeros(pf,pf);
for i=1:pf
    for j=i:pf
        hl=length(b([phlist{i} '-' phlist{j}]))/2;
        obt1(j,i)=obt1(j,i)+hl;
        obt1(i,j)=obt1(i,j)+hl;
    end
end

%Normalize
obt1=obt1/sum(sum(obt1));

% Calculate probability table for randomness distribution
expn1=sum(obt1)'*sum(obt1); % double outer product

% Calculate area fractions
totarea=sum(get(g,'area'));
af=zeros(pf,1);
for i=1:pf
    af(i)=sum(get(g(phlist{i}),'area'))/totarea;
end

% Calculate probability table for randomness distribution
% (diagonals are af^2, outdiagonals are 2*af(i)*af(j)
expn2=2*af*af'; % double outer product
expn2=expn2-diag(diag(expn2)/2); % half of diagonals

% Calculate total length and expected length table
totlength=sum(get(b,'cumlength'));

% Calculate observed lengths table
obt2=zeros(pf,pf);
for i=1:pf
    for j=i:pf
        obt2(j,i)=sum(get(b([phlist{i} '-' phlist{j}]),'cumlength'));
        obt2(i,j)=obt2(j,i);
    end
end

%Normalize
obt2=obt2/totlength;

obt=obt2.*(2*obt1-diag(diag(obt1)));
expn=expn2.*(2*expn1-diag(diag(expn1)));
obn=tril(obt);
exn=tril(expn);

if strcmpi(opts.format,'cell')
    exn=[{'Expected'} gplist(g)' ; [gplist(g) num2cell(exn)]];
    obn=[{'Obtained'} gplist(g)' ; [gplist(g) num2cell(obn)]];
end

% % Calculate chi-square value
% if exist('chi2cdf','file')==2
%     chis=sum(sum(tril(((obt-expn).^2)./expn)));
%     pp=chi2cdf(chis,pf*(pf+1)/2-1);
%     if pp>0.5
%         disp(['Contacts are not randomly distributed at significance level ' num2str(pp*100)]);
%     else
%         disp(['Contacts are randomly distributed at significance level ' num2str(100-pp*100)]);
%     end
% end

if opts.plot
    if opts.select
        phx=listdlg('ListString',phlist,'Name','Choose Type(s)','ListSize',[150 200],'CancelString','Exit');
        if isempty(phx)
            return
        end
    else
        phx=1:length(phlist);
    end
    % plot histogram
    obt1=obt(phx,phx);
    expn1=expn(phx,phx);
    obt2=[];
    expn2=[];
    names=[];
    cla;
    hold on
    for i=1:length(phx)
        for j=i:length(phx)
            names=strvcat(names,[phlist{phx(i)} '-' phlist{phx(j)}]);
            obt2=[obt2;obt1(j,i)];
            expn2=[expn2;expn1(j,i)];
            if i==j
                bar(size(names,1),100*(obt1(j,i)-expn1(j,i))./sqrt(expn1(j,i)),1,'r');
            else
                bar(size(names,1),100*(obt1(j,i)-expn1(j,i))./sqrt(expn1(j,i)),1,'b');
            end
        end
    end
    set(gca,'XTickLabel',names)
    set(gca,'XTick',1:length(obt2))
    ax=axis;
    ax(1:2)=[0.5 length(obt2)+0.5];
    axis(ax);
    title('Contact Average Method')
    ylabel('(O-E)/sqrt(E)')
    if length(obt2)>10
        xticklabel_rotate;
    end
end
