function index = getoutliers(y,varargin)
%GETOUTLIERS Rosner's many-outlier test for detection of outliers in data.
% Syntax: ix=getoutliers(a,options);
% a could be grain/boundary object or numeric vector.
% options are passed as pairs of option name and option value:
% 'alpha'      ... significance level for the overall test. Default 0.05
% 'prop'       ... property used as data for grain/boundary objects.
%                  Default 'length'.
% 'maxout'     ... maximum number of outliers to be found. Default N/2.
% 'invert'     ... 0..return index to outliers 1..return index to all
%                  except outiers. Default 0.
%

% Originally written by Bob Newell, February 1996
% and modified by Jaco de Groot, May 2006
% Bob Newell used a fixed value for lambda. This script calculates the
% critical values for lambda based on the equations in
% "Quality control of semi-continuous mobility size-fractionated particle number concentration data",
% Atmospheric Environment 38 (2004) 3341�3348, Rong Chun Yu,*, Hee Wen Teh, Peter A. Jaques, Constantinos Sioutas,
% John R. Froines)
%-----------------------------------------------------
%

% This file is part of polyLX.
% 
% polyLX is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% polyLX is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with polyLX.  If not, see <http://www.gnu.org/licenses/>.

% polyLX - MATLAB toolbox for microstructure analyses
% Copyright (C) 2010 Ondrej Lexa

if nargin<1
    help getoutliers
    return
end

n = length(y);

% Process input arguments
opts.alpha=0.05;
opts.prop='length';
opts.maxout=round(n/2);
opts.invert=0;
opts=parseargs(varargin,opts);

% when grain object is passed
if isa(y,'polylxgrain')
   y=get(y,opts.prop);
end 
if isa(y,'polylxboundary')
    y=get(y,opts.prop);
end

R = zeros(opts.maxout + 1,1);
% sort deviations from the mean
ybar = mean(y);
[ys,is] = sort(abs(y - ybar));
% calculate statistics for up to k outliers
for i = 0:opts.maxout
    yy = ys(1:n-i);
    R(i+1) = abs(yy(n-i) - mean(yy)) / std(yy);
end
% statistical test to find outliers
index1 = [];
index=[];
imax=0;
for i = 1:opts.maxout
    pcrit=1-(opts.alpha/((2*(n-i+1))));
    t=tinv(pcrit, n-i-1);
    lambda(i)=(n-i)*t./sqrt(((n-i-1+t^2)*(n-i+1)));
    if R(i) > lambda
        index=is(n-i+1:end);   
        index1 = [ index1 is(n-i+1) ];
    end
end

if opts.invert
    index=setdiff(1:n,index);
end
