function p=parseargs(args, defargs)
%PARSEARGS - parse varargin cell array

% This file is part of polyLX.
% 
% polyLX is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% polyLX is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with polyLX.  If not, see <http://www.gnu.org/licenses/>.

% polyLX - MATLAB toolbox for microstructure analyses
% Copyright (C) 2010 Ondrej Lexa

if nargin<2
    error('You must provide default values');
end
if mod(length(args),2)==1
    error('Wrong number of arguments. Options must be in pairs.');
end

% get names of default properties
props=lower(fieldnames(defargs));
p=defargs;

for i=1:2:length(args)
    tprop=args{i};
    if ~isa(tprop,'char')
        error([tprop ' is not option name. Check arguments order.']);
    end
    tprop=lower(tprop);
    if any(strcmp(tprop,props))
        if ~strcmp(class(args{i+1}),class(getfield(defargs,tprop)))
            error(['Wrong value for option ' tprop '. Is should be ' class(getfield(defargs,tprop)) '.']);
        end
        p=setfield(p,tprop,args{i+1});
    end
end
