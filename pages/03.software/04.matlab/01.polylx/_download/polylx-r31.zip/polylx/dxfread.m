function [g,pth,fnm]=dxfread(varargin)
%DXFREAD Read grain geometry from ASCII Drawing Interchange (DXF) Files R12.
% Syntax:  [g,path,filename]=dxfread;
%          [g,path,filename]=dxfread(filename);

% This file is part of polyLX.
% 
% polyLX is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% polyLX is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with polyLX.  If not, see <http://www.gnu.org/licenses/>.

% polyLX - MATLAB toolbox for microstructure analyses
% Copyright (C) 2010 Ondrej Lexa

% GUI open file
pth=[]; fnm=[];
if isempty(varargin)
    [fnm, pth]=uigetfile({'*.dxf','Drawing Interchange DXF R12 (*.dxf)'},'Open DXF file');
    if fnm==0
        g=[];
        return
    end
    filename=[pth fnm];
else
    filename=varargin{1};
    if isempty(strfind(filename,'.dxf'))||~exist(filename,'file')
        g=[];
        error('First argument must be valid filename of DXF file with extension. Aborted.');
    end
    ix=find(filename=='\');
    if isempty(ix);
        ix=0;
    end
    fnm=filename(ix(end)+1:end);
    pth=filename(1:ix(end));
end

fid=fopen(filename);
C=textscan(fid,'%s');
fclose(fid);
C=C{1,1};

% find POLYLINE
ixpoly=find(strcmp('POLYLINE', C));
poc=length(ixpoly);
ixpoly=[ixpoly;length(C)];

h=fwaitbar(0,'Reading geometry...');

id=0;
for i=1:poc
    P=C(ixpoly(i):ixpoly(i+1)-1);
    ph=P{3}; %set phase
    ixnodes=find(strcmp('VERTEX', P));
    x=str2double((P(ixnodes+4)));
    y=str2double((P(ixnodes+6)));
    if length(x)>3
        geom=plgeo(x,y);
        if sign(geom(1))~=1
            x=flipud(x);
            y=flipud(y);
%            disp(id+1)
        end
        id=id+1;
        g(id)=polylxgrain(id,ph,x,y);
    end
    fwaitbar(i/poc,h);
end
close(h)
