function [exn,obt,chis,vmr]=aquadrat(g,varargin)
%AQUADRAT Return results of quadrat analysis.
% Syntax:  [exn,obt]=aquadrat(g,options)
%    exn - number of expected grains in each cell
%    obt - matrix of observed number of grain in each cell
%   chis - chi-square goodness-of-fit test of randomness
%    vmr - variance mean ratio <1 towards uniformity
%                              >1 towards clustering
% options are string evaluated by function (these are default values):
% 'xgrid'       ... number of division on x side. Default Auto
% 'ygrid'       ... number of division on y side. Default Auto
% 'dots'        ... 0.. no plot, 1.. plot points.  Default 0
% 'plot'        ... 0.. no plot, 1.. checkerboard plot,
%                   2.. density contours. Default 0
% 'ncont'       ... number of contours. Defaut 10
% 'smooth'      ... degree of smoothing for contour plotting. Default 2
% 'pointsize'   ... point size. Dafault 6
% 'poitcolor'   ... point color and style. Default 'b.'

% This file is part of polyLX.
% 
% polyLX is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% polyLX is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with polyLX.  If not, see <http://www.gnu.org/licenses/>.

% polyLX - MATLAB toolbox for microstructure analyses
% Copyright (C) 2010 Ondrej Lexa

if nargin<1
    help aquadrat;
    return;
end

if ~isa(g,'polylxgrain')
    help aquadrat;
    return;
end 

% Process input arguments
opts.xgrid=round(sqrt(length(g)/10));
opts.ygrid=round(sqrt(length(g)/10));
opts.plot=0;
opts.dots=0;
opts.ncont=10;
opts.smooth=2;
opts.pointsize=6;
opts.pointcolor='k.';
opts=parseargs(varargin,opts);

% initialize x a y coordinates of grains and determine bounding rectangle
[gx,gy]=get(g,'xcentre','ycentre');

% calculate counting grid
dx=max(gx)-min(gx);
dy=max(gy)-min(gy);
xmin=min(gx)-dx/100;
xmax=max(gx)+dx/100;
ymin=min(gy)-dy/100;
ymax=max(gy)+dy/100;

% count
[dummy,dummy,obt]=dengrid(gx,gy,0,opts.xgrid,opts.ygrid,xmin,xmax,ymin,ymax);
exn=length(g)/(opts.xgrid*opts.ygrid);
s2=sum(sum((obt-exn).^2))/(numel(obt)-1);
chis=sum(sum((obt-exn).^2/exn));
vmr=s2/exn;
%z=sqrt((numel(obt)-1)/2)*(vmr-1);

% plotting
if opts.plot==1
    pcolor(linspace(xmin,xmax,opts.xgrid+1),linspace(ymin,ymax,opts.ygrid+1),[obt zeros(size(obt,1),1);zeros(1,size(obt,2)+1)]);
    colorbar
end
if opts.plot==2
    [x,y,tt]=dengrid(gx,gy,opts.smooth,opts.xgrid,opts.ygrid,xmin,xmax,ymin,ymax);
    contourf(x,y,tt,linspace(0,max(max(obt)),opts.ncont));
    colormap(flipud(gray));
    colorbar
end

if opts.dots>0
    hold on
    plot(gx,gy,opts.pointcolor,'MarkerSize',opts.pointsize);
    hold off
end

% Calculate chi-square value chi2cdf(x,df)=gammainc(x/2,df/2)
pp=gammainc(chis/2,(numel(obt)-1)/2);
if chis<2*gammaincinv(0.025,(numel(obt)-1)/2)
    disp(['Grains are uniformly distributed at significance level ' num2str(100-pp*100)]);
elseif chis>2*gammaincinv(0.975,(numel(obt)-1)/2)
    disp(['Grains are clustered at significance level ' num2str(pp*100)]);
else
    disp('Grains are randomly distributed within 95% confidence.');
end
