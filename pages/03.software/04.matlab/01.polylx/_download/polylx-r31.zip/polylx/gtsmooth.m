function gn=gtsmooth(g)
%GTSMOOTH Topological smoothing of the grain objects.
% Syntax:  gn=gtsmooth(g);
%    g   - grain objects

% This file is part of polyLX.
% 
% polyLX is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% polyLX is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with polyLX.  If not, see <http://www.gnu.org/licenses/>.

% polyLX - MATLAB toolbox for microstructure analyses
% Copyright (C) 2013 Ondrej Lexa

% Initialize
co=zeros(0,2);
cn=sparse([],[],[],1,1,0);

h=fwaitbar(0,'Decomposing grain objects...');
%Decompose grains
poc=length(g);
gn=repmat(polylxgrain,1,poc);
for i=1:poc
    fwaitbar(i/poc,h);
    [x,y]=get(g(i),'x','y');
    for j=1:length(x)-1
        nfrom=find((co(:,1)==x(j))&(co(:,2)==y(j)));
        if isempty(nfrom)
            co=[co;x(j) y(j)];
            nfrom=size(co,1);
        end
        nto=find((co(:,1)==x(j+1))&(co(:,2)==y(j+1)));
        if isempty(nto)
            co=[co;x(j+1) y(j+1)];
            nto=size(co,1);
        end
        cn(nfrom,nto)=i;
    end
    nholes=get(g(i),'nholes');
    if nholes>0
        hol=get(g(i),'holes');
        for k=1:nholes
            x=hol(k).x;
            y=hol(k).y;
            for j=1:length(x)-1
                nfrom=find((co(:,1)==x(j))&(co(:,2)==y(j)));
                if isempty(nfrom)
                    co=[co;x(j) y(j)];
                    nfrom=size(co,1);
                end
                nto=find((co(:,1)==x(j+1))&(co(:,2)==y(j+1)));
                if isempty(nto)
                    co=[co;x(j+1) y(j+1)];
                    nto=size(co,1);
                end
                cn(nfrom,nto)=i;
            end
        end
    end
end
close(h);

h=fwaitbar(0,'Smoothing segments...');
%smooth
% create special adjancency matrix
bb=cn~=0|cn'~=0;
mx=nnz(bb);
%power of nodes
st=sum(bb);
%starts at least triple points
tp=find(st>=3);
finish=false;
while ~finish
    ok=false;
    % find begin of branch
    while ~ok&&~finish
        nodes=tp(1);
        nn=find(bb(nodes,:),1);
        if isempty(nn)
            tp(1)=[];
            if isempty(tp)
                finish=true;
            end
        else
            ok=true;
        end
    end
    if ~finish
        % follow the branch
        while st(nn)<3
            bb(nodes(end),nn)=0;
            bb(nn,nodes(end))=0;
            nodes=[nodes nn];
            nn=find(bb(nn,:),1);
        end
        bb(nodes(end),nn)=0;
        bb(nn,nodes(end))=0;
        nodes=[nodes nn];
        hermite(nodes);
    end
    fwaitbar((mx-nnz(bb))/mx,h);
end
% find all islands
while nnz(bb)
    [zac,nn]=find(bb,1);
    nodes=zac;
    while nn~=zac
        bb(nodes(end),nn)=0;
        bb(nn,nodes(end))=0;
        nodes=[nodes nn];
        nn=find(bb(nn,:),1);
    end
    bb(nodes(end),nn)=0;
    bb(nn,nodes(end))=0;
    nodes=[nodes nn];
    hermite(nodes);
    fwaitbar((mx-nnz(bb))/mx,h);
end
close(h);

h=fwaitbar(0,'Constructing grains...');
%construct
for i=1:poc
    fwaitbar(i/poc,h);
    part=[];
    ok=true;
    [zac,nn]=find(cn==i,1);
    while ok
        nodes=zac;
        while nn~=zac
            cn(nodes(end),nn)=0;
            nodes=[nodes nn];
            nn=find(cn(nn,:)==i,1);
        end
        cn(nodes(end),nn)=0;
        nodes=[nodes nn];
        part=[part;co(nodes,:);[NaN NaN]];
        [zac,nn]=find(cn==i,1);
        if isempty(zac)
            ok=false;
        end
    end
    gn(i)=polylxgrain(get(g(i),'id'),char(get(g(i),'phase')),part(1:end-1,1),part(1:end-1,2));
end
close(h);

% ----------------------------------------------
    function hermite(nodes)
        %smooth segment
        x=co(nodes,1);
        y=co(nodes,2);
        s=[0;cumsum(sqrt(diff(x).^2+diff(y).^2))];
        ns=linspace(0,s(end),length(nodes))';
        ss=[s(1:end-1)-s(end);s;s(2:end)+s(end)];
        xx=[x(1:end-1);x;x(2:end)];
        yy=[y(1:end-1);y;y(2:end)];
        x1=pchip(ss,xx,ns);
        y1=pchip(ss,yy,ns);
        co(nodes(2:end-1),:)=[x1(2:end-1) y1(2:end-1)];
    end
end