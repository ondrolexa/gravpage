function g=genellipses(n,varargin)
%GENELLIPSES Generate elliptical grains of given properties.
% Syntax: g=genellipses(n,options);
% n is number of ellipses to generate. Default is 100.
% options are passed as pairs of option name and option value:
% 'meanar'   ... Mean axial ratio. Default 2
% 'stdar'    ... Standard deviation of axial ratio distribution. Default 0
% 'randor'   ... Random orientation. Default 1
% 'meanor'   ... Mean orientation for randor=0. Default 0
% 'stdor'    ... Standard deviation of orientation. Default 0

% This file is part of polyLX.
% 
% polyLX is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% polyLX is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with polyLX.  If not, see <http://www.gnu.org/licenses/>.

% polyLX - MATLAB toolbox for microstructure analyses
% Copyright (C) 2010 Ondrej Lexa

if nargin<1
    n=100;
end

% Process input arguments
opts.meanar=2;
opts.stdar=0;
opts.randor=1;
opts.meanor=0;
opts.stdor=0;
opts=parseargs(varargin,opts);

phi=linspace(0,2*pi,180)';
id=0;
%  find grid size
sz=ceil(sqrt(n));
%make grid
[x,y]=meshgrid(linspace(-3*sz*sqrt(opts.meanar)/2,3*sz*sqrt(opts.meanar)/2,sz),linspace(-3*sz*sqrt(opts.meanar)/2,3*sz*sqrt(opts.meanar)/2,sz));
% choose n seeds for ellipses
ix=randperm(sz^2);
ix=ix(1:n);
% generate ODF
if opts.randor==1
    or=pi*rand(n,1);
else
    or=(opts.meanor+opts.stdor*randn(n,1))*pi/180;
end
% generate AR
ar=exp(log(opts.meanar)+opts.stdar*randn(n,1));

for i=1:n;
    id=id+1;
    if ar(i)>1
        xx=sin(phi)/sqrt(ar(i));
        yy=cos(phi)*sqrt(ar(i));
    else
        xx=sin(phi)*sqrt(ar(i));
        yy=cos(phi)/sqrt(ar(i));
    end
    R=[cos(or(i)) -sin(or(i));sin(or(i)) cos(or(i))];
    cc=[xx yy]*R;
    g(id)=polylxgrain(id,'ellipse',x(ix(i))+cc(:,1),y(ix(i))+cc(:,2));
end
