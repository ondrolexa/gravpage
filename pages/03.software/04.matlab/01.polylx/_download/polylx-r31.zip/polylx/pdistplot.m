function pdistplot(a,varargin)
%PDISTPLOT Plot normal or lognormal probability plot.
% Syntax: pdistplot(a,options);
% a could be grain/boundary object, column vector or cell array of column
% vectors. EAD for grain and CumLength for boundary is used by default.
% options are passed as pairs of option name and option value:
% 'type'       ... 'normal' ... normal probability plot
%                  'log' ... lognormal probability plot. Default 'normal'
% 'symbol'     ... plot symbol. Default '+'.
% 'fit'        ... 0 ... no fit 1 ... linear fit. Default 0

% This file is part of polyLX.
% 
% polyLX is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% polyLX is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with polyLX.  If not, see <http://www.gnu.org/licenses/>.

% polyLX - MATLAB toolbox for microstructure analyses
% Copyright (C) 2010 Ondrej Lexa

if nargin<1
    help pdistplot;
    return;
end

%check input
if isa(a,'double')
    a={a};
end

for i=1:length(a)
    leg{i}=num2str(i);
end

% when grain object is passed
if isa(a,'polylxgrain')
    leg=gplist(a);
    for i=1:length(leg)
        dd{i}=get(a(leg{i}),'ead');
    end
    a=dd;
end
if isa(a,'polylxboundary')
    leg=gplist(a);
    for i=1:length(leg)
        dd{i}=get(a(leg{i}),'CumLength');
    end
    a=dd;
end

% Process input arguments
opts.type='normal';
opts.symbol='+';
opts.fit=0;
opts=parseargs(varargin,opts);

%go
cc=jet(length(a));
clf;
for i=1:length(a)
    d=a{i};
    d=d(:);
    ds=sort(d);
    p=((1:length(d))-0.5)/length(d);
    z=-sqrt(2)*erfcinv(2*p);
    switch opts.type
        case 'normal'
            plot(z,ds,opts.symbol,'color',cc(i,:));
            hold on;
            xlabel('Normal quantile function')
        case 'log'
            loglog(exp(z),ds,opts.symbol,'color',cc(i,:));
            hold on;
            xlabel('Lognormal quantile function')
        otherwise
            error('Wrong type provided.')
    end
end
ylabel('Ordered response')
hold off
legend(leg);

