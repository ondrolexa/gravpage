function [err,yt]=fitrs(lam,xx)
% function to fit finite strain for nearest neighbor method
% lam is [a b c]

% This file is part of polyLX.
% 
% polyLX is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% polyLX is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with polyLX.  If not, see <http://www.gnu.org/licenses/>.

% polyLX - MATLAB toolbox for microstructure analyses
% Copyright (C) 2010 Ondrej Lexa

global xdat ydat

a=lam(1);
b=lam(2);
c=lam(3);

if nargout<2
 yt=c-a.*cos(2*xdat)-b*sin(2*xdat);
 err=sum((ydat-yt).^2.*(ydat));
else
 yt=c-a.*cos(2*xx)-b*sin(2*xx);
 err=0;
end