function cn = grainmask(c,g)
%GRAINMASK Return mask of selected grains.
% Syntax:
%      cg=grainmask(c,g)
% where c is cip object and g are PolyLX grains

% This file is part of polyLX.
% 
% polyLX is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% polyLX is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with polyLX.  If not, see <http://www.gnu.org/licenses/>.

% polyLX - MATLAB toolbox for microstructure analyses
% Copyright (C) 2010 Ondrej Lexa

[sy,sx]=size(c.mask);
[x,y]=meshgrid(1:sx,1:sy);
xx=[];
yy=[];
for i=1:length(g);
    xx=[xx;get(g(i),'x');NaN];
    yy=[yy;-get(g(i),'y');NaN];
    nh = get(g(i),'NHoles');
    if nh>0
        h = get(g(i),'holes');
        for j=1:nh
            xx=[xx;h(j).x;NaN];
            yy=[yy;-h(j).y;NaN];
        end
    end
end
bw = inpolygon(x,y,xx,yy);
bw = bw&c.mask;
cn = cipdata(c.azi,c.incp,bw,sprintf('%s - Selection of %d grains',c.name,length(g)));