function [c,offset] = cipmerge(c1,c2,t,name)
%CIPMERGE Merge cipdata object.
%   c = CIPMERGE(c1,c2,t,[name])
%
% t is 1x2 vector of mutual translation, so pos(c2)=pos(c1)+t
% c2 always overwrite c1 in overlapped area. You can change it by swapping
% parameters and pass t with negative values.
%
% Check Fiji grid/collection stitching plugin to find good t values.

% This file is part of polyLX.
% 
% polyLX is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% polyLX is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with polyLX.  If not, see <http://www.gnu.org/licenses/>.

% polyLX - MATLAB toolbox for microstructure analyses
% Copyright (C) 2010 Ondrej Lexa

if nargin<3
    help cipmerge
    c=[];
    return
end
if nargin<4
    name=[get(c1,'name') '+' get(c2,'name')];
end

a1=get(c1,'azi');
a2=get(c2,'azi');
i1=get(c1,'incp');
i2=get(c2,'incp');
m1=get(c1,'mask');
m2=get(c2,'mask');

offset=-t;
offset(t>0)=0;

p1l=[0 0];
p1u=size(a1);
p2l=fliplr(round(t));
p2u=size(a2);

r=[p1l;p1u;p2l;p2l+p2u];
ns=diff([min(r);max(r)]);

a=nan(ns);
i=nan(ns);
m=false(ns);

o1=p1l-min(r);
o2=p2l-min(r);

a(1+o1(1):p1u(1)+o1(1),1+o1(2):p1u(2)+o1(2))=a1;
a(1+o2(1):p2u(1)+o2(1),1+o2(2):p2u(2)+o2(2))=a2;
i(1+o1(1):p1u(1)+o1(1),1+o1(2):p1u(2)+o1(2))=i1;
i(1+o2(1):p2u(1)+o2(1),1+o2(2):p2u(2)+o2(2))=i2;
m(1+o1(1):p1u(1)+o1(1),1+o1(2):p1u(2)+o1(2))=m1;
m(1+o2(1):p2u(1)+o2(1),1+o2(2):p2u(2)+o2(2))=m2;
c=cipdata(a,i,m,name);
