function [dt,gc]=graindata(c,g,opt)
%GRAINDATA Return grain integrated azimuth and inclination data.
% Syntax:
%      [dt,gc]=graindata(c,g);

% This file is part of polyLX.
% 
% polyLX is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% polyLX is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with polyLX.  If not, see <http://www.gnu.org/licenses/>.

% polyLX - MATLAB toolbox for microstructure analyses
% Copyright (C) 2010 Ondrej Lexa

if nargin<3
    opt=true;
end
dt=[];
gc=[];
dc=[];
[sy,sx]=size(c.mask);
disp('Integrating grain data...')
for i=1:length(g)
    tbw = poly2mask(get(g(i),'x'),-get(g(i),'y'),sy,sx);
    nh = get(g(i),'NHoles');
    if nh>0
        h = get(g(i),'holes');
        for j=1:nh
            tbw = xor(tbw,poly2mask(h(j).x,-h(j).y,sy,sx));
        end
    end
    vse=length(find(tbw));
    tbw = tbw&c.mask;
    if any(any(tbw))
        if length(find(tbw))/vse>0.25
            azi = c.azi(tbw);
            incp = c.incp(tbw);
            gdc = [cos(incp*pi/180).*cos(azi*pi/180) cos(incp*pi/180).*sin(azi*pi/180) sin(incp*pi/180)];
            [e1,e2] = eig(gdc'*gdc);
            md = sign(e1(3,3))*e1(:,3)';
            dipdir = real(acos(md(1)./cos(asin(md(3)))))*180/pi;
            dipdir(md(2)<0) = 360-dipdir(md(2)<0);
            dt = [dt;dipdir asin(md(3))*180/pi];
            dc = [dc; md];
            gc = [gc g(i)];
        else
            if opt
                disp(sprintf('Grain %d skipped. No data.',i));
            end
        end
    else
        if opt
            disp(sprintf('Grain %d skipped. No data.',i));
        end
    end
end
