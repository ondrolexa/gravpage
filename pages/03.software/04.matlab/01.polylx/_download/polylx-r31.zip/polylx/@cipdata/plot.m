function plot(c,type,lut)
%PLOT Plot cip data maps.
% Syntax:
%      plot(c);
%      plot(c,type)
%      plot(c,type,lut)
% Options:
%    type ... orient
%         ... azi
%         ... incp
%         ... mask
%         ... biazi
%         ... mapexport
% See help azidip2color for possible LUT's

% This file is part of polyLX.
% 
% polyLX is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% polyLX is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with polyLX.  If not, see <http://www.gnu.org/licenses/>.

% polyLX - MATLAB toolbox for microstructure analyses
% Copyright (C) 2010 Ondrej Lexa

if nargin<3
    lut='';
end
if nargin<2
    type='cip';
end
switch lower(type)
    case 'azi'           
        clf
        imagesc(get(c,'azi'))
        alpha(double(c.mask))
        colormap(hsv)
        colorbar
        axis equal
        axis tight
        title(['Azimuth map - ' c.name])
    case 'incp'
        clf
        imagesc(get(c,'incp'))
        alpha(double(c.mask))
        colorbar
        axis equal
        axis tight
        title(['Inclination map - ' c.name])
    case 'mask'
        clf
        imagesc(c.mask)
        axis equal
        axis tight
        colormap gray
        title(['Mask - ' c.name])
    case 'biazi'
        clf
        imagesc(mod(get(c,'azi'),180))
        alpha(double(c.mask))
        colorbar
        axis equal
        axis tight
        title(['Bi-Azimuth map - ' c.name])
    case 'mapexport'
        % for case of missing parameter
        if isempty(lut)
            lut=type;
        end
        [r,g,b]=azidip2color(get(c,'azi'),get(c,'incp'),'lut',lut);
        im = cat(3,r,g,b);
        imwrite(im,'map.png','png','Transparency',[1 1 1]);        
        [sazi,sdip,rs,gs,bs]=schmidtgrid(512,'lut',lut);
        imlt = cat(3,rs,gs,bs); 
        imwrite(imlt,'lookup.png','png','Transparency',[1 1 1]);
    otherwise
        % for case of missing parameter
        if isempty(lut)
            lut=type;
        end
        clf
        h=subplot('position',[0.02 0.03 0.78 0.94]);
        [r,g,b]=azidip2color(get(c,'azi'),get(c,'incp'),'lut',lut);
        %r(~c.mask)=1;
        %g(~c.mask)=1;
        %b(~c.mask)=1;
        im = cat(3,r,g,b);
        image(im);
        axis equal
        axis tight
        axis off
        set(gca,'Color',[0 0 0])
        alpha(double(c.mask))
        t=title(['Grain orientation map - ' c.name]);
        if strcmpi(lut,'renee')
            set(gcf,'color',[0 0 0])
            set(t,'color','w')
        end
        %imwrite(im,'map.png','png','Transparency',[1 1 1]);        
        subplot('position',[0.81 0.15 0.18 0.25])
        [sazi,sdip,rs,gs,bs]=schmidtgrid(512,'lut',lut);
        imlt = cat(3,rs,gs,bs); 
        image(imlt)
        %rs(isnan(rs))=1;
        %gs(isnan(gs))=1;
        %bs(isnan(bs))=1;
        axis equal
        axis tight
        axis off
        alpha(double(~isnan(rs)))
        %title('Look-up table')
        %imwrite(imlt,'lookup.png','png','Transparency',[1 1 1]);
        subplot('position',[0.81 0.6 0.18 0.25])
        contour(c,'nc',8,'scale',3,'annotation',false)
        axis tight
        axis off
        subplot(h)
end
