function contour(c,varargin)
%CONTOUR Plot contour plot of cipdata.
% Syntax:
%      contour(c);
% Arguments:
%      c     ... cip object
% options are passed as pairs of option name and option value:
% 'grid'   ... counting grid halfsize. Default 16
% 'nc'     ... number of contours or vector of contour values. Default 10
% 'scale'  ... 0 - linear >0 - logarithmic (value is shift). Default 0
% 'res'    ... number of bins. Default 512.
% 'color'  ... true/false. Default false
% 'grains' ... when grains, data are integrated per grain. Default [];
% 'diff'   ... if true contour difference between grain and cip fabric.
%              Grains option must be non-empty. Default false.

% This file is part of polyLX.
% 
% polyLX is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% polyLX is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with polyLX.  If not, see <http://www.gnu.org/licenses/>.

% polyLX - MATLAB toolbox for microstructure analyses
% Copyright (C) 2010 Ondrej Lexa

% initialize defaults and parse arguments
opts.grid=12;
opts.nc=10;
opts.res=512;
opts.scale=0;
opts.color=false;
opts.grains=polylxgrain;
opts.diff=false;
opts.annotation=true;
opts=parseargs(varargin,opts);

if isempty(opts.grains)
    dd = get(c,'data');
else
    dd = graindata(c,opts.grains,false);
end

s2 = sqrt(2);
% get inner and outer data for schmidt projection
x = [s2*sin(pi/4-(dd(:,2)*pi/180)/2).*sin(dd(:,1)*pi/180);s2*sin(pi/4-(-dd(:,2)*pi/180)/2).*sin(dd(:,1)*pi/180-pi)];
y = [s2*sin(pi/4-(dd(:,2)*pi/180)/2).*cos(dd(:,1)*pi/180);s2*sin(pi/4-(-dd(:,2)*pi/180)/2).*cos(dd(:,1)*pi/180-pi)];
%create counting grid
xe = linspace(-s2,s2,2*opts.grid); ye = linspace(-s2,s2,2*opts.grid);
%create centers of counting grid used during interpolation
xs = (xe(1)+xe(2))/2+cumsum([0 diff(xe)]); xs = xs(1:end-1);
ys = (ye(1)+ye(2))/2+cumsum([0 diff(ye)]); ys = ys(1:end-1);
[xx,yy] = meshgrid(xs,ys);
% do count
histmat = hist2(x,y,xe,ye);
% count for uniform distribution
ud = 8*size(dd,1)/(pi*(2*opts.grid)^2);
% create interpolation grid
xsf = linspace(-1,1,opts.res); ysf = linspace(-1,1,opts.res);
[xxf,yyf] = meshgrid(xsf,ysf);
% interpolate counted data
zzf = interp2(xx,yy,histmat(1:end-1,1:end-1),xxf,yyf,'cubic');
% discard out of projection data
dist = xxf.^2 + yyf.^2;
zzf(dist>1) = nan;
zzf(zzf<0) = 0;

if opts.diff && ~isempty(opts.grains)
    dd1 = get(c,'data');
    % get inner and outer data for schmidt projection
    x = [s2*sin(pi/4-(dd1(:,2)*pi/180)/2).*sin(dd1(:,1)*pi/180);s2*sin(pi/4-(-dd1(:,2)*pi/180)/2).*sin(dd1(:,1)*pi/180-pi)];
    y = [s2*sin(pi/4-(dd1(:,2)*pi/180)/2).*cos(dd1(:,1)*pi/180);s2*sin(pi/4-(-dd1(:,2)*pi/180)/2).*cos(dd1(:,1)*pi/180-pi)];
    % do count
    histmat = hist2(x,y,xe,ye);
    % count for uniform distribution
    ud1 = 8*size(dd1,1)/(pi*(2*opts.grid-1)^2);
    % interpolate counted data
    zzf1 = interp2(xx,yy,histmat(1:end-1,1:end-1),xxf,yyf,'cubic');
    % discard out of projection data
    zzf1(dist>1) = nan;
    zzf1(zzf1<0) = 0;
    
    % plot contours - multiples of uniform distribution
    if opts.scale
        cc=logspace(log10(opts.scale),log10(max(max(zzf/ud-zzf1/ud1))+opts.scale),opts.nc)-opts.scale;
        cc(1)=0;
        opts.nc=cc;
    end
    contourf(xxf,yyf,zzf/ud-zzf1/ud1,opts.nc);
    axis equal, axis off, box off
    if opts.color
        colormap(jet)
    else
        colormap(flipud(gray))
    end
    if opts.annotation
        colorbar
        title(['Contour plot of grain texture difference - ' c.name])
        text(1.01,0,'90');
        text(-0.07,-1.06,'180');
        text(-1.13,0,'270');
        text(1.1,-1.1,sprintf('Max: %.3f',max(max(zzf/ud))))
        text(-1.1,-1.1,sprintf('Grains: %d Points: %d',size(dd,1),size(dd1,1)))
    end
else 
    % plot contours - multiples of uniform distribution
    if opts.scale
        cc=logspace(log10(opts.scale),log10(max(max(zzf/ud))+opts.scale),opts.nc)-opts.scale;
        cc(1)=0;
        opts.nc=cc;
    end
    contourf(xxf,yyf,zzf/ud,opts.nc);
    axis equal, axis off, box off
    if opts.color
        colormap(jet)
    else
        colormap(flipud(gray))
    end
    if opts.annotation
        colorbar
        if isempty(opts.grains)
            title(['Contour plot - ' c.name])
        else
            title(['Contour plot - ' c.name ' - Grain integrated'])
        end
        text(1.01,0,'90');
        text(-0.07,-1.06,'180');
        text(-1.13,0,'270');
        text(1.1,-1.1,sprintf('Max: %.3f',max(max(zzf/ud))))
        text(-1.1,-1.1,sprintf('Points: %d',size(dd,1)))
    end
end
    
function histmat  = hist2(x, y, xedges, yedges)
% function histmat  = hist2(x, y, xedges, yedges)
%
% Extract 2D histogram data containing the number of events
% of [x , y] pairs that fall in each bin of the grid defined by 
% xedges and yedges. The edges are vectors with monotonically 
% non-decreasing values.  
%
%EXAMPLE 
%
% events = 1000000;
% x1 = sqrt(0.05)*randn(events,1)-0.5; x2 = sqrt(0.05)*randn(events,1)+0.5;
% y1 = sqrt(0.05)*randn(events,1)+0.5; y2 = sqrt(0.05)*randn(events,1)-0.5;
% x= [x1;x2]; y = [y1;y2];
%
%For linearly spaced edges:
% xedges = linspace(-1,1,64); yedges = linspace(-1,1,64);
% histmat = hist2(x, y, xedges, yedges);
% figure; pcolor(xedges,yedges,histmat'); colorbar ; axis square tight ;
%
%For nonlinearly spaced edges:
% xedges_ = logspace(0,log10(3),64)-2; yedges_ = linspace(-1,1,64);
% histmat_ = hist2(x, y, xedges_, yedges_);
% figure; pcolor(xedges_,yedges_,histmat_'); colorbar ; axis square tight ;

% University of Debrecen, PET Center/Laszlo Balkay 2006
% email: balkay@pet.dote.hu

[xn, xbin] = histc(x,xedges);
[yn, ybin] = histc(y,yedges);

%xbin, ybin zero for out of range values 
% (see the help of histc) force this event to the 
% first bins
xbin(find(xbin == 0)) = 1;
ybin(find(ybin == 0)) = 1;

xnbin = length(xedges);
ynbin = length(yedges);

if xnbin >= ynbin
    xy = ybin*(xnbin) + xbin;
      indexshift =  xnbin; 
else
    xy = xbin*(ynbin) + ybin;
      indexshift =  ynbin; 
end

xyuni = unique(xy);
hstres = histc(xy,xyuni);
histmat = zeros(xnbin,ynbin);
histmat(xyuni-indexshift) = hstres;
histmat = histmat';