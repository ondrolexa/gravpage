function val = get(c, varargin)
%GET Get cipdata properties.

% This file is part of polyLX.
% 
% polyLX is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% polyLX is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with polyLX.  If not, see <http://www.gnu.org/licenses/>.

% polyLX - MATLAB toolbox for microstructure analyses
% Copyright (C) 2010 Ondrej Lexa

if nargin>1
    switch lower(varargin{1})
        case 'azi'
            val = c.azi;
            val(~c.mask)=nan;
        case 'incp'
            val = c.incp;
            val(~c.mask)=nan;
        case 'mask'
            val = c.mask;
        case 'width'
            val=c.width;
        case 'height'
            val=c.height;
        case 'name'
            val=c.name;
        case 'data'
            a = c.azi(c.mask);
            b = c.incp(c.mask);
            val = [a(:) b(:)];
        otherwise
            error([varargin{1},' is not valid cip property']);
    end
else
    disp('Available cipdata properties are:');
    disp('  AZI');
    disp('  INCP');
    disp('  MASK');
    disp('  Width');
    disp('  Height');
    disp('  Name');
    disp('  Data');
end
