function res=describe(g,varargin)
%DESCRIBE Return descriptive statistics of chosen measurement.
% Number, mean, std, geomean, geostd, min, qtile1, median, qtile3, max
% and trimean is calculated for individual phases or boundary types.
% Syntax:  dsc=describe(g,options);
%  g      - grain/boundary objects
% options are passed as pairs of option name and option value:
% 'prop'       ... properties of grain/boundary object to dump.
% 'format'     ... 'cell'...return cell arrays ready for txtwrite.
%                  otherwise returns numeric arrays. Default 'cell'.

% This file is part of polyLX.
% 
% polyLX is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% polyLX is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with polyLX.  If not, see <http://www.gnu.org/licenses/>.

% polyLX - MATLAB toolbox for microstructure analyses
% Copyright (C) 2010 Ondrej Lexa

if nargin<1
    help describe
    res=[];
    return
end
if ~isa(g,'polylxgrain') && isa(g,'polylxboundary')
    help describe
    res=[];
    return
end

% Process input arguments
opts.prop='';
opts.format='cell';
opts=parseargs(varargin,opts);

if isempty(opts.prop)
    tlist=get(g);
    [typa,valid]=listdlg('PromptString','Select measurement:','SelectionMode','Single','ListString',tlist);
    if valid~=1
        disp ('Aborted.')
        res=[];
        return
    end
else
    tlist={opts.prop};
    typa=1;
end
ph=gplist(g);
pf=length(ph);
dsc=[];

for i=1:pf
   f=get(g(ph{i}),tlist{typa});
   dsc=[dsc [length(f);mean(f);std(f);exp(mean(log(f)));exp(std(log(f)));min(f);percentil(f,25);median(f);percentil(f,75);max(f);(percentil(f,25)+2*percentil(f,50)+percentil(f,75))/4]];
end

if strcmpi(opts.format,'cell')
    res=[{tlist{typa};'N';'Mean';'Std';'Geomean';'Geostd';'Min';'Qtile1';'Median';'Qtile3';'Max';'Trimean'} [ph';num2cell(dsc)]];
else
    res=dsc;
end
