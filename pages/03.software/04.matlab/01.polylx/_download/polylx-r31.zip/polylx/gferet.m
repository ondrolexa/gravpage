function gn=gferet(g,varargin)
%GFERET Return length and orientation of maximum and maximum perpendicular Feret diameters
% Syntax: gn=gferet(g,options)
% g can be grain or boundary object(s)
% When grain objects are passed gn are grains objects with calculated
% properties centre, la,sa,lao,sao. When boundary objects are passed gn is
% structure with fields x[y]centre, lao, sao, la, sa. To plot data from
% structure use PELLIPSE or PCROSS
% options are passed as pairs of option name and option value:
% 'res'      ... resolution i.e. number of vertexes Default 91.
%                res 5 is enough to get la,sa,lao,sao

% This file is part of polyLX.
% 
% polyLX is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% polyLX is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with polyLX.  If not, see <http://www.gnu.org/licenses/>.

% polyLX - MATLAB toolbox for microstructure analyses
% Copyright (C) 2010 Ondrej Lexa

if nargin<1
    help gferet;
    return;
end

% Process input arguments
opts.res=91;
opts=parseargs(varargin,opts);
if opts.res<5
    opts.res=5;
end

%Initialize
n=length(g);
switch class(g)
    case 'polylxgrain'
        gn=repmat(polylxgrain,1,n);
    case 'polylxboundary'
        gn=repmat(struct('xcentre',[],'ycentre',[],'lao',[],'sao',[],'la',[],'sa',[]),1,n);
    otherwise
        disp('First argument must be grain or boundary object.')
        gn=[];
        return
end
the=linspace(0,360,opts.res)';

h=fwaitbar(0,'Calculating...');

for ii=1:n
    dt=get(g(ii),'x','y');
    m=size(dt,1);
    p=(m-1):-1:2;
    k=zeros(m*(m-1)/2,1);
    k(cumsum([1 p]))=1;
    k=cumsum(k);
    j=ones(m*(m-1)/2,1);
    j(cumsum(p)+1)=2-p;
    j(1)=2;
    j=cumsum(j);
    l=(dt(k,:)-dt(j,:))';
    l=sum(l.^2);
    l=sqrt(l);
    o=size(l,2);
    m=(1+sqrt(1+8*o))/2;
    z=zeros(m);
    k=ones(o,1);
    j=[1 (m-1):-1:2]';
    k(cumsum(j))=(2:m);
    z(cumsum(k))=l';
    z = z + z';
    [z1,p1]=max(z);
    [la,p2]=max(z1);
    p1=p1(p2);
    dp=dt(p2,:)-dt(p1,:);
    rv=dp/sqrt(dp*dp');
    rv=[rv(2);-rv(1)]; % unit perpendicular vector
    pp=(dt*rv); % projection onto rv
    sa=max(pp)-min(pp);
    lao=mod(atan2(dp(1),dp(2))*180/pi,180);
    R=[cosd(lao) sind(lao);-sind(lao) cosd(lao)];
    ndt=dt*R;
    cc=((max(ndt)+min(ndt))/2)*R';
    co=cosd(lao);
    si=sind(lao);
    x=si*cosd(the)*la/2+co*sind(the)*sa/2+cc(1);
    y=co*cosd(the)*la/2-si*sind(the)*sa/2+cc(2);
    if isa(g,'polylxgrain')
        gn(ii)=polylxgrain(get(g(ii),'id'),...
                           get(g(ii),'phase'),...
                           x,...
                           y,...
                           get(g(ii),'userdata'));
    else
        gn(ii).xcentre=cc(1);
        gn(ii).ycentre=cc(2);
        gn(ii).lao=lao;
        gn(ii).sao=mod(lao+90,180);
        gn(ii).la=la;
        gn(ii).sa=sa;
    end
    fwaitbar(ii/n,h);
end
close(h)