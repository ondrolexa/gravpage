function  [la,sa,lao]=fitpd(pd,ang);
%FITPD - return results of ellipse projection fit on paror results
% Syntax: [la,sa,lao,sao]=fitpd(pd);

% This file is part of polyLX.
% 
% polyLX is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% polyLX is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with polyLX.  If not, see <http://www.gnu.org/licenses/>.

% polyLX - MATLAB toolbox for microstructure analyses
% Copyright (C) 2010 Ondrej Lexa

global xdat ydat

xdat=1:180;
ydat=pd(:)';
 
% do estimates
[tt,ot]=max(pd);

% fit
r=fminsearch('fitelf',[tt/2 min(ydat)/2 ot],optimset('Display','off'));

la=abs(r(1));
sa=abs(r(2));
lao=mod(r(3),180);

%correct results
% swap
if(sa>la)
    tt=la; la=sa; sa=tt;
    lao=mod(lao+90,180);
end
