function id=lnisec(b,xp,yp)
%LNISEC Return intersection of lines or [] if do not intersect
% Pre:
%     b - boundary object
% xp,yp - [x1;x2] [y1;y2]
% Post:
% xi,yi - row vector of coordinates of intersection
% ua,ub - multipliers.

% This file is part of polyLX.
% 
% polyLX is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% polyLX is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with polyLX.  If not, see <http://www.gnu.org/licenses/>.

% polyLX - MATLAB toolbox for microstructure analyses
% Copyright (C) 2010 Ondrej Lexa

xi=[]; yi=[]; ua=[]; ub=[]; x=[]; y=[]; id=[];

if ~isa(b,'polylxboundary')
 return
end

for i=1:size(b,2)
 xt=get(b(i),'x');
 yt=get(b(i),'y');
 x=[x [xt(1:end-1) xt(2:end)]'];
 y=[y [yt(1:end-1) yt(2:end)]'];
 id=[id repmat(get(b(i),'id'),1,size(xt,1)-1)];
end

xpl=repmat(xp,1,size(x,2));
ypl=repmat(yp,1,size(x,2));
ud=(ypl(2,:)-ypl(1,:)).*(x(2,:)-x(1,:))-(xpl(2,:)-xpl(1,:)).*(y(2,:)-y(1,:));
ix=find(ud==0);
ud(ix)=repmat(nan,1,length(ix));
ua=((xpl(2,:)-xpl(1,:)).*(y(1,:)-ypl(1,:))-(ypl(2,:)-ypl(1,:)).*(x(1,:)-xpl(1,:)))./ud;
ub=((x(2,:)-x(1,:)).*(y(1,:)-ypl(1,:))-(y(2,:)-y(1,:)).*(x(1,:)-xpl(1,:)))./ud;
xi=x(1,:)+ua.*(x(2,:)-x(1,:));
yi=y(1,:)+ua.*(y(2,:)-y(1,:));

ix=intersect(find((ua>=0)&(ua<=1)),find((ub>=0)&(ub<=1)));
id=id(ix);

