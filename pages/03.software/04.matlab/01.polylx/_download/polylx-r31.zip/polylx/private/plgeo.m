function geom=plgeo(x,y) 
% PLGEO Geometry of a planar polygon
%
%   PLGEO(X,Y) returns geometry of the polygon 
%   specified by vertices in vectors X and Y.
%
%   PLGEO returns area, centroid location, perimeter
%   GEOM = [ area  perimeter  x_cen  y_cen ]

% This file is part of polyLX.
% 
% polyLX is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% polyLX is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with polyLX.  If not, see <http://www.gnu.org/licenses/>.

% polyLX - MATLAB toolbox for microstructure analyses
% Copyright (C) 2010 Ondrej Lexa

% check if inputs are same size
if ~isequal( size(x), size(y) ),
  error( 'X and Y must be the same size');
end

% number of vertices
x=shiftdim(x);
y=shiftdim(y);
n= size(x,1);

% temporarily shift data to mean of vertices for improved accuracy
xm=mean(x);
ym=mean(y);
x=x-xm*ones(n,1);
y=y-ym*ones(n,1);

% delta x and delta y
dx=x([2:n 1])-x;
dy=y([2:n 1])-y;

% sums  
A=sum(y.*dx-x.*dy)/2;
Axc=sum(6*x.*y.*dx-3*x.*x.*dy+3*y.*dx.*dx+dx.*dx.*dy )/12;
Ayc=sum(3*y.*y.*dx-6*x.*y.*dy-3*x.*dy.*dy-dx.*dy.*dy )/12;
P=sum( sqrt( dx.*dx +dy.*dy ) );

% centroidal moments
xc=Axc/A;
yc=Ayc/A;

% replace mean of vertices
x_cen=xc+xm;
y_cen=yc+ym;

% return values
geom=[A P x_cen y_cen];

% end of function PLGEO
