function res=dbcommand(command)
%DBCOMMAND  Send an SQL statement to a database

% This file is part of polyLX.
% 
% polyLX is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% polyLX is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with polyLX.  If not, see <http://www.gnu.org/licenses/>.

% polyLX - MATLAB toolbox for microstructure analyses
% Copyright (C) 2010 Ondrej Lexa

global polylx_prefs

try
    if strcmpi(polylx_prefs.driver,'SQlite3')
        res=mksqlite(polylx_prefs.connected,command);
    else
        curs=fetch(exec(polylx_prefs.connected,command));
        res=curs.Data';
        if strcmp('No Data',res)
            res=[];
        else
            %Convert according to mksqlite form
            fd=fieldnames(res);
            dc={};
            for i=1:length(fd)
                if isnumeric(res.(fd{i}))
                    dc=[dc num2cell(res.(fd{i}))];
                else
                    dc=[dc res.(fd{i})];
                end
            end
            res=cell2struct(dc,fd,2);
        end
    end
catch ME
    % If anything went wrong return an empty set
    disp(ME.message)
    res=[];
end
