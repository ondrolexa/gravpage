function fout = fwaitbar(x,name)
%FWAITBAR Fast display of wait bar.
%			H = FWAITBAR(X,'title') creates and displays a wait bar of
%			fractional length X.  The handle to the waitbar figure is
%			returned in H.  X should be between 0 and 1.  Each
%			subsequent call to waitbar, WAITBAR(X,H), extends the length
%			of the bar to the new position X.
%
%			FWAITBAR is a much speeded up version of WAITBAR (see help on
%			WAITBAR).

%			Olof Liungman.
%			Dept. of Oceanography, Earth Sciences Centre
%			G�teborg University, Sweden
%			E-mail: olof.liungman@oce.gu.se

x = max(0,min(100*x,100));

if isstr(name)

  pos = get(0,'ScreenSize');
  f = figure('MenuBar','none','Units','Pixels',...
             'Position',[pos(3)/2-180 pos(4)/2-37 360 75], ...
             'Resize','off','NumberTitle','off',...
             'Name','Please wait...','Pointer','watch',...
             'Color','w');
  if ~strcmp(computer,'PCWIN')
    set(f,'DefaultTextFontSize',12)
    set(f,'DefaultAxesFontSize',12)
  end
  colormap([])

  axes('XLim',[0 100],'YLim',[0 1],'Box','on','Position',...
       [.05 .30 .9 .30],'YTick',[],'XColor','k','YColor','k');
  title(name,'Color','k')

  xpatch = [0 x x 0];
  ypatch = [0 0 1 1];
  p = patch(xpatch,ypatch,'r','Edgecolor','r','EraseMode','none');
  set(f,'UserData',p)

else

  p = get(name,'UserData');
  xpatch = get(p,'xdata');
  xpatch = [xpatch(2) x x xpatch(2)];
  set(p,'Xdata',xpatch)

end

drawnow

if nargout==1,
  fout = f;
end

