function dbclose
%DBCLOSE Close the connection to the database

% This file is part of polyLX.
% 
% polyLX is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% polyLX is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with polyLX.  If not, see <http://www.gnu.org/licenses/>.

% polyLX - MATLAB toolbox for microstructure analyses
% Copyright (C) 2010 Ondrej Lexa

global polylx_prefs
try
    if strcmpi(polylx_prefs.driver,'SQlite3')
        mksqlite(polylx_prefs.connected, 'close');
    else
        close(polylx_prefs.connected);
    end
    polylx_prefs=rmfield(polylx_prefs,'connected');
end
