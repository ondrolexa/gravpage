function display(g)
%DISPLAY Command window display of a grain

% This file is part of polyLX.
% 
% polyLX is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% polyLX is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with polyLX.  If not, see <http://www.gnu.org/licenses/>.

% polyLX - MATLAB toolbox for microstructure analyses
% Copyright (C) 2010 Ondrej Lexa

n = length(g); 
if n == 0
    disp(' ');
    disp([inputname(1),' is empty polylxgrain object. ']);
    disp(' ');
elseif n == 1
    disp(' ');
    disp([inputname(1),' = ']);
    disp(' ');
    disp(['Grain ID = ' num2str(g.id)]);
    disp(['Phase = ' g.phase]);
    disp(['Area = ' num2str(g.area)]);
    disp(['Perimeter = ' num2str(g.perimeter)]);
    disp(['Length = ' num2str(g.length)]);
    disp(['Width = ' num2str(g.width)]);
    disp(['Orientation = ' num2str(g.orientation)]);
    disp(['No. of holes = ' num2str(g.nholes)]);
    if ~isempty(fieldnames(g.userdata))
        disp('Userdata: ');
        disp(g.userdata);
    else
        disp(' ');
    end
else
    disp(' ');
    disp([inputname(1),' = ']);
    disp(' ');
    disp(['Set of ' num2str(n) ' grain objects']);
    disp(['Number of phases = ' num2str(length(gplist(g)))]);
    disp(['Total area = ' num2str(sum(cat(1,g.area)))]);
    disp(' ');
end
