function g2 = set(g,ix,varargin)
%SET set grain properties

% This file is part of polyLX.
% 
% polyLX is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% polyLX is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with polyLX.  If not, see <http://www.gnu.org/licenses/>.

% polyLX - MATLAB toolbox for microstructure analyses
% Copyright (C) 2010 Ondrej Lexa

if nargin>1
    if isa(ix,'char')
        varargin=[ix varargin];
        ix=1:length(g);
    end
end
g2=g;
if length(varargin)>1
    noerr=0;
    for i=1:2:length(varargin);
        switch lower(varargin{i})
            case 'phase'
                [g2(ix).phase] = deal(varargin{i+1});
            
            case 'userdata'
                if nargin>i+2
                    u = get(g(ix),'userdata');
                    [u.(varargin{i+1})] = deal(varargin{i+2});
                    for ii=1:length(ix)
                        g2(ix(ii)).userdata = u(ii);
                    end
                elseif nargin>i+1 && isa(varargin{i+1},'struct')
                    for ii=1:length(ix)
                        g2(ix(ii)).userdata = varargin{i+1};
                    end
                else
                    error('Userdata have to be structure.')
                end
                noerr=1;
            
            otherwise
                if ~noerr
                    error([varargin{i},' is not valid grain property.']);
                else
                    noerr=0;
                end
        end
    end
else
    disp('Available grain properties are:');
    disp('  Phase');
    disp('  UserData');
    clear g2
end
