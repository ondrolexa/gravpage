function b = polylxboundary(id,ixa,ixb,phasea,phaseb,x,y,udata)
%POLYLXBOUNDARY Create boundary object
%   b = POLYLXBOUNDARY(id,ixa,ixb,typa,typb,x,y) create a boundary object
%   from vectors of coordinates x,y with type name p and id.
%   ixa and ixb are grain indexes.

% This file is part of polyLX.
% 
% polyLX is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% polyLX is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with polyLX.  If not, see <http://www.gnu.org/licenses/>.

% polyLX - MATLAB toolbox for microstructure analyses
% Copyright (C) 2010 Ondrej Lexa

if nargin==7
    udata=struct;
end
if nargin == 0
    b=struct('id',[],...
        'ixa',[],...
        'ixb',[],...
        'phasea',[],...
        'phaseb',[],...
        'type',[],...
        'x',[],...
        'y',[],...
        'cumlength',[],...
        'length',[],...
        'width',[],...
        'orientation',[],...
        'userdata',struct);
    b=class(b,'polylxboundary');
elseif isa(id,'polylxboundary')
    b=id;
elseif nargin >= 7
    % Check if coords are hex string or wkt
    if ischar(x)
        if isa(y,'int8')
            y=char(y');
        end
        if ischar(y)
            if strcmpi(x,'WKT')
                co=sscanf(y(strfind(y,'(')+1:strfind(y,')')-1),'%f %f,',[2,inf]);
                x=co(1,:);
                y=co(2,:);
            else
                x=typecast(uint8(hex2dec(reshape(x,[],2))),'double');
                y=typecast(uint8(hex2dec(reshape(y,[],2))),'double');
            end
        end
    end
    %check double vertex
    ii=[1;1+find(abs(diff(x))>1e-12|abs(diff(y))>1e-12)];
    x = x(ii); y = y(ii);
    %check u-turn lines
    if find(diff(atan2(diff(x),diff(y)))==pi,1);
        fprintf('Check line ID:%d for topology... Line U-turn found.\n',id)
    end
    b=struct('id',id,...
        'ixa',ixa,...
        'ixb',ixb,...
        'phasea',phasea,...
        'phaseb',phaseb,...
        'type',[],...
        'x',x(:),...
        'y',y(:),...
        'cumlength',[],...
        'length',[],...
        'width',[],...
        'orientation',[],...
        'userdata',udata);
    % Set type and length info
    if ~isempty(phaseb)
        tt=sortrows({phasea;phaseb});
        b.type=[tt{1} '-' tt{2}];
    else
        b.type=phasea;
    end
    b.cumlength=sum(sqrt(diff(b.x).^2+diff(b.y).^2));
    [la,sa,or]=diamor(x,y);
    b.length=la;
    b.width=sa;
    b.orientation=or;
    b=class(b,'polylxboundary');
else
    disp('Wrong number of arguments');
end

% begin of subfunction DIAMOR

function [la,sa,or]=diamor(x,y)

dt=[x y];
m=size(dt,1);
p=(m-1):-1:2;
k=zeros(m*(m-1)/2,1);
k(cumsum([1 p]))=1;
k=cumsum(k);
j=ones(m*(m-1)/2,1);
j(cumsum(p)+1)=2-p;
j(1)=2;
j=cumsum(j);
l=(dt(k,:)-dt(j,:))';
l=sum(l.^2);
l=sqrt(l);
n=size(l,2);
m=(1+sqrt(1+8*n))/2;
z=zeros(m);
k=ones(n,1);
j=[1 (m-1):-1:2]';
k(cumsum(j))=(2:m);
z(cumsum(k))=l';
z = z + z';
[z1,p1]=max(z);
[la,p2]=max(z1);
p1=p1(p2);
dp=dt(p2,:)-dt(p1,:);
rv=dp/sqrt(dp*dp');
rv=[rv(2);-rv(1)]; % unit perpendicular vector
pp=(dt*rv); % projection onto rv
sa=(max(pp)-min(pp));
or=atan2(dp(1),dp(2))*180/pi;
if or<0
    or=or+180;
end

