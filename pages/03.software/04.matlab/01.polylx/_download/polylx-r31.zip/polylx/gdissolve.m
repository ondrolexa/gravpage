function gn=gdissolve(g,b)
%GDISSOLVE Dissolve shared boundaries between same phase grains.
% Syntax: gn=gdissolve(g,b);
% g is grain object and b is boundary object
% number and indexes of grains dissolved into resulted objects are stored
% in userdata.

% This file is part of polyLX.
% 
% polyLX is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% polyLX is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with polyLX.  If not, see <http://www.gnu.org/licenses/>.

% polyLX - MATLAB toolbox for microstructure analyses
% Copyright (C) 2010 Ondrej Lexa

if ~isa(g,'polylxgrain')
    error('First argument must be grain objects');
end

if nargin<2
    b=bmake(g);
end

%make list of like-like boundaries
gn=[];
pl=gplist(g);
nn=length(pl);
h=fwaitbar(0,'Dissolving boundaries...');

for ii=1:nn

    ix=gpsel(g,pl{ii});
    while ~isempty(ix)
        %take next aggregate
        cl=getpclust(g,b,ix(1));
        n=length(cl);
        if n>1
            % process aggregate
            co=zeros(0,2);
            cn=sparse([],[],[],1,1,0);
            for i=1:n
                %outline
                xy=get(g(cl(i)),'x','y');
                addtograph(xy)
                %holes
                hol=get(g(cl(i)),'holes');
                for j=1:get(g(cl(i)),'nholes');
                    xy=[hol(j).x hol(j).y];
                    addtograph(xy)
                end
                fwaitbar((ii-1)/nn+i/n/nn,h);
            end
            % remove shared segments
            [r,c]=find(((cn~=0)+(cn~=0)')==2);
            for j=1:length(r)
                cn(r(j),c(j))=0;
            end
            % construct
            res={};
            while nnz(cn)
                [r,c]=find(cn,1);
                cn(r,c)=0;
                xy=co([r,c],:);
                while c~=r
                    c2=find(cn(c,:));
                    cn(c,c2)=0;
                    xy=[xy;co(c2,:)];
                    c=c2;
                end
                res=[res xy];
            end

            %create grain
            xy=res{1};
            for j=2:length(res)
                xy=[xy;[NaN NaN];res{j}];
            end
            gn=[gn polylxgrain(get(g(cl(1)),'id'),pl{ii},xy(:,1),xy(:,2),struct('ngrains',length(cl),'ix',cl))];
        else
            % process isolated grain
            gg=g(cl);
            gg=set(gg,'userdata',struct('ngrains',1,'ix',cl));
            gn=[gn gg];
        end
        % remove dissolved indexes from todo list
        ix=setdiff(ix,cl);
    end
end
%done
close(h)

%%------------------------------------------------------
    % nested function
    function addtograph(xy)
        for k=1:size(xy,1)-1
            [~,~,nfrom]=intersect(xy(k,:),co,'rows');
            if isempty(nfrom)
                co=[co;xy(k,:)];
                nfrom=size(co,1);
            end
            [~,~,nto]=intersect(xy(k+1,:),co,'rows');
            if isempty(nto)
                co=[co;xy(k+1,:)];
                nto=size(co,1);
            end
            cn(nfrom,nto)=k;
        end
    end
end