function dbcreate
%DBCREATE Create empty PolyLX database.
% Syntax:  dbcreate

% This file is part of polyLX.
% 
% polyLX is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% polyLX is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with polyLX.  If not, see <http://www.gnu.org/licenses/>.

% polyLX - MATLAB toolbox for microstructure analyses
% Copyright (C) 2010 Ondrej Lexa

global polylx_prefs

avdrivers={'SQlite3','MySQL'};

if ~exist('polylx_prefs','var')
    ok=false;
else
    if ~isfield(polylx_prefs,'server')|~isfield(polylx_prefs,'database')|~isfield(polylx_prefs,'username')|~isfield(polylx_prefs,'password')|~isfield(polylx_prefs,'driver')|~(~isempty(polylx_prefs.server)&~isempty(polylx_prefs.database)&~isempty(polylx_prefs.username)&~isempty(polylx_prefs.driver))
        ok=false;
    else
        ok=true;
    end
end

while ~ok
    [sel,ok]=listdlg('ListString',avdrivers,'SelectionMode','single','ListSize',[120 50],'Name','Connection','PromptString','Select database type');
    if isempty(sel)
        return
    end
    driver=avdrivers{sel};
    switch driver
        case 'SQlite3'
            [fname,path] = uiputfile('*.plx','PolyLX database');
            if isa(fname,'double')
                clear global polylx_prefs
                return
            end
            polylx_prefs=struct('server',fullfile(path,fname),'driver',driver);
            ok=true;
        case 'MySQL'
            answer=inputdlg({'Database server:','Database:','Username:','Password:'},'Database connection',1,{'localhost','polylx','',''});
            if isempty(answer)
                clear global polylx_prefs
                return
            end
            polylx_prefs=struct('server',answer{1},'database',answer{2},'username',answer{3},'password',answer{4},'driver',driver);
            ok=~isempty(polylx_prefs.server)&~isempty(polylx_prefs.database)&~isempty(polylx_prefs.username)&~isempty(polylx_prefs.driver);
    end
end

if strcmpi(polylx_prefs.driver,'SQlite3')
    sql = {'PRAGMA synchronous=OFF','PRAGMA journal_mode=OFF','PRAGMA encoding=''UTF-8'''};
    sql = [sql 'DROP TABLE IF EXISTS samples'];
    sql = [sql 'CREATE TABLE samples (id integer NOT NULL PRIMARY KEY AUTOINCREMENT, name varchar NOT NULL, label varchar NULL, X double NULL DEFAULT 0, Y double NULL DEFAULT 0)'];
    sql = [sql 'DROP TABLE IF EXISTS grains'];
    sql = [sql 'CREATE TABLE grains (id integer NOT NULL PRIMARY KEY AUTOINCREMENT, id_sample integer NOT NULL, id_grain integer NOT NULL, phase varchar NOT NULL, X double NULL DEFAULT 0, Y double NULL DEFAULT 0)'];
    sql = [sql 'DROP TABLE IF EXISTS boundaries'];
    sql = [sql 'CREATE TABLE boundaries (id integer NOT NULL PRIMARY KEY AUTOINCREMENT, id_sample integer NOT NULL, id_boundary integer NOT NULL, id_graina integer NOT NULL, id_grainb integer NOT NULL, phasea varchar NOT NULL, phaseb varchar NOT NULL, X double NULL DEFAULT 0, Y double NULL DEFAULT 0)'];
    try
        dbconn = mksqlite(0, 'open', polylx_prefs.server);
        for i=1:length(sql)
            mksqlite(dbconn,sql{i});
        end
        polylx_prefs=setfield(polylx_prefs,'connected',dbconn);
    catch
        disp('Error occured during database connection.')
        clear global polylx_prefs
    end
else
    sql = {'DROP TABLE IF EXISTS samples'};
    sql = [sql 'CREATE TABLE samples (id int(10) unsigned NOT NULL auto_increment, name varchar(20) collate latin1_general_ci default NOT NULL, label varchar(10) collate latin1_general_ci default NULL, X float default NULL, Y float default NULL, PRIMARY KEY (id)) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci'];
    sql = [sql 'DROP TABLE IF EXISTS grains'];
    sql = [sql 'CREATE TABLE grains (id int(10) unsigned NOT NULL auto_increment, id_sample int(10) unsigned default NULL, id_grain int(10) unsigned default NULL, phase varchar(20) collate latin1_general_ci default NULL, geometry polygon default NULL, PRIMARY KEY (id)) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci'];
    sql = [sql 'DROP TABLE IF EXISTS boundaries'];
    sql = [sql 'CREATE TABLE boundaries (id int(10) unsigned NOT NULL auto_increment, id_sample int(10) unsigned default NULL, id_boundary int(10) unsigned default NULL, id_graina int(10) unsigned default NULL, id_grainb int(10) unsigned default NULL, phasea varchar(20) collate latin1_general_ci default NULL, phaseb varchar(20) collate latin1_general_ci default NULL, geometry linestring default NULL, PRIMARY KEY (id)) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci'];
    dbconn = database(polylx_prefs.database,polylx_prefs.username,polylx_prefs.password,'com.mysql.jdbc.Driver',['jdbc:mysql://' polylx_prefs.server '/' polylx_prefs.database]);
    if ~isempty(dbconn.Message)
        disp(dbconn.Message)
        clear global polylx_prefs
        return
    else
        for i=1:length(sql)
            fetch(exec(dbconn,sql{i}));
        end
        polylx_prefs=setfield(polylx_prefs,'connected',dbconn);
    end
end
