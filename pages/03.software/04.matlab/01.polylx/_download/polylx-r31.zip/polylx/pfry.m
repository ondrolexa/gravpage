function pfry(g)
%PFRY Make Fry's plot to detemine the strain ellipse.
% Syntax: pfry(g);

% This file is part of polyLX.
% 
% polyLX is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% polyLX is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with polyLX.  If not, see <http://www.gnu.org/licenses/>.

% polyLX - MATLAB toolbox for microstructure analyses
% Copyright (C) 2010 Ondrej Lexa

if nargin<1
    help pfry
    return
end
if ~isa(g,'polylxgrain')
    help pfry
    return
end


x=get(g,'xcentre');
y=get(g,'ycentre');
poc=length(x);

tri=delaunay(x,y);
nnd=[];
for j=1:poc
    [xi,dummy]=find(tri==j);
    w=tri(xi,:);
    w=setdiff(w(:),j);
    dt=sqrt(sum(([x(w) y(w)]-repmat([x(j) y(j)],length(w),1)).^2'));
    nn=min(dt);
    nnd=[nnd;nn];
end
mn=mean(nnd);

xnew=[];
ynew=[];
h=fwaitbar(0,'Please wait for computations to be done');
for i=1:poc
    dxx=x-x(i);
    dyy=y-y(i);
    w=find((dxx.^2+dyy.^2)<12*mn^2);
    xnew=[xnew;dxx(w)];
    ynew=[ynew;dyy(w)];
    fwaitbar(i/length(x),h);
end
close(h);

cla
hold on
plot(xnew,ynew,'r.')
plot(0,0,'k.')
title('Fry''s Plot');
set(gca,'xlim',[min(xnew),max(xnew)],'ylim',[min(ynew),max(ynew)]);
axis equal
hold off
