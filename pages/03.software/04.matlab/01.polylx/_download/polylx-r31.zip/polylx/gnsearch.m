function [id,idmore,idless]=gnsearch(g,b,ph1,ph2,treshold,opt)
%GNSEARCH Return grains of phase ph1 which share boundary with phase ph2.
% Routine return as well grains which share more/less than treshold.
% Syntax:  [id,idmore,idless]=gnsearch(g,b,ph1,ph2,treshold);
%   ph1      ... searched phase
%   ph2      ... enclosing phase
%   treshold ... treshold value for perimeter fraction. Default 0.5
%   opt      ... 0... boundary grains are not used. Default
%            ... 1... boundary grains are used

% This file is part of polyLX.
% 
% polyLX is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% polyLX is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with polyLX.  If not, see <http://www.gnu.org/licenses/>.

% polyLX - MATLAB toolbox for microstructure analyses
% Copyright (C) 2010 Ondrej Lexa

if nargin<4
    error('Not enough arguments.');
end

if nargin<5
    treshold=0.5;
end

if nargin<6
    opt=0;
end

rp=[];
rid=[];
tt=sort({ph1,ph2});
btype=strcat(tt{1},'-',tt{2});
ix=gpsel(g,ph1);
ixa=get(b,'ixa');
ixb=get(b,'ixb');
for i=1:length(ix);
   ib=union(find(ixa==ix(i)),find(ixb==ix(i)));
   if ~isempty(ib)
      per=get(g(ix(i)),'perimeter');
      cltot=sum(get(b(ib),'cumlength'));
      if opt==0
          if cltot/per>0.99999 % bad way to test border grains
              cltyp=sum(get(b(ib(btsel(b(ib),btype))),'length'));
              rp=[rp cltyp/cltot];
              rid=[rid ix(i)];
          end
      else
          cltyp=sum(get(b(ib(btsel(b(ib),btype))),'length'));
          rp=[rp cltyp/cltot];
          rid=[rid ix(i)];
      end
   else % isolated grains
       if opt==1
           rp=[rp 0];
           rid=[rid ix(i)];
       end
   end
end
id=rid(rp==treshold);
idmore=rid(rp>treshold);
idless=rid(rp<treshold);
