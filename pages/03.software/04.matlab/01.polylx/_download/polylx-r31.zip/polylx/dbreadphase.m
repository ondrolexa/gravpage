function g=dbreadphase(samples,phase)
%DBREADPHASE Read all grains of choosen phase from database.
% Syntax:  g=dbreadphase;
%          g=dbreadphase(samples,phase);
% samples should be cell array (see dbselect) while phase string

% This file is part of polyLX.
% 
% polyLX is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% polyLX is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with polyLX.  If not, see <http://www.gnu.org/licenses/>.

% polyLX - MATLAB toolbox for microstructure analyses
% Copyright (C) 2010 Ondrej Lexa

global polylx_prefs
%Check connection
if dbconnect
    if nargin<1
        res=dbcommand(['SELECT name FROM samples']);
        samples={res.name};
        if isempty(samples)
            disp('No samples in open database. Aborting.');
            g=[];
            dbclose
            return
        end
    end
    if nargin<2
        up={};
        for i=1:length(samples)
            upt=dbcommand(['SELECT phase FROM grains INNER JOIN samples ON (grains.id_sample=samples.id) WHERE samples.name="' samples{i} '" ORDER BY phase']);
            up=union(up,{upt.phase});
        end
        [sel,ok] = listdlg('ListString',up,'SelectionMode','single','Name','Select sample');
        if ok==0
            g=[];
            dbclose;
            return
        else
            phase=up{sel};
        end
    end
    ii=1;
    for k=1:length(samples)
        if strcmpi(polylx_prefs.driver,'SQlite3')
            res=dbcommand(['SELECT grains.id_grain, grains.X, grains.Y FROM grains INNER JOIN samples ON samples.id=grains.id_sample WHERE grains.phase="' phase '" AND samples.name="' samples{k} '" ORDER BY grains.id']);
        else
            res=dbcommand(['SELECT grains.id_grain, ''WKT'' as X, AsText(geometry) as Y FROM grains INNER JOIN samples ON samples.id=grains.id_sample WHERE grains.phase="' phase '" AND samples.name="' samples{k} '" ORDER BY grains.id']);
        end
        poc=length(res);
        if poc>0
            g(ii:poc+1)=polylxgrain;
            h=fwaitbar(0,['Reading grains ' num2str(k) ' of ' num2str(length(samples)) ' from database...']);
            for i=1:poc;
                g(ii+i-1)=polylxgrain(res(i).id_grain,samples{k},res(i).X,res(i).Y);
                fwaitbar(i/poc,h);
            end
            ii=ii+poc;
            close(h)
        end
    end
    dbclose;
end

