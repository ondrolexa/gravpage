function [chis,chiv]=paniso(g,varargin)
%PANISO Plot phase spatial distribution anisotropy plot
% Routine calculate deviations from uniform distribution of grain centres
% for different directions for individual phases. Maximum indicate
% direction with maximum clustering. Confindence interval for uniformity is
% marked by black lines.
% Syntax: chis=paniso(g,options);
% g must be grain object(s)
% options are passed as pairs of option name and option value:
% 'bins'    ... number of bins to evaluate distyribution Default 18.

% This file is part of polyLX.
% 
% polyLX is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% polyLX is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with polyLX.  If not, see <http://www.gnu.org/licenses/>.

% polyLX - MATLAB toolbox for microstructure analyses
% Copyright (C) 2012 Ondrej Lexa

if nargin<1
    help paniso
    chis=[];
    return
end
if ~isa(g,'polylxgrain')
    help paniso
    chis=[];
    return
end

% Process input arguments
opts.bins=18;
opts=parseargs(varargin,opts);
if opts.bins<2
    opts.bins=2;
end

% Initialize
ph=gplist(g);
chis=[];

for i=1:length(ph);
    gg=g(gpsel(g,ph{i}));
    
    un=length(gg)/opts.bins;
    [x,y]=get(gg,'xcentre','ycentre');

    % Rotate and project centres
    nn=[cosd(1:180);-sind(1:180)];
    ff=[x y]*nn;

    % Calculate deviations from uniform
    ch=[];
    pp=[];
    for ii=1:180
        mn=min(ff(:,ii));
        mx=max(ff(:,ii));
        ed=linspace(mn,mx,opts.bins+1);
        n=histc(ff(:,ii),ed);
        n(end-1)=n(end-1)+n(end);
        n=n(1:end-1);
        ch=[ch sum(sum((n-un).^2/un))];
    end
    chis=[chis;ch];
end

% Plot
h=plot(0:180,[chis(:,end) chis]);
line([0 180],[2*gammaincinv(0.975,(opts.bins-1)/2) 2*gammaincinv(0.975,(opts.bins-1)/2)],'color','k');
line([0 180],[2*gammaincinv(0.025,(opts.bins-1)/2) 2*gammaincinv(0.025,(opts.bins-1)/2)],'color','k');
legend(h,ph)
xlabel('Direction')
ylabel('Chi square test of uniformity')
title('Phase spatial distribution anisotropy plot')
