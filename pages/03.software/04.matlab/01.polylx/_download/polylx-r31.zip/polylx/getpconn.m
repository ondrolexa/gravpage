function r=getpconn(g,b,varargin)
%GETPCONN Return connectivity index for individual phases.
% Syntax: res=getpconn(g,b,options);
% Return number of all grains, number of isolated grains
% and bulk connectivity (0-1)
% options are passed as pairs of option name and option value:
% 'format'     ... 'cell'...return cell arrays ready for txtwrite.
%                  'num' ...numeric array. Default 'cell'.

% This file is part of polyLX.
% 
% polyLX is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% polyLX is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with polyLX.  If not, see <http://www.gnu.org/licenses/>.

% polyLX - MATLAB toolbox for microstructure analyses
% Copyright (C) 2010 Ondrej Lexa

if nargin<1
   help getpconn
   return
end

if nargin<2
    b=bmake(g);
end

% Process input arguments
opts.format='cell';
opts=parseargs(varargin,opts);

% Initialize
phlist=gplist(g);
r=[];

% Generate connectivity matrix
cm=getcm(g,b);

% Calculate connectivity for individual phases
for i=1:length(phlist)
    ix=gpsel(g,phlist{i});
    cmt=cm(ix,ix);
    poc=length(ix);
    if full(any(any(cmt)))
        vl=1:poc;
        clear pm;
        l=[];
        
        while (~isempty(vl))
            pvl=ggclust(cmt,vl(1));
            l=[l;length(pvl)];
            vl=setdiff(vl,pvl);
        end
        
        b0=length(find(l==1));
        bc=sum(l)-b0;
        cc=l(l~=1);
        cc(:,2)=cc(:,1)./(b0+bc);
        c=unique(cc(:,1));
        for k=1:length(c)
            c(k,2)=sum(cc(cc(:,1)==c(k),2));
        end
        r=[r;[poc b0 sum(c(:,2))]];
    else
        r=[r;[poc poc 0]];
    end
end

if strcmpi(opts.format,'cell')
    r=[{'Phase' 'N' 'Niso' 'Conn'};phlist num2cell(r)];
end


%---------------------- Functions ------------------------%
function v=ggclust(cm,vl)
% get grains cluster contain grain/s vl
i=1;
v=ggneigh(cm,vl);
top=length(v);
while i<=top
    u=setdiff(ggneigh(cm,v(i)),v);
    v=[v;u(:)];
    top=length(v);
    i=i+1;
end

function v=ggneigh(cm,vl)
% get grain/s neighbours
v=vl;
for i=1:length(vl)
    u=(find(cm(:,vl(i))==1));
    v=union(v,u);
end
v=v(:);
