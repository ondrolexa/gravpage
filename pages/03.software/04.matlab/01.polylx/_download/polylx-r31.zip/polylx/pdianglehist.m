function stat=pdianglehist(da,varargin)
%PDIANGLEHIST Plot histogram of chosen dihedral angles.
%Syntax: stat=pdianglehist(da,options);
%For options see PHISTNORM

% This file is part of polyLX.
% 
% polyLX is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% polyLX is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with polyLX.  If not, see <http://www.gnu.org/licenses/>.

% polyLX - MATLAB toolbox for microstructure analyses
% Copyright (C) 2010 Ondrej Lexa

stat=[];
if nargin<1
    help pdianglehist
    return
end
if ~isa(da,'cell')
    help pdianglehist
    return
end

while true
    [tx,c]=listdlg('ListString',da(2:end,1),'Name','Choose boundary type','ListSize',[150 200],'CancelString','Exit','SelectionMode','single');
    if c==0
        return
    end

    [phx,c]=listdlg('ListString',da(1,2:end),'Name','Choose oposite phase','ListSize',[150 200],'CancelString','Exit','SelectionMode','single');
    if c==0
        return
    end

    dt=da{tx+1,phx+1};
    if length(dt)>1
        [stat,tt]=phistnorm(dt,varargin{:});
        title([da{tx+1,1} '--<' da{1,phx+1} '  ' tt])
    end
end