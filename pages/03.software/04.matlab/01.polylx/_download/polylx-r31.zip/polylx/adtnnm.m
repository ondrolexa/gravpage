function adtnnm(g)
%ADTNNM The Delaunay triangulation nearest neighbor method to detemine the strain.
%         after Mulchrone(2002)
% Syntax: adtnnm(g);

% This file is part of polyLX.
% 
% polyLX is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% polyLX is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with polyLX.  If not, see <http://www.gnu.org/licenses/>.

% polyLX - MATLAB toolbox for microstructure analyses
% Copyright (C) 2010 Ondrej Lexa

if nargin<1
    help adtnnm
    return
end
if ~isa(g,'polylxgrain')
    help adtnnm
    return
end


global xdat ydat hel

gg=gfitel(g);
x=get(gg,'xcentre');
y=get(gg,'ycentre');
la=get(gg,'la');
sa=get(gg,'sa');
tri=delaunay(x,y);
k=convhull(x,y);
ix=find(~ismember(tri(:,1),k)&~ismember(tri(:,2),k)&~ismember(tri(:,3),k));

I=[tri(ix,1);tri(ix,1);tri(ix,2)];
J=[tri(ix,2);tri(ix,3);tri(ix,3)];

dx=x(I)-x(J);
dy=y(I)-y(J);
d=sqrt(dx.^2+dy.^2);
phi=atan2(dx,dy);
dn=d./(sqrt(la(I).*sa(I))/2+sqrt(la(J).*sa(J))/2);

ydat=[1./(dn.^2);1./(dn.^2)];
xdat=[phi;phi+pi];
xdat(xdat>pi)=xdat(xdat>pi)-2*pi;

r=fminsearch('fitrs',[0 0 0],optimset('Display','off','TolFun',1e-8,'TolX',1e-8));
fs2=atan(r(2)/r(1));
rs=sqrt((r(3)*cos(fs2)+r(1))/(r(3)*cos(fs2)-r(1)));
theta=180*fs2/2/pi;
if rs<1
   rs=1/rs;
   theta=theta+90;
end
if phi>180
 theta=theta-90;
end

clear xdat ydat

x=sin(phi).*dn;
y=cos(phi).*dn;

plot(x,y,'k.',-x,-y,'k.');
axis equal
set(gca,'UserData',[-2*rs 2*rs -2*rs 2*rs]);
axis(get(gca,'UserData'));
hel=pellipse(sqrt(rs),1/sqrt(rs),theta,[0 0],'r');
set(hel,'LineWidth',2);
title(['Strain ratio:' num2str(rs) ' Orientation:' num2str(theta)]);

h0 = gcf;
set(gca,'Units','pixels','Position',[31 70 501 322]);
uicontrol('Parent',h0, ...
	'Units','points', ...
	'BackgroundColor',[0.752941176470588 0.752941176470588 0.752941176470588], ...
	'Callback','global hel; delete(hel); h=findobj(''Tag'',''OrSlider''); theta=get(h,''Value''); h=findobj(''Tag'',''RsSlider''); rs=get(h,''Value'');  hel=pellipse(sqrt(rs),1/sqrt(rs),theta,[0 0],''r''); set(hel,''LineWidth'',2); axis(get(gca,''UserData'')); title([''Strain ratio:'' num2str(rs) '' Orientation:'' num2str(theta)]);', ...
	'ListboxTop',0, ...
	'Max',2*rs, ...
	'Min',1, ...
	'Position',[22.5 10.5 179.25 13.5], ...
	'Style','slider', ...
	'Tag','RsSlider', ...
	'Value',rs);
uicontrol('Parent',h0, ...
	'Units','points', ...
	'BackgroundColor',[0.752941176470588 0.752941176470588 0.752941176470588], ...
   'Callback','global hel; delete(hel); h=findobj(''Tag'',''OrSlider''); theta=get(h,''Value''); h=findobj(''Tag'',''RsSlider''); rs=get(h,''Value'');  hel=pellipse(sqrt(rs),1/sqrt(rs),theta,[0 0],''r''); set(hel,''LineWidth'',2); axis(get(gca,''UserData'')); title([''Strain ratio:'' num2str(rs) '' Orientation:'' num2str(theta)]);', ...
	'ListboxTop',0, ...
	'Max',180, ...
	'Position',[219.75 10.5 179.25 13.5], ...
	'Style','slider', ...
	'Tag','OrSlider', ...
	'UserData','[ ]', ...
	'Value',theta);
uicontrol('Parent',h0, ...
	'Units','points', ...
	'BackgroundColor',[0.752941176470588 0.752941176470588 0.752941176470588], ...
	'ListboxTop',0, ...
	'Position',[63 26.25 102 10.5], ...
	'String','Strain ratio', ...
	'Style','text', ...
	'Tag','StaticText1');
uicontrol('Parent',h0, ...
	'Units','points', ...
	'BackgroundColor',[0.752941176470588 0.752941176470588 0.752941176470588], ...
	'ListboxTop',0, ...
	'Position',[261.75 26.25 102 10.5], ...
	'String','Orientation', ...
	'Style','text', ...
	'Tag','StaticText1');
