function pal=makepal(g,prop,varargin)
%MAKEPAL Routine to generate universal color palette for plot.
% Syntax:  pal=makepal(g,prop);
%          pal=makepal(g,prop,options);
% g can be grain and boundary object(s)
%   prop - double or cell array of values on which the pallette is based.
%          Must have same number of elements as g
%          when prop is color table (genct) it will be converted to palette
% options are passed as pairs of option name and option value:
%  'type'     ... 'unique' or 'gradual'. Default 'unique'.
%  'method'   ... 'auto' or 'manual'. Default 'auto'.
%  'nbins'    ... Number of bins. Default 10. When vector it defines edges
%                 of bins
%  'flip'     ... 0.. normal 1.. flip color order. Default 0
%  'colormap' ... Default 'jet'. Could be any MATLAB colormap.

% This file is part of polyLX.
% 
% polyLX is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% polyLX is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with polyLX.  If not, see <http://www.gnu.org/licenses/>.

% polyLX - MATLAB toolbox for microstructure analyses
% Copyright (C) 2010 Ondrej Lexa

%TODO graduate manual

if nargin<2
    switch class(g)
        case 'polylxgrain'
            prop=get(g,'phase');
        case 'polylxboundary'
            prop=get(g,'type');
        otherwise
            error('First argument must be grain or boundary object!');
    end
end

opts.type='unique';
opts.method='auto';
opts.nbins=10;
opts.flip=0;
opts.colormap='jet';
opts=parseargs(varargin,opts);
        
poc=length(g);
pal=cell(poc,3);

if size(prop,2)==2 % color table passed instead properties
    pal=[repmat({[0]},poc,1) repmat({''},poc,1) repmat({[0 0 0]},poc,1)];
    gpl=get(g,'phase');
    for i=1:length(prop);
        ix=strcmp(prop{i,1},gpl);
        pal(ix,1)={i};
        pal(ix,2)={[prop{i,1} ' (' num2str(length(find(ix))) ')']};
        pal(ix,3)=prop(i,2);
    end
else
    if strcmpi(opts.type,'unique')
        if strcmp(class(prop),'double')
            prop=cellstr(num2str(prop(:)));
        end
        if ischar(prop)
            prop=cellstr(prop);
        end
        zoz=unique(prop);
        % Create autopallete
        cpal=eval([opts.colormap sprintf('(%d)',length(zoz))]);
        if opts.flip
            cpal=flipud(cpal);
        end
        if strcmpi(opts.method,'manual')
            for i=1:length(zoz)
                ac=uisetcolor(cpal(i,:),['Define color for class ' zoz{i}]);
                if length(ac)==3
                    cpal(i,:)=ac;
                end
            end
        end
        for i=1:length(zoz);
            ix=strcmp(zoz{i},prop);
            pal(ix,1)={i};
            pal(ix,2)={[zoz{i} ' (' num2str(length(find(ix))) ')']};
            pal(ix,3)={cpal(i,:)};
        end
    elseif strcmpi(opts.type,'gradual')
        if ~strcmp(class(prop),'double')
            error('For graduate pallete values must be numeric')
        end
        % Create autopallete
        if length(opts.nbins)==1
            cpal=eval([opts.colormap sprintf('(%d)',opts.nbins)]);
            if opts.flip
                cpal=flipud(cpal);
            end
            % Natural breaks
            if isa(g,'polylxgrain')
                a=get(g,'area');
            else
                a=get(g,'cumlength');
            end
            [ps,ix]=sort(prop);
            ed=round(interp1(cumsum(a(ix))/sum(a),1:length(a),linspace(0,1,opts.nbins+1)));
            edg=[ps(1);ps(ed(2:end-1));ps(end)]';
        else
            edg=opts.nbins;
            opts.nbins=length(edg)-1;
            cpal=eval([opts.colormap sprintf('(%d)',opts.nbins)]);
            if opts.flip
                cpal=flipud(cpal);
            end
        end
        if strcmpi(opts.method,'manual')
            for i=1:opts.nbins
                ac=uisetcolor(cpal(i,:),['Define color for class ' num2str(edg(i)) '-' num2str(edg(i+1))]);
                if length(ac)==3
                    cpal(i,:)=ac;
                end
            end
        end
        [dummy,bins]=histc(prop,edg);
        for i=1:opts.nbins-1
            ix=find(bins==i);
            if ~isempty(ix)
                pal(ix,1)={i};
                pal(ix,2)={[num2str(edg(i)) '-' num2str(edg(i+1)) ' (' num2str(length(ix)) ')']};
                pal(ix,3)={cpal(i,:)};
            end
        end
        ix=find(bins>=opts.nbins);
        pal(ix,1)={opts.nbins};
        pal(ix,2)={[num2str(edg(opts.nbins)) '-' num2str(edg(opts.nbins+1)) ' (' num2str(length(ix)) ')']};
        pal(ix,3)={cpal(end,:)};
        % out of bins objects
        ix=cellfun('isempty',pal(:,1));
        pal(ix,1)={0};
        pal(ix,2)={''};
        pal(ix,3)={[0 0 0]};
    end
end
