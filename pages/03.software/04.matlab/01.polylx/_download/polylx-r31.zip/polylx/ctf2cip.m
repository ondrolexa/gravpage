function c=ctf2cip(varargin)
%CTF2CIP Read grid Channel text file and convert it to CIP object.
% Syntax:  c=ctf2cip;

% This file is part of polyLX.
% 
% polyLX is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% polyLX is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with polyLX.  If not, see <http://www.gnu.org/licenses/>.

% polyLX - MATLAB toolbox for microstructure analyses
% Copyright (C) 2010 Ondrej Lexa

% GUI open file

if nargin>0
    if exist(varargin{1},'file')
        filename=varargin{1};
        [pth,nm,ex] = fileparts(filename);
        fnm=[nm ex];
    end
end

if ~exist('filename','var')
    [fnm, pth] = uigetfile('*.ctf', 'Channel text file');
    if fnm==0
        c = [];
        return
    end
end

filename = fullfile(pth,fnm);

% Count header lines
bg = '';
hd = 0;
fid = fopen(filename,'r');
while ~strcmp(bg,'Phase')&&~feof(fid)
    [bg, val] = strtok(fgetl(fid));
    hd = hd+1;
    switch bg
        case 'XCells';
            nx = str2double(val);
        case 'YCells';
            ny = str2double(val);
        case 'XStep';
            xst = str2double(val);
        case 'YStep';
            yst = str2double(val);
        case 'JobMode'
            mode = val;
        case 'Phases';
            poc = str2double(val);
            for i=1:poc
                [bg, val] = strtok(fgetl(fid));
                [bg, val] = strtok(val);
                [bg, val] = strtok(val);
                ph{i}=bg;
            end
    end
end
% Check format
if ~(exist('nx','var')&&exist('ny','var')&&exist('xst','var')&&exist('yst','var'))
    error('Not Channel Text file from Grid mode. Aborting')
end

% Select phase
if poc>1
    [phval,valid]=listdlg('PromptString','Select Phase:','SelectionMode','Single','Name','ctf2cip','ListString',ph);
else
    phval=1;
    valid=1;
end

if valid
    % ctf columns
    Phase=1; X=2; Y=3; Bands=4; Error=5; Euler1=6; Euler2=7; Euler3=8; MAD=9; BC=10; BS=11;
    ctf = textscan(fid,'%d%f%f%d%d%f%f%f%f%d%d');
    fclose(fid);

    mask = reshape(ctf{Phase} == phval, nx, ny)';
    % [001] orientation from euler angles
    % syms e1 e2 e3 x1 x2 x3 real
    % D = [cos(e3) sin(e3) 0;-sin(e3) cos(e3) 0;0 0 1];
    % C = [cos(e2) 0 sin(e2);0 1 0;-sin(e2) 0 cos(e2)];
    % B = [cos(e1) sin(e1) 0;-sin(e1) cos(e1) 0;0 0 1];
    % R = B*C*D;
    % cx = R*[0;0;1]
    c1 = cosd(ctf{Euler1}).*sind(ctf{Euler2});
    c2 = -sind(ctf{Euler2}).*sind(ctf{Euler1});
    c3 = cosd(ctf{Euler2});
    ix = c3<0;
    c1(ix) = -c1(ix);
    c2(ix) = -c2(ix);
    c3(ix) = -c3(ix);
    azi = reshape(mod(atan2(c2,c1)*180/pi, 360), nx, ny)';
    dip = reshape(asind(c3), nx, ny)';

    % e1 = reshape(ctf{Euler1}, nx, ny)';
    % e2 = reshape(ctf{Euler2}, nx, ny)';
    % e3 = reshape(ctf{Euler3}, nx, ny)';
    % mad = reshape(ctf{MAD}, nx, ny)';
    % bc = reshape(ctf{BC}, nx, ny)';
    % bs = reshape(ctf{BS}, nx, ny)';

    c = cipdata(azi,dip,mask,fnm);
else
    c=[];
end