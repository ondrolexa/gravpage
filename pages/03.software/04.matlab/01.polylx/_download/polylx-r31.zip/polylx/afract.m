function gc=afract(g,plt)
%AFRACT Return summary for proportions of grain phases/boundary types
% Calculate total area, area fraction, number of grains and average diameter
% for each phase. Average diameter is EAD for average area.
% For boundaries total length, length fraction, number of boundaries and
% average length for each boundary type is calculated.
% Syntax: res=afract(g,plt);
%  g   - grain/boundary object
%  plt - nonzero plt produce a pie graph
%        1-Area/Length fraction 2-Number fraction

% This file is part of polyLX.
% 
% polyLX is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% polyLX is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with polyLX.  If not, see <http://www.gnu.org/licenses/>.

% polyLX - MATLAB toolbox for microstructure analyses
% Copyright (C) 2010 Ondrej Lexa

if nargin<2
    plt=0;
end

% obtain phase list and number of phases
if isa(g,'polylxgrain')
    ta=sum(get(g,'area'));
    ph=gplist(g);
    head={'Phase' 'Area' '%' 'N' 'Dm'};
elseif isa(g,'polylxboundary')
    ta=sum(get(g,'cumlength'));
    ph=btlist(g);
    head={'Type' 'Length' '%' 'N' 'Lm'};
else
    help afract
    return
end
pf=size(ph,1);
leg=cell(pf,1);
gc=zeros(pf,4);

if isa(g,'polylxgrain')
    % Calculate area fractions
    for i=1:pf
        ix=gpsel(g,ph{i});
        ca=sum(get(g(ix),'area'));
        gc(i,:)=[ca 100*ca/ta length(ix) 2*sqrt(ca/(length(ix)*pi))];
        leg{i}=[ph{i} ' (' num2str(gc(i,3)) ')'];
    end
else
    % Calculate length proportions
    for i=1:pf
        ix=btsel(g,ph{i});
        ca=sum(get(g(ix),'cumlength'));
        gc(i,:)=[ca 100*ca/ta length(ix) ca/(length(ix))];
        leg{i}=[ph{i} ' (' num2str(gc(i,3)) ')'];
    end
end
    
switch plt
    case 1
        ix=gc(:,2)<=2;
        if length(find(ix))>1
            pie([gc(~ix,2); sum(gc(ix,2))]);
            legend([leg(~ix);{['Others (' num2str(sum(gc(ix,3))) ')']}]);
        else
            pie(gc(:,2));
            legend(leg);
        end
        if isa(g,'polylxgrain')
            title('Area fractions')
        else
            title('Length fractions')
        end
    case 2
        pie(gc(:,3));
        legend(leg);
        title('Number fractions')
end
gc=[head;ph num2cell(gc)];
